﻿/* Breezy HEMS 2026.10.10-910ae6c2 : panneau Home Assistant, généré par scripts/build-ha.py (ne pas modifier) */
window.BZ_BUILD = "2026.10.10-910ae6c2";
// ═══ v3/js/core.js
// Breezy HEMS V3 — cœur : accès aux états, commandes, modèle énergétique, historique, formatage.
// Aucune présentation ici : les pages lisent ce module et ne touchent jamais directement aux entités.
(() => {
  const BZ = (window.BZ = window.BZ || {});
  const C = window.VOLTIA_CONFIG;
  // Source des états : la démo (MOCK_STATES, modifiable sur place) ou Home Assistant. Dans le panneau HA,
  // v3/ha/panel-core.js pose window.BZ_HASS avant ce fichier ; hass.states y est un nouvel objet à chaque
  // mise à jour, on le relit donc à chaque accès et on n'y écrit jamais (il appartient à Home Assistant).
  const HA = window.BZ_HASS || null;
  const S = HA ? null : window.MOCK_STATES;
  const states = () => (HA ? HA.states : S);

  /* ─── États ─────────────────────────────────────────────────────── */
  const ent = (id) => states()[id] || { state: "unavailable", attributes: {} };
  const st = (id) => ent(id).state;
  const num = (id) => { const v = parseFloat(st(id)); return Number.isFinite(v) ? v : NaN; };
  const attr = (id, a) => ent(id).attributes[a];
  const isOn = (id) => ["on", "open", "playing", "heat", "unlocked", "cleaning"].includes(st(id));
  // Compteur d'énergie en kWh : Home Assistant donne parfois des Wh (index Linky) ou des MWh ; sans unité, celle de sa
  // statistique. Démo : la valeur telle quelle
  const UNIT = { wh: 1e-3, kwh: 1, mwh: 1e3 };
  const energy = (id) => {
    const v = num(id);
    if (!HA || !Number.isFinite(v)) return v;
    let u = String(attr(id, "unit_of_measurement") || "").trim().toLowerCase();
    if (!u && hist && hist.meta) { const m = hist.meta.find((x) => x.statistic_id === id); u = String((m && m.display_unit_of_measurement) || "").toLowerCase(); }
    return v * (UNIT[u] || 1);
  };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  const listeners = new Set();
  let frame = 0;
  const notify = () => { if (frame) return; frame = requestAnimationFrame(() => { frame = 0; listeners.forEach((f) => f()); }); };
  const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
  const patch = (id, state, attrs) => {
    if (HA) return;   // Home Assistant : l'état vient toujours de HA
    if (!S[id]) S[id] = { entity_id: id, state: "", attributes: {} };
    if (state != null) S[id].state = String(state);
    if (attrs) Object.assign(S[id].attributes, attrs);
  };

  // Attentes en cours (une commande attend son nouvel état) : vérifiées à chaque nouvel état de Home Assistant, sans
  // attendre qu'une image soit dessinée (onglet en arrière-plan : le navigateur ne dessine plus rien)
  const watchers = new Set();
  const checkWatchers = () => { watchers.forEach((w) => w()); };
  // Home Assistant envoie un nouvel hass à chaque changement (parfois plusieurs par seconde) : au plus un rendu
  // par seconde pour le direct ; une commande confirmée se redessine aussitôt (sa fin appelle notify)
  let liveAt = 0, liveTimer = 0;
  const liveNotify = () => {
    checkWatchers();
    const wait = liveAt + 1000 - Date.now();
    if (wait <= 0) { liveAt = Date.now(); notify(); return; }
    if (!liveTimer) liveTimer = setTimeout(() => { liveTimer = 0; liveAt = Date.now(); notify(); }, wait);
  };

  /* ─── Commandes : mêmes services que Home Assistant ──────────────────
     En démo, chaque service modifie l'état local après un court délai, pour
     montrer l'état « en cours ». Branché sur HA, seul `transport` change. */
  const pending = new Set();
  const SERVICES = {
    "light.toggle": (id) => patch(id, isOn(id) ? "off" : "on"),
    "light.turn_off": (id) => patch(id, "off"),
    "switch.toggle": (id) => patch(id, isOn(id) ? "off" : "on"),
    "switch.turn_on": (id) => patch(id, "on"),
    "switch.turn_off": (id) => patch(id, "off"),
    "cover.set_cover_position": (id, d) => patch(id, d.position > 0 ? "open" : "closed", { current_position: d.position }),
    "climate.set_temperature": (id, d) => patch(id, null, { temperature: d.temperature }),
    "climate.set_hvac_mode": (id, d) => patch(id, d.hvac_mode),
    "number.set_value": (id, d) => patch(id, d.value),
    "input_number.set_value": (id, d) => patch(id, d.value),
    "lock.lock": (id) => patch(id, "locked"),
    "lock.unlock": (id) => patch(id, "unlocked"),
    // Démo : un relevé forcé rapporte des valeurs fraîches (en charge : +1 %)
    "button.press": (id) => {
      if (id !== C.voiture_rafraichir) return;
      patch(C.voiture_maj, new Date().toISOString());
      if (isOn(C.voiture_branchee) && isOn(C.voiture_en_charge) && num(C.voiture_soc) < num(C.voiture_limite_pct)) {
        patch(C.voiture_soc, num(C.voiture_soc) + 1); patch(C.session_soc, num(C.session_soc) + 1);
        patch(C.voiture_autonomie_km, num(C.voiture_autonomie_km) + 5); patch(C.voiture_minutes_restantes, Math.max(0, num(C.voiture_minutes_restantes) - 6));
      }
    },
    "vacuum.start": (id) => patch(id, "cleaning", { started_at: new Date().toISOString() }),
    "vacuum.pause": (id) => patch(id, "paused"),
    // Démo : le retour à la base prend quelques secondes, puis l'aspirateur se recharge
    "vacuum.return_to_base": (id) => { patch(id, "returning"); setTimeout(() => { if (st(id) === "returning") { patch(id, "docked"); notify(); } }, 8000); },
    "vacuum.locate": () => {},
    "vacuum.set_fan_speed": (id, d) => patch(id, null, { fan_speed: d.fan_speed }),
    "select.select_option": (id, d) => patch(id, d.option),
    "media_player.media_play_pause": (id) => patch(id, st(id) === "playing" ? "paused" : "playing"),
    "media_player.media_next_track": () => {},
    "media_player.media_previous_track": () => {},
    "media_player.volume_set": (id, d) => patch(id, null, { volume_level: d.volume_level }),
    "script.turn_on": (id) => {
      if (id === C.script_remplir) { patch(C.tremie_kg, Math.min(num(C.tremie_kg) + 15, attr(C.tremie_kg, "max") || 30)); patch(C.stock_kg, Math.max(0, num(C.stock_kg) - 15)); }
      if (id === C.script_achat) patch(C.stock_kg, num(C.stock_kg) + 15);
    },
  };
  const demoTransport = (service, ids, data) => new Promise((resolve) => setTimeout(() => { ids.forEach((id) => SERVICES[service] && SERVICES[service](id, data)); resolve(); }, 280));
  // Home Assistant : « light.toggle » → domaine « light », service « toggle », cibles en entity_id
  const split = (service) => { const i = service.indexOf("."); return [service.slice(0, i), service.slice(i + 1)]; };
  const ENTITY_SVC = /^(light|switch|cover|climate|number|input_number|lock|vacuum|select|media_player)\./;
  const transport = HA
    ? (service, ids, data) => {
      if (!ids.length && ENTITY_SVC.test(service)) return Promise.resolve();   // ex. « tout éteindre » sans lumière allumée : rien à envoyer
      const [d, s] = split(service);
      return HA.callService(d, s, data, ids.length ? { entity_id: ids } : undefined);
    }
    : demoTransport;
  // HA rend la main quand le service a fini ; le nouvel état arrive juste après. On reste « en cours » jusqu'à ce que
  // chaque entité visée change (3 s au plus), sauf pour les services qui ne changent rien à l'entité elle-même.
  // Limites de charge Kia : la valeur ne revient qu'au relevé suivant de la voiture (jusqu'à 90 s).
  const NO_SETTLE = /^(media_player\.media_(next|previous)_track|vacuum\.locate|script\.turn_on|button\.press)$/;
  const settleCap = (ids) => (ids.some((id) => id === C.voiture_limite_pct || id === C.voiture_limite_dc_pct) ? 90000 : 3000);
  // Refus de Home Assistant (objet {code, message} déjà normalisé par le pont) → phrase pour le message
  function haErrorText(e) {
    const code = e && e.code, msg = String((e && e.message) || "").trim();
    if (code === 3 && e.sent === false) return "Pas de connexion à Home Assistant : la commande n'est pas partie.";
    if (code === 3) return "Connexion à Home Assistant perdue : la commande n'est peut-être pas partie.";
    if (code === "not_found") return "Cette action n'existe pas dans Home Assistant (vérifie config.js).";
    if (code === "invalid_format" || code === "service_validation_error") return `Home Assistant a refusé la valeur : ${msg}`;
    if (code === "home_assistant_error" && /unauthori[sz]ed/i.test(msg)) return "Ton compte Home Assistant n'a pas le droit de piloter cet appareil.";
    if (code === "home_assistant_error") return `Home Assistant : ${msg}`;
    return "La commande a échoué.";
  }
  // Démo : résout toujours. Home Assistant : true si la commande est passée, false après un refus (déjà annoncé)
  async function call(service, target, data = {}) {
    const ids = [].concat(target), before = ids.map((id) => states()[id]);
    ids.forEach((id) => pending.add(id));
    notify();
    try {
      await transport(service, ids, data);
      if (HA && ids.length && !NO_SETTLE.test(service)) await waitFor(() => ids.every((id, i) => states()[id] !== before[i]), settleCap(ids));
      return true;
    } catch (e) {
      if (!HA) throw e;
      HA.noteError(service, ids, e);
      BZ.toast(haErrorText(e), "bad");
      return false;
    } finally { ids.forEach((id) => pending.delete(id)); notify(); }
  }
  const isPending = (id) => pending.has(id);

  /* ─── Commandes lentes : la voiture passe par le cloud Kia Connect ─────
     Le service HA rend la main quand Kia a accepté la commande (souvent 5 à 30 s) ;
     la voiture l'applique ensuite et son état ne change qu'au relevé suivant
     (jusqu'à 1 à 2 min). Chaque commande est suivie en trois temps :
       send : envoi au cloud Kia → wait : la voiture applique → ok, ou fail (refus ou délai dépassé).
     Une seule commande voiture à la fois : l'API Kia les traite l'une après l'autre. */
  const slow = new Map();
  const demo = { fail: null, ack: 2400, apply: 5200, timeout: 120000 };   // démo : délais simulés ; fail = "send" | "wait" pour tester un échec
  const demoSlow = (service, ids, data) => new Promise((resolve, reject) => setTimeout(() => {
    const f = demo.fail; demo.fail = null;
    if (f === "send") return reject(new Error("refus"));
    resolve();
    if (f !== "wait") setTimeout(() => { ids.forEach((id) => SERVICES[service] && SERVICES[service](id, data)); notify(); }, demo.apply);
  }, demo.ack));
  // Home Assistant : le service rend la main quand Kia a accepté. Sans réponse en 90 s, ou connexion coupée pendant
  // l'envoi, la commande est peut-être partie : on attend alors la voiture comme si Kia l'avait acceptée.
  // Hors connexion au moment d'appuyer : la commande n'est jamais partie, échec immédiat.
  const ACK_MAX = 90000;
  const transportSlow = HA
    ? (service, ids, data) => {
      const [d, s] = split(service);
      let timer;
      const late = new Promise((resolve) => { timer = setTimeout(() => resolve("unknown"), ACK_MAX); });
      return Promise.race([HA.callService(d, s, data, { entity_id: ids }), late])
        .catch((e) => { if (e && e.code === 3 && e.sent !== false) return "unknown"; throw e; })
        .finally(() => clearTimeout(timer));
    }
    : demoSlow;
  // Vraie dès que ok() l'est : vérifiée à chaque rendu (démo) et à chaque nouvel état de HA ; au bout du délai, une
  // dernière vérification (l'état a pu arriver pendant que la page ne se dessinait plus)
  const waitFor = (ok, ms) => new Promise((resolve) => {
    if (ok()) return resolve(true);
    let done = false;
    const end = (v) => { if (done) return; done = true; clearTimeout(timer); off(); watchers.delete(check); resolve(v); };
    const check = () => { if (ok()) end(true); };
    const timer = setTimeout(() => end(!!ok()), ms);
    const off = subscribe(check);
    watchers.add(check);
  });
  const slowEnd = (t, phase, why) => {
    const end = t.tEnd = Date.now(); t.phase = phase; t.why = why || ""; notify();
    setTimeout(() => { if (slow.get(t.key) === t && t.tEnd === end) { slow.delete(t.key); notify(); } }, phase === "ok" ? 2600 : 12000);
    // Échec, mais la voiture finit par appliquer (confirmation arrivée après le délai) : la commande est faite,
    // on passe à « confirmé » (sinon « Réessayer » relancerait une commande déjà appliquée)
    if (phase === "fail" && t.expect) {
      const w = () => { if (slow.get(t.key) !== t || t.phase !== "fail") stop(); else if (t.expect()) { stop(); slowEnd(t, "ok"); } };
      const off = subscribe(w), stop = () => { off(); watchers.delete(w); };
      watchers.add(w);
    }
    return phase === "ok";
  };
  // key : nom de la commande (lock, clim, charge, refresh) ; to : état visé (pour les libellés) ; expect() : vrai quand la voiture a appliqué
  // Délai de confirmation : 2 min par défaut (Kia Connect), réglable dans config.js pour Home Assistant
  const slowTimeout = () => (HA ? (Number(C.voiture_delai_confirmation_s) || 120) * 1000 : demo.timeout);
  function slowCall(key, service, target, data, { to = null, expect, timeout = slowTimeout() } = {}) {
    const busy = slowBusy();
    if (busy) return busy.promise;
    const t = { key, to, expect, phase: "send", t0: Date.now(), tWait: 0, tEnd: 0, why: "" };
    slow.set(key, t); notify();
    // Raisons d'échec courtes : la page Voiture les affiche telles quelles dans la ligne étroite du pupitre
    t.promise = (async () => {
      try { await transportSlow(service, [].concat(target), data); }
      catch (e) { if (HA) HA.noteError(service, [].concat(target), e); return slowEnd(t, "fail", e && e.code === 3 ? "Hors ligne : commande non envoyée" : "Kia a refusé la commande"); }
      t.phase = "wait"; t.tWait = Date.now(); notify();
      // Option (config.js) : si la voiture tarde à confirmer, on lui demande un relevé, une seule fois
      const ask = HA && key !== "refresh" ? Number(C.voiture_releve_apres_commande_s) || 0 : 0;
      if (ask > 0 && C.voiture_rafraichir) setTimeout(() => { if (t.phase === "wait") HA.callService("button", "press", {}, { entity_id: [C.voiture_rafraichir] }).catch(() => {}); }, ask * 1000);
      return slowEnd(t, ...(await waitFor(expect || (() => true), timeout) ? ["ok"] : ["fail", "La voiture n'a pas confirmé"]));
    })();
    return t.promise;
  }
  const slowOf = (key) => slow.get(key) || null;
  const slowBusy = () => [...slow.values()].find((t) => t.phase === "send" || t.phase === "wait") || null;

  /* ─── Modèle énergétique en direct ─────────────────────────────────── */
  function live() {
    const solar = Math.max(0, num(C.solaire_w));
    const grid = num(C.reseau_w);                                   // + achat, − revente
    const bat = C.batterie_inverse ? -num(C.batterie_w) : num(C.batterie_w); // + charge, − décharge
    const plugged = isOn(C.voiture_branchee), charging = plugged && isOn(C.voiture_en_charge);
    // Home Assistant : la phase du compteur sert aussi à d'autres appareils, on ne la compte comme voiture qu'en charge
    const car = (HA ? charging : plugged) ? Math.max(0, num(C.voiture_charge_w)) : 0;
    const total = solar + grid - bat;
    const evSun = Math.max(0, num(C.ve_solaire_w)), evGrid = Math.max(0, num(C.ve_reseau_w));
    return { solar, grid, bat, car, house: Math.max(0, total - car), total, plugged, charging, evSolarShare: evSun + evGrid > 0 ? evSun / (evSun + evGrid) : 0 };
  }

  // Compteur du jour ; capteur indisponible dans Home Assistant : le cumul du jour lu dans l'historique
  const ctr = (key, field) => { const v = field === "savings" ? num(C[key]) : energy(C[key]); return Number.isFinite(v) || !hist ? v : hist.todaySoFar(field); };
  function today() {
    const prod = ctr("production_jour_kwh", "prod"), imp = ctr("import_jour_kwh", "imp"), exp = ctr("export_jour_kwh", "exp");
    const chg = ctr("batterie_charge_jour_kwh", "chg"), dch = ctr("batterie_decharge_jour_kwh", "dch");
    const cons = prod - exp + imp - chg + dch;
    const self = Math.max(0, prod - exp - chg);
    return { prod, imp, exp, chg, dch, cons, self, forecast: num(C.prevision_jour_kwh), autonomy: cons > 0 ? clamp(1 - imp / cons, 0, 1) : 0, savings: ctr("economies_jour_eur", "savings") };
  }

  /* ─── Tarifs ───────────────────────────────────────────────────────── */
  // Prix lu dans Home Assistant ; s'il est indisponible, le prix de secours de config.js
  const pick = (v, d) => (Number.isFinite(v) ? v : Number.isFinite(d) ? d : NaN);
  const TARIFS = {
    hp: { label: "Heures pleines", short: "HP", price: () => pick(num(C.tarif_hp), C.tarif_hp_defaut) },
    hc: { label: "Heures creuses", short: "HC", price: () => pick(num(C.tarif_hc), C.tarif_hc_defaut) },
    hsc: { label: "Super creuses", short: "HSC", price: () => pick(num(C.tarif_hsc), C.tarif_hsc_defaut) },
  };
  const ranges = (k) => ((C.plages_tarifaires || {})[k] || []).map((r) => r.split("-").map((t) => parseInt(t, 10)));
  const inRange = (h, [a, b]) => (a <= b ? h >= a && h < b : h >= a || h < b);
  const tariffAt = (h) => (ranges("hsc").some((r) => inRange(h, r)) ? "hsc" : ranges("hc").some((r) => inRange(h, r)) ? "hc" : "hp");
  function tariffNow(date = new Date()) {
    const h = date.getHours(), key = tariffAt(h);
    let next = 1; while (next < 24 && tariffAt((h + next) % 24) === key) next++;
    const changeAt = new Date(date); changeAt.setHours(h + next, 0, 0, 0);
    return { key, ...TARIFS[key], price: TARIFS[key].price(), nextKey: tariffAt((h + next) % 24), changeAt };
  }
  const tariffHours = () => Array.from({ length: 24 }, (_, h) => tariffAt(h));
  const rangeLabel = (k) => k === "hp" ? "7h–23h" : ranges(k).map(([a, b]) => `${a}h–${b}h`).join(", ");

  /* ─── Historique ──────────────────────────────────────────────────────
     Démo : inventé mais cohérent sur toutes les périodes (ci-dessous). Home Assistant : un fournisseur
     (v3/ha/history.js) s'inscrit par BZ.useHistory et répond de façon synchrone depuis son cache ;
     tant qu'une valeur n'est pas arrivée, elle vaut NaN (affichée « — ») avec loading: true. */
  let hist = null;
  const useHistory = (p) => { hist = p; BZ.hist = p; notify(); };
  const day = (date) => (hist ? hist.day(date) : demoDay(date));
  const hours = () => (hist ? hist.hours() : demoHours());
  const forecastDay = (date) => (hist ? hist.forecastDay(date) : demoForecastDay(date));

  /* ─── Historique de démo, cohérent sur toutes les périodes ─────────────
     Une seule fonction « jour » produit les totaux d'une journée ; semaine,
     mois et année sont des sommes de jours. Aujourd'hui = valeurs des capteurs. */
  const rnd = (seed) => { let t = (seed + 0x6d2b79f5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const MONTH_PROD = [7.2, 10.5, 15.5, 20.6, 24.5, 27.3, 27.4, 25.2, 19.7, 13.5, 8.3, 6.1];   // kWh/jour moyens
  const MONTH_CONS = [15.2, 14.6, 12.5, 11.0, 9.8, 9.3, 9.2, 9.4, 10.2, 11.2, 13.8, 15.4];
  const dayKey = (d) => d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate();
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
  const isToday = (d) => startOfDay(d).getTime() === startOfDay(new Date()).getTime();

  function demoDay(date) {
    if (isToday(date)) {
      const t = today();
      return { date, prod: t.prod, cons: t.cons, self: t.self, chg: t.chg, dch: t.dch, imp: t.imp, exp: t.exp, ...splitImport(t.imp, dayKey(date)), ev: 8.9, evSun: 6.8, savings: t.savings, partial: true };
    }
    const k = dayKey(date), m = date.getMonth();
    const weather = 0.5 + 0.7 * rnd(k);                        // nuageux … ensoleillé
    const prod = MONTH_PROD[m] * weather;
    const doy = Math.floor((date - new Date(date.getFullYear(), 0, 1)) / 864e5);
    const evDay = doy % 3 === 0;                                // une recharge tous les 3 jours environ
    const ev = evDay ? 6 + rnd(k * 11) * 7 : 0;
    const cons = MONTH_CONS[m] * (0.9 + rnd(k * 3) * 0.2) + ev * 0.6;
    // Le soleil ne couvre que la journée : au mieux ~55 % de la consommation en direct
    const self = Math.min(prod * 0.8, cons * 0.55) * (0.85 + rnd(k * 5) * 0.1);
    const surplus = Math.max(0, prod - self);
    const chg = Math.min(surplus * 0.55, 7.5), exp = surplus - chg;
    const dch = Math.min(chg * 0.92, Math.max(0, cons - self) * 0.6);
    const imp = Math.max(cons * 0.15, cons - self - dch);
    const evSun = ev ? Math.min(ev, ev * (weather > 0.8 ? 0.85 : 0.25)) : 0;
    const savings = (self + dch) * 0.2 + exp * 0.06;
    return { date, prod, cons, self, chg, dch, imp, exp, ...splitImport(imp, k), ev, evSun, savings };
  }
  function splitImport(imp, k) {
    const hsc = imp * (0.45 + rnd(k * 13) * 0.15), hc = imp * (0.15 + rnd(k * 17) * 0.1);
    return { hsc, hc, hp: Math.max(0, imp - hsc - hc) };
  }
  const FIELDS = ["prod", "cons", "self", "chg", "dch", "imp", "exp", "hp", "hc", "hsc", "ev", "evSun", "savings"];
  // Home Assistant : une valeur inconnue (NaN) le reste dans la somme, et les drapeaux des jours suivent
  // (jours sans historique non comptés, voir history.js ; gaps : jours sans données ; splitLoading : achat par tarif en route)
  const sumDays = (days) => (hist ? hist.sum(days) : FIELDS.reduce((o, f) => ((o[f] = days.reduce((a, d) => a + (d[f] || 0), 0)), o), {}));
  // Prévision pour une journée à venir : production attendue seulement
  const demoForecastDay = (date) => ({ date, prod: MONTH_PROD[date.getMonth()] * (0.75 + rnd(dayKey(date)) * 0.3), forecast: true });

  // Profil horaire d'aujourd'hui, calé sur les compteurs du jour
  function demoHours() {
    const now = new Date(), H = now.getHours() + now.getMinutes() / 60, t = today();
    const sunShape = (h) => Math.max(0, Math.exp(-((h + 0.5 - 13.2) ** 2) / (2 * 2.7 ** 2)) - 0.02);
    const consShape = (h) => 0.35 + (h >= 6 && h < 8 ? 0.9 : 0) + (h >= 9 && h < 12 ? 1.6 : 0) + (h >= 18 && h < 21 ? 1.2 : 0) + (h >= 2 && h < 5 ? 0.6 : 0);
    const past = (h) => h + 1 <= H;
    const sh = Array.from({ length: 24 }, (_, h) => sunShape(h)), ch = Array.from({ length: 24 }, (_, h) => consShape(h));
    const sumPast = (a) => a.reduce((s, v, h) => s + (past(h) ? v : 0), 0);
    const kP = t.prod / (sumPast(sh) || 1), kC = t.cons / (sumPast(ch) || 1);
    const kF = Math.max(0, t.forecast - t.prod) / (sh.reduce((s, v, h) => s + (past(h) ? 0 : v), 0) || 1);
    return Array.from({ length: 24 }, (_, h) => ({
      h, label: `${h}h`, tariff: tariffAt(h), future: !past(h), current: h === Math.floor(H),
      prod: sh[h] * (past(h) ? kP : kF), cons: past(h) ? ch[h] * kC : null,
    }));
  }

  const MONTHS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  const MONTHS_LONG = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  // Une période = une liste de « cases » (heures, jours ou mois) + la même période d'avant pour comparer.
  // Home Assistant : la période d'avant est arrêtée à la même heure et ne compte que ce qui est connu des deux côtés
  // (group : « energie » ou « voiture », les compteurs qui doivent exister) ; cmpTotal = la période en cours réduite d'autant
  function period(kind, group) {
    if (hist) return periodHA(kind, group);
    const now = new Date(), D = (y, m, d) => new Date(y, m, d, 12);
    const y = now.getFullYear(), m = now.getMonth(), d = now.getDate();
    const daysBetween = (a, n) => Array.from({ length: n }, (_, i) => D(a.getFullYear(), a.getMonth(), a.getDate() + i));
    let buckets, prev, title, compare;
    if (kind === "jour") {
      buckets = hours().map((x) => ({ ...x, key: x.label, value: x.prod }));
      const tot = { ...sumDays([day(now)]) };
      return { kind, title: "Aujourd'hui", compare: "vs hier", buckets, total: tot, prevTotal: sumDays([day(D(y, m, d - 1))]), unitLabel: "par heure" };
    }
    if (kind === "semaine") {
      const days = daysBetween(D(y, m, d - 6), 7);
      buckets = days.map((x) => ({ key: x.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", ""), ...day(x), current: isToday(x) }));
      prev = daysBetween(D(y, m, d - 13), 7).map(day); title = "7 derniers jours"; compare = "vs 7 jours d'avant";
    } else if (kind === "mois") {
      const n = new Date(y, m + 1, 0).getDate();
      buckets = daysBetween(D(y, m, 1), n).map((x) => (x.getDate() <= d ? { key: String(x.getDate()), ...day(x), current: x.getDate() === d } : { key: String(x.getDate()), ...forecastDay(x) }));
      prev = daysBetween(D(y, m - 1, 1), Math.min(d, new Date(y, m, 0).getDate())).map(day); title = MONTHS_LONG[m][0].toUpperCase() + MONTHS_LONG[m].slice(1); compare = "vs même période le mois dernier";
    } else {
      buckets = MONTHS.map((lab, i) => {
        if (i > m) return { key: lab, prod: MONTH_PROD[i] * new Date(y, i + 1, 0).getDate(), forecast: true };
        const n = i === m ? d : new Date(y, i + 1, 0).getDate();
        return { key: lab, ...sumDays(daysBetween(D(y, i, 1), n).map(day)), current: i === m };
      });
      prev = []; for (let i = 0; i <= m; i++) prev.push(...daysBetween(D(y - 1, i, 1), i === m ? d : new Date(y - 1, i + 1, 0).getDate()).map(day));
      title = String(y); compare = `vs ${y - 1} à date`;
    }
    const real = buckets.filter((b) => !b.forecast);
    return { kind, title, compare, buckets, total: sumDays(real), prevTotal: sumDays(prev), forecastTotal: buckets.reduce((a, b) => a + (b.prod || 0), 0) };
  }

  function periodHA(kind, group = "energie") {
    const now = new Date(), D = (y, m, d) => new Date(y, m, d, 12), K = hist.key, S = hist.shifts;
    const y = now.getFullYear(), m = now.getMonth(), d = now.getDate();
    const daysBetween = (a, n) => Array.from({ length: n }, (_, i) => D(a.getFullYear(), a.getMonth(), a.getDate() + i));
    const like = (a, b, pa, pb, shift) => hist.like({ a: K(a), b: K(b), pa: K(pa), pb: K(pb), live: true, group, shift });
    let buckets, title, compare, cmp;
    if (kind === "jour") {
      buckets = hours().map((x) => ({ ...x, key: x.label, value: x.prod }));
      cmp = like(now, now, D(y, m, d - 1), D(y, m, d - 1), S.days(1));
      return { kind, title: "Aujourd'hui", compare: "vs hier à la même heure", buckets, total: sumDays([day(now)]), prevTotal: cmp.prevTotal, cmpTotal: cmp.cmpTotal, cmp, unitLabel: "par heure" };
    }
    if (kind === "semaine") {
      buckets = daysBetween(D(y, m, d - 6), 7).map((x) => ({ key: x.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", ""), ...day(x), current: isToday(x) }));
      cmp = like(D(y, m, d - 6), now, D(y, m, d - 13), D(y, m, d - 7), S.days(7)); title = "7 derniers jours"; compare = "vs 7 jours d'avant";
    } else if (kind === "mois") {
      const n = new Date(y, m + 1, 0).getDate(), pn = new Date(y, m, 0).getDate();
      buckets = daysBetween(D(y, m, 1), n).map((x) => (x.getDate() <= d ? { key: String(x.getDate()), ...day(x), current: x.getDate() === d } : { key: String(x.getDate()), ...forecastDay(x) }));
      // Mois d'avant plus court que le jour d'aujourd'hui : tout le mois d'avant, sans heure d'arrêt
      cmp = d > pn ? hist.like({ a: K(D(y, m, 1)), b: K(now), pa: K(D(y, m - 1, 1)), pb: K(D(y, m - 1, pn)), live: false, group, shift: S.month(K(now).slice(0, 7)) })
        : like(D(y, m, 1), now, D(y, m - 1, 1), D(y, m - 1, d), S.month(K(now).slice(0, 7)));
      title = MONTHS_LONG[m][0].toUpperCase() + MONTHS_LONG[m].slice(1); compare = "vs même période le mois dernier";
    } else {
      buckets = MONTHS.map((lab, i) => (i > m ? { key: lab, ...hist.forecastMonth(y, i) } : { key: lab, ...hist.monthSum(y, i, i === m ? d : null), current: i === m }));
      cmp = like(D(y, 0, 1), now, D(y - 1, 0, 1), D(y - 1, m, Math.min(d, new Date(y - 1, m + 1, 0).getDate())), S.year(y));
      title = String(y); compare = `vs ${y - 1} à date`;
    }
    const real = buckets.filter((b) => !b.forecast);
    return { kind, title, compare, buckets, total: sumDays(real), prevTotal: cmp.prevTotal, cmpTotal: cmp.cmpTotal, cmp, forecastTotal: buckets.reduce((a, b) => a + (b.prod || 0), 0) };
  }

  /* ─── Voiture : recharges ─────────────────────────────────────────── */
  function chargeDays(n = 35) {
    return Array.from({ length: n }, (_, i) => {
      const date = new Date(); date.setDate(date.getDate() - (n - 1 - i));
      const x = day(date);
      // Home Assistant : jour d'avant les compteurs de la borne (pas d'historique) : pas de recharge connue
      const kwh = hist && x.nocov && !Number.isFinite(x.ev) && !x.loading ? 0 : x.ev;
      return { date, kwh, sun: kwh ? x.evSun / kwh : 0, ...(hist ? { evHp: x.evHp, evHc: x.evHc, evHsc: x.evHsc, loading: x.loading || x.evLoading, absent: x.absent, nocov: x.nocov && kwh === 0 && !Number.isFinite(x.ev) } : {}) };
    });
  }
  function chargeMix(kind) {
    if (hist) {
      // Home Assistant : kWh de la borne par tarif, heure par heure (historique) ; inconnus tant qu'ils ne sont pas arrivés
      const t = kind === "jour" ? sumDays([day(new Date())]) : period(kind, "voiture").total;
      const mix = { sol: t.evSun, hsc: t.evHsc, hc: t.evHc, hp: t.evHp }, price = { sol: 0, hsc: TARIFS.hsc.price(), hc: TARIFS.hc.price(), hp: TARIFS.hp.price() };
      const kwh = t.ev, cost = Object.keys(mix).reduce((a, k) => a + mix[k] * price[k], 0);
      return { kwh, cost, mix, price, sunShare: kwh > 0 ? t.evSun / kwh : kwh === 0 ? 0 : NaN, hpCost: kwh * price.hp, loading: t.loading };
    }
    const p = period(kind === "jour" ? "semaine" : kind), t = kind === "jour" ? sumDays([day(new Date())]) : p.total;
    const grid = Math.max(0, t.ev - t.evSun);
    // Démo : répartition du réseau par plage ; « heures creuses seulement » exclut les heures pleines.
    // Avec Home Assistant, ces kWh viendront des compteurs de la borne par tarif.
    const offPeak = isOn(C.voiture_heures_creuses);
    const mix = offPeak ? { sol: t.evSun, hsc: grid * 0.72, hc: grid * 0.28, hp: 0 } : { sol: t.evSun, hsc: grid * 0.62, hc: grid * 0.23, hp: grid * 0.15 };
    const price = { sol: 0, hsc: num(C.tarif_hsc), hc: num(C.tarif_hc), hp: num(C.tarif_hp) };
    const kwh = t.ev, cost = Object.keys(mix).reduce((a, k) => a + mix[k] * price[k], 0);
    return { kwh, cost, mix, price, sunShare: kwh ? t.evSun / kwh : 0, hpCost: kwh * price.hp };
  }

  /* ─── Retour sur investissement ───────────────────────────────────── */
  function roi() {
    const inv = C.solaire_investissement_eur, total = num(C.economies_total_eur), start = new Date(C.solaire_mise_en_service);
    const years = Math.max(0.1, (Date.now() - start) / (365.25 * 864e5)), perYear = total / years;
    const remaining = Math.max(0, inv - total);
    return { inv, total, start, perYear, remaining, progress: clamp(total / inv, 0, 1), payback: new Date(Date.now() + (remaining / perYear) * 365.25 * 864e5), totalYears: inv / perYear };
  }

  /* ─── Formatage ───────────────────────────────────────────────────── */
  const nf = (d) => new Intl.NumberFormat("fr-FR", { minimumFractionDigits: d, maximumFractionDigits: d });
  const NF = [0, 1, 2, 3, 4].map(nf);
  // Valeur inconnue (capteur indisponible, historique en chargement, date illisible) : « — », jamais « NaN »
  const ok = Number.isFinite, okDate = (d) => d != null && Number.isFinite(+new Date(d));
  const fmt = {
    n: (v, d = 0) => (Number.isFinite(v) ? NF[d].format(v) : "—"),
    // Puissance : valeur + unité séparées, pour styliser l'unité
    power: (w) => (!ok(w) ? ["—", "W"] : Math.abs(w) >= 1000 ? [NF[2].format(w / 1000), "kW"] : [NF[0].format(w), "W"]),
    powerText: (w) => { const [v, u] = fmt.power(w); return `${v} ${u}`; },
    kwh: (v) => (ok(v) ? [NF[v >= 100 ? 0 : 1].format(v), "kWh"] : ["—", "kWh"]),
    kwhText: (v) => (ok(v) ? `${NF[v >= 100 ? 0 : 1].format(v)} kWh` : "— kWh"),
    eur: (v, d = v >= 100 ? 0 : 2) => (ok(v) ? `${NF[d].format(v)} €` : "— €"),
    pct: (v) => (ok(v) ? `${NF[0].format(v * 100)} %` : "— %"),
    time: (d) => (okDate(d) ? d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "—"),
    ago: (iso) => {
      const m = Math.round((Date.now() - new Date(iso)) / 60e3);
      if (!ok(m)) return "—";
      if (m < 1) return "à l'instant"; if (m < 60) return `il y a ${m} min`; if (m < 1440) return `il y a ${Math.round(m / 60)} h`;
      if (m < 2880 && new Date(iso).getDate() === new Date(Date.now() - 864e5).getDate()) return "hier";
      if (m < 60 * 1440) return `il y a ${Math.round(m / 1440)} j`; return `il y a ${Math.round(m / 43800)} mois`;
    },
    inDays: (date) => Math.round((date - Date.now()) / 864e5),
    date: (d, o = { day: "numeric", month: "long" }) => (okDate(d) ? d.toLocaleDateString("fr-FR", o) : "—"),
    cap: (s) => s.charAt(0).toUpperCase() + s.slice(1),
  };

  /* ─── Démo : petites variations pour que le direct « vive » ─────────── */
  function jitter() {
    C.onduleurs_w.forEach((id, i) => { const base = [1920, 1880, 1050][i]; patch(id, Math.round(base * (0.93 + Math.random() * 0.1))); });
    patch(C.solaire_w, C.onduleurs_w.reduce((a, id) => a + num(id), 0));
    const l = live();
    patch(C.reseau_w, Math.round(1070 + l.car + l.bat - l.solar + (Math.random() - 0.5) * 140));
    notify();
  }
  if (!HA) setInterval(jitter, 5000);

  /* ─── Dates des entités ───────────────────────────────────────────────
     Démo : chaînes ISO. Home Assistant : un input_datetime vaut « AAAA-MM-JJ HH:MM:SS », « AAAA-MM-JJ » ou
     « HH:MM:SS » (illisible pour Safari via new Date) ; son attribut timestamp est sûr (heure seule : secondes depuis minuit).
     Un capteur horodaté (device_class timestamp) donne une date ISO avec fuseau. */
  const dtDemo = (id) => new Date(st(id));
  function dtHA(id) {
    const e = ent(id), a = e.attributes || {}, s = String(e.state);
    if (Number.isFinite(a.timestamp)) {
      if (a.has_date === false) { const d = new Date(); d.setHours(0, 0, 0, 0); return new Date(d.getTime() + a.timestamp * 1000); }
      return new Date(a.timestamp * 1000);
    }
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/.exec(s);
    if (m) return new Date(+m[1], m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
    return new Date(s);
  }
  const dt = HA ? dtHA : dtDemo;

  if (HA) HA.on("states", liveNotify);
  // Adresse d'une page : « #/energy » (démo) ; Home Assistant : celle du panneau (/breezy/energy), qui s'ouvre aussi
  // dans un nouvel onglet ou se copie
  const href = (id) => (HA ? HA.pathOf(id) : `#/${id}`);

  Object.assign(BZ, {
    C, ent, st, num, attr, isOn, clamp, call, isPending, subscribe, notify, slowCall, slowOf, slowBusy, demo,
    live, today, tariffNow, tariffHours, tariffAt, rangeLabel, TARIFS, hours, period, day, chargeDays, chargeMix, roi,
    fmt, MONTHS, MONTHS_LONG,
    // Home Assistant (null / false en démo)
    ha: HA, HA: !!HA, hist, states, liveNotify, useHistory, dt, haErrorText, energy, href,
  });
})();
;
// ═══ v3/ha/history.js
// Breezy HEMS — historique Home Assistant (statistiques long terme), chargé juste après core.js, dans le panneau HA seulement.
// Règles de calcul (vérifiées sur les sources de HA, à confirmer sur un échantillon réel : « Copier le diagnostic ») :
//  · compteurs (kWh, €) : la variation `change` du cumul `sum` que HA calcule par heure ou par jour (c'est aussi ce que
//    fait son tableau Énergie) ; jamais `state` ni `max` d'une case : une remise à zéro vers minuit les fausse ;
//    un mois = la somme de ses journées (la même valeur dans la vue Mois et dans la vue Année) ;
//  · niveau de la batterie (%) : la moyenne `mean` de chaque heure ;
//  · aujourd'hui : les compteurs du jour en direct (convertis en kWh) ; l'heure en cours = compteur du jour − heures
//    déjà écrites par HA (seulement à l'intérieur d'aujourd'hui, jamais d'un jour sur l'autre) ;
//  · journées, mois et heures dans le fuseau de Home Assistant (hass.config.time_zone), comme ses statistiques.
// Garde-fous :
//  · lignes triées ; une variation négative est ramenée à 0 et reprise sur les heures suivantes du même jour ;
//    un jour terminé garde toujours la variation de son cumul (Σ des heures = chiffre du jour) ;
//  · une heure invraisemblable (pic de remise à zéro d'un compteur) est écartée, et la même quantité est retirée de
//    la journée, du mois et des fenêtres qui la contiennent ; une journée invraisemblable fait lire ses heures ;
//  · chaque compteur a une date de début (sa première statistique) : avant, la valeur est inconnue (« — »), jamais 0 ;
//    avant la mise en service des panneaux, production, revente, batterie et économies valent 0 (l'achat reste lu) ;
//  · les comparaisons ne portent que sur ce qui est connu des deux côtés (même durée, même heure) ;
//  · aucune valeur inventée : inconnu = NaN, affiché « — ».
// Les getters sont synchrones et ne lèvent jamais : ils lisent un cache par morceaux et demandent ce qui manque.
(() => {
  const BZ = window.BZ, HA = BZ.ha;
  if (!HA) return;
  const C = BZ.C;
  const HOUR = 36e5, DAY = 864e5;
  const ENTITY = /^[a-z_]+\.[a-z0-9_]+$/;
  const pad = (n) => String(n).padStart(2, "0");
  const H24 = Array.from({ length: 24 }, (_, h) => h);

  /* ─── Fuseau de Home Assistant ──────────────────────────────────────── */
  function makeTz(tz) {
    const o = { hourCycle: "h23", year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" };
    let f;
    try { f = new Intl.DateTimeFormat("en-US", { ...o, timeZone: tz }); } catch { f = new Intl.DateTimeFormat("en-US", o); }   // fuseau inconnu : celui de l'appareil
    const parts = (ms) => { const r = {}; for (const p of f.formatToParts(ms)) r[p.type] = p.value; return { y: +r.year, m: +r.month - 1, d: +r.day, h: +r.hour % 24, mi: +r.minute, s: +r.second }; };
    const offset = (ms) => { const p = parts(ms); return Date.UTC(p.y, p.m, p.d, p.h, p.mi, p.s) - (ms - (ms % 1000)); };
    const at = (y, m, d, h = 0) => { const g = Date.UTC(y, m, d, h); return g - offset(g - offset(g)); };   // heure murale → instant (2 passes : sûr aux changements d'heure)
    const key = (ms) => { const p = parts(ms); return `${p.y}-${pad(p.m + 1)}-${pad(p.d)}`; };
    return { parts, at, key };
  }
  let TZ = makeTz(HA.tz), tzName = HA.tz;
  // Les pages construisent des Date locales (navigateur) : leur jour AAAA-MM-JJ est lu comme un jour de Home Assistant
  const pageKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const ymd = (k) => k.split("-").map(Number);
  const dayNum = (k) => { const [y, m, d] = ymd(k); return Math.round(Date.UTC(y, m - 1, d) / DAY); };
  const addDays = (k, n) => { const [y, m, d] = ymd(k), x = new Date(Date.UTC(y, m - 1, d + n)); return `${x.getUTCFullYear()}-${pad(x.getUTCMonth() + 1)}-${pad(x.getUTCDate())}`; };
  const dayStart = (k) => { const [y, m, d] = ymd(k); return TZ.at(y, m - 1, d); };
  const monthOf = (k) => k.slice(0, 7);
  const monthStart = (mk) => { const [y, m] = ymd(mk); return TZ.at(y, m - 1, 1); };
  const nextMonth = (mk) => { const [y, m] = ymd(mk); return m === 12 ? `${y + 1}-01` : `${y}-${pad(m + 1)}`; };
  const prevMonth = (mk) => { const [y, m] = ymd(mk); return m === 1 ? `${y - 1}-12` : `${y}-${pad(m - 1)}`; };
  const daysIn = (mk) => { const [y, m] = ymd(mk); return new Date(Date.UTC(y, m, 0)).getUTCDate(); };
  const todayKey = () => TZ.key(Date.now());
  const iso = (ms) => new Date(ms).toISOString();
  const dayDate = (k) => { const [y, m, d] = ymd(k); return new Date(y, m - 1, d, 12); };
  const maxKey = (a, b) => (a > b ? a : b);
  // Heure de HA (décimale) maintenant : la période d'avant est arrêtée à la même heure
  const nowH = () => { const p = TZ.parts(Date.now()); return p.h + p.mi / 60 + p.s / 3600; };
  const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
  const dayOf = (v) => (DAY_RE.test(String(v || "").slice(0, 10)) ? String(v).slice(0, 10) : "");
  // Mise en service des panneaux : avant, production, revente, batterie et économies valent 0 (l'achat, lui, est lu)
  const SOLAR0 = dayOf(C.solaire_mise_en_service) || "2000-01-01";
  // Début du Bilan (navigation) : historique_debut de config.js, sinon la mise en service
  const HSTART = dayOf(C.historique_debut) || SOLAR0;
  // Couverture demandée depuis décembre de l'année d'avant celle qui précède le début : une statistique qui a une
  // ligne ce mois-là couvre tout ce que Breezy peut afficher ou comparer
  const COV_Y = +(HSTART < SOLAR0 ? HSTART : SOLAR0).slice(0, 4) - 1;
  const COV_REQ = `${COV_Y - 1}-12`;
  const SOLAR_F = new Set(["prod", "exp", "chg", "dch", "evSun", "savings"]);

  /* ─── Registre des champs : quel compteur de Home Assistant pour quoi ─────
     Pour chaque champ, parmi les candidats (clés de config.js, dans l'ordre) qui ont de vraies statistiques,
     celui dont l'historique commence le plus tôt (à égalité : le premier). */
  const REG = [
    { f: "prod", keys: ["stat_production", "production_jour_kwh"], kind: "energy", group: "energie", label: "la production solaire" },
    { f: "imp", keys: ["stat_import", "import_jour_kwh"], kind: "energy", group: "energie", label: "l'achat au réseau" },
    { f: "exp", keys: ["stat_export", "export_jour_kwh"], kind: "energy", group: "energie", label: "la revente au réseau" },
    { f: "chg", keys: ["stat_batterie_charge", "batterie_total_charge_kwh", "batterie_charge_jour_kwh"], kind: "energy", group: "energie", label: "la charge de la batterie" },
    { f: "dch", keys: ["stat_batterie_decharge", "batterie_total_decharge_kwh", "batterie_decharge_jour_kwh"], kind: "energy", group: "energie", label: "la décharge de la batterie" },
    { f: "evSun", keys: ["stat_ve_solaire", "ve_solaire_kwh"], kind: "energy", group: "voiture", label: "la recharge solaire de la voiture" },
    { f: "evGrid", keys: ["stat_ve_reseau", "ve_reseau_kwh"], kind: "energy", group: "voiture", label: "la recharge de la voiture sur le réseau" },
    { f: "savings", keys: ["stat_economies", "economies_total_eur", "economies_jour_eur"], kind: "money", group: "economies", label: "les économies" },
    { f: "impHp", keys: ["stat_import_hp"], kind: "energy", group: "tarifs", label: "l'achat en heures pleines" },
    { f: "impHc", keys: ["stat_import_hc"], kind: "energy", group: "tarifs", label: "l'achat en heures creuses" },
    { f: "impHsc", keys: ["stat_import_hsc"], kind: "energy", group: "tarifs", label: "l'achat en heures super creuses" },
    { f: "soc", keys: ["batterie_soc"], kind: "mean", group: "soc", label: "le niveau de la batterie" },
  ];
  const GROUPS = { energie: ["prod", "imp", "exp", "chg", "dch"], voiture: ["evSun", "evGrid"], economies: ["savings"], tarifs: ["impHp", "impHc", "impHsc"], soc: ["soc"] };
  const SUMS = ["prod", "imp", "exp", "chg", "dch", "evSun", "evGrid", "savings", "impHp", "impHc", "impHsc"];
  const DAYF = ["prod", "imp", "exp", "chg", "dch", "evSun", "evGrid", "savings"];
  const ENERGY_UNITS = ["Wh", "kWh", "MWh"];
  // Live du jour (compteurs remis à 0 chaque nuit) : la clé de config.js de chaque champ, pour l'heure en cours et le contrôle C1
  const LIVE_KEY = { prod: "production_jour_kwh", imp: "import_jour_kwh", exp: "export_jour_kwh", chg: "batterie_charge_jour_kwh", dch: "batterie_decharge_jour_kwh", savings: "economies_jour_eur" };
  const candidates = (r) => r.keys.map((key) => ({ key, id: C[key] })).filter((c) => typeof c.id === "string" && ENTITY.test(c.id));

  let META = { status: "idle", list: null, by: null };   // métadonnées brutes (recorder/get_statistics_metadata)
  let FIELDS = {};                                        // champ → { id, key, alt }
  let PROBLEMS = [];                                      // candidats refusés (pour le diagnostic)
  let OKC = new Map();                                    // champ → candidats valables (avant le choix par couverture)
  let FIRST = new Map();                                  // statistique → mois de sa première ligne (AAAA-MM), "none" sans aucune
  let COVROWS = new Map();                                // statistique → Map(mois → variation brute) (contrôles C2, C3)
  // Contrat d'un candidat : un compteur a une somme (has_sum) et une unité d'énergie ou d'euros ; le SOC a une moyenne
  function verdict(m, kind) {
    if (!m) return { why: "missing" };
    const meanType = m.mean_type != null ? m.mean_type : m.has_mean ? 1 : 0, u = String(m.statistics_unit_of_measurement || m.display_unit_of_measurement || "").trim();
    if (kind === "mean") return meanType ? { ok: true } : { why: "nomean" };
    if (!m.has_sum) return { why: meanType ? "measure" : "nosum" };
    if (kind === "energy") return m.unit_class === "energy" || ENERGY_UNITS.includes(u) ? { ok: true } : { why: "unit", unit: u };
    const cur = (HA.hass && HA.hass.config && HA.hass.config.currency) || "EUR";
    return /^(€|eur|euros?)$/i.test(u) || u === cur ? { ok: true } : { why: "unit", unit: u };
  }
  // Étape 1 (métadonnées) : candidats valables de chaque champ ; étape 2 (couverture) : le choix
  function screen(list) {
    const by = new Map((list || []).map((m) => [m.statistic_id, m]));
    OKC = new Map(); PROBLEMS = [];
    for (const r of REG) {
      const ok = [];
      candidates(r).forEach((c, i) => { const v = verdict(by.get(c.id), r.kind); if (v.ok) ok.push({ ...c, i }); else PROBLEMS.push({ f: r.f, ...c, ...v }); });
      OKC.set(r.f, ok);
    }
    META = { status: "loading", list, by };
  }
  const firstOf = (id) => { const v = FIRST.get(id); return v == null || v === "none" ? "9999-99" : v; };
  function resolve() {
    FIELDS = {};
    for (const r of REG) {
      const ok = OKC.get(r.f) || [];
      if (!ok.length) continue;
      // Le compteur préféré peut avoir été créé tard (state_class ajouté après coup, base du recorder repartie de zéro) :
      // celui dont l'historique commence le plus tôt gagne, à égalité le premier de config.js
      let best = ok[0];
      if (r.kind !== "mean") for (const c of ok) if (firstOf(c.id) < firstOf(best.id)) best = c;
      FIELDS[r.f] = { id: best.id, key: best.key, alt: best.i > 0, late: best !== ok[0] ? { id: ok[0].id, key: ok[0].key, from: firstOf(ok[0].id) } : null };
    }
    META.status = "ok";
    seq++;
  }
  const fid = (f) => (FIELDS[f] ? FIELDS[f].id : null);
  // Les getters relancent les métadonnées (ou la couverture) après un échec (pause croissante, comme les morceaux)
  const metaOk = () => {
    if (META.status === "error") {
      const m = chunks.get("meta:all"), v = chunks.get("cov:all"), c = m && m.data ? v : m;
      if (!c || (!c.busy && !c.queued && Date.now() >= c.next)) { if (m && m.data) enqueue(chunk("cov", "all"), -1); else loadMeta(); }
    }
    return META.status === "ok";
  };
  const sumIds = () => [...new Set(SUMS.map(fid).filter(Boolean))];
  // Groupes : null tant que les métadonnées manquent ; économies sans statistique mais énergie complète : « est » (estimées)
  function has(g) {
    if (META.status !== "ok") return null;
    const all = GROUPS[g].every((f) => FIELDS[f]);
    if (g === "economies" && !all) return has("energie") ? "est" : false;
    return all;
  }

  /* ─── Couverture : depuis quand chaque compteur a des statistiques ────── */
  // Premier jour connu d'un champ : "0000-01-01" (depuis toujours), le jour de sa première ligne, "9999-12-31" (jamais),
  // null tant que la journée exacte n'est pas lue (le mois de sa première ligne, par jour)
  function knownFrom(f) {
    const id = fid(f);
    if (!id) return "9999-12-31";
    const fm = FIRST.get(id);
    if (fm == null) return null;
    if (fm === "none") return "9999-12-31";
    if (fm <= COV_REQ) return "0000-01-01";
    const D = need("d", fm, 1);
    if (!D.data) return null;
    const keys = D.data[f + "Raw"] ? [...D.data[f + "Raw"].keys()].sort() : [];
    return keys[0] || `${nextMonth(fm)}-01`;
  }
  // Pour ce qui est « solaire », une statistique née avant la mise en service couvre tout (0 avant les panneaux)
  const knownFromEff = (f) => { const k = knownFrom(f); return k != null && SOLAR_F.has(f) && k <= SOLAR0 ? "0000-01-01" : k; };
  // À partir de quand une page peut comparer « à l'identique » : énergie (et économies) dès la mise en service et dès que
  // chaque compteur existe ; voiture : dès que les deux compteurs de la borne existent
  function compareFrom(group) {
    if (META.status !== "ok") return null;
    let k = group === "voiture" ? "0000-01-01" : SOLAR0;
    const fs = group === "voiture" ? GROUPS.voiture : [...GROUPS.energie, ...(has("economies") === true ? ["savings"] : [])];
    for (const f of fs) {
      if (!FIELDS[f]) continue;
      const kf = group === "voiture" ? knownFromEff(f) : knownFrom(f);
      if (kf == null) return null;
      k = maxKey(k, kf);
    }
    return k;
  }
  // Premier jour où tous les compteurs d'énergie ont un historique (sous-titre « historique dès le … »)
  const coverStart = () => { let k = "0000-01-01"; for (const f of GROUPS.energie) { if (!FIELDS[f]) continue; const kf = knownFromEff(f); if (kf == null) return null; k = maxKey(k, kf); } return k; };
  // État d'un champ un jour donné : absent (pas de compteur), yes (statistiques), pre (pas de statistiques avant la mise en
  // service : 0, les panneaux n'étaient pas posés), no (pas encore de statistiques : inconnu) ; le jour précis du début se
  // lit dans le mois de la première ligne. Des statistiques qui existent avant la mise en service font foi
  function coverOf(f, k, D) {
    if (!FIELDS[f]) return "absent";
    const fm = FIRST.get(fid(f)), mk = monthOf(k);
    let c;
    if (fm == null) c = "yes";
    else if (fm === "none" || mk < fm) c = "no";
    else if (fm <= COV_REQ || mk > fm) c = "yes";
    else { const kf = D && D[f + "Raw"] ? [...D[f + "Raw"].keys()].sort()[0] : null; c = kf && k >= kf ? "yes" : "no"; }
    return c === "no" && SOLAR_F.has(f) && k < SOLAR0 ? "pre" : c;
  }

  /* ─── Cache par morceaux, file d'attente, rafraîchissement ─────────────
     Un morceau = un appel : meta (métadonnées), cov (première ligne de chaque compteur, par mois), h (un jour, par heure),
     t (un mois par heure : tarifs, économies estimées, pics), d (un mois par jour), s (aujourd'hui jusqu'à maintenant,
     un nombre), x (échantillon brut pour le diagnostic). Deux appels au plus en même temps. */
  const chunks = new Map(), queue = [];
  let seq = 0, order = 0, inflight = 0, paused = false, gen = 0, lastFetch = 0;
  const BACKOFF = [30e3, 120e3, 600e3];
  // Panneau quitté (page détachée) : on n'en redemande pas le rendu ; resume() et le retour du panneau le refont
  const notify = () => { if (paused) return; BZ.liveNotify(); loadingMark(); };
  const loadingMark = () => document.documentElement.toggleAttribute("data-hist-loading", inflight > 0 || queue.length > 0 || META.status === "loading");
  function chunk(fam, key) {
    const id = `${fam}:${key}`;
    let c = chunks.get(id);
    if (!c) { c = { id, fam, key, status: "idle", data: null, tries: 0, next: 0, at: 0, complete: false, queued: false, busy: false, prio: 9 }; chunks.set(id, c); }
    return c;
  }
  // Demandé par un getter (rendu en cours) : jamais bloquant ; un échec est retenté après une pause croissante
  function need(fam, key, prio = 0) {
    const c = chunk(fam, key);
    if (c.status === "idle" || (c.status === "error" && Date.now() >= c.next)) enqueue(c, prio);
    else if (c.queued && prio < c.prio) c.prio = prio;
    return c;
  }
  function enqueue(c, prio) {
    if (c.busy) { c.again = true; return; }
    if (c.queued) { c.prio = Math.min(c.prio, prio); return; }
    c.queued = true; c.prio = prio; c.order = order++;
    if (!c.data) c.status = "loading";
    queue.push(c);
    Promise.resolve().then(pump);
  }
  const withTimeout = (p, ms) => new Promise((resolve, reject) => {
    const t = setTimeout(() => reject({ code: "timeout", message: "Home Assistant n'a pas répondu" }), ms);
    p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
  function pump() {
    if (paused) return;
    queue.sort((a, b) => a.prio - b.prio || a.order - b.order);
    while (inflight < 2) {
      // Tout attend les métadonnées et la couverture (elles disent quels capteurs lire, et depuis quand)
      const i = queue.findIndex((c) => c.fam === "meta" || (c.fam === "cov" && META.list) || META.status === "ok");
      if (i < 0) break;
      const c = queue.splice(i, 1)[0], g = gen, t0 = Date.now();
      c.queued = false; c.busy = true; inflight++;
      withTimeout(load(c), 30000).then((data) => {
        if (g !== gen) return;
        c.data = data; c.status = "ok"; c.tries = 0; c.at = t0; c.err = null; lastFetch = Date.now();
        c.complete = c.end != null && c.end + 15 * 6e4 <= t0;   // fini d'écrire par HA quand on l'a lu : on ne le relira plus
        seq++;
        if (c.fam === "meta") afterMeta();
        if (c.fam === "cov") afterCov();
      }, (e) => {
        if (g !== gen) return;
        c.tries++; c.err = e; c.next = Date.now() + BACKOFF[Math.min(c.tries, BACKOFF.length) - 1];
        if (!c.data) c.status = "error";
        if (c.fam === "meta" || (c.fam === "cov" && META.status !== "ok")) META.status = "error";
        HA.noteError(`historique ${c.id}`, [], e);
        setTimeout(() => { if (c.status === "error" && !c.queued && !c.busy) { seq++; notify(); } }, c.next - Date.now() + 50);   // nouvel essai au prochain rendu
      }).finally(() => {
        c.busy = false; inflight--;   // appels réellement en cours chez HA, remise à zéro ou pas
        if (g !== gen) { pump(); return; }   // appel d'avant une remise à zéro : résultat oublié, place libérée
        if (c.again) { c.again = false; enqueue(c, c.prio); }
        pump(); notify();
      });
    }
    loadingMark();
  }

  /* ─── Les appels ──────────────────────────────────────────────────── */
  const ws = (msg) => HA.callWS(msg);
  const during = (ids, period, s, e, types) => (ids.length
    ? ws({ type: "recorder/statistics_during_period", start_time: iso(s), end_time: iso(e), statistic_ids: ids, period, types, units: { energy: "kWh" } })
    : Promise.resolve({}));
  const single = (id, extra) => ws({ type: "recorder/statistic_during_period", statistic_id: id, types: ["change"], units: { energy: "kWh" }, ...extra });
  // Champs lus heure par heure sur un mois : achat et recharge réseau (tarifs), production (forme de la journée) ;
  // économies estimées : aussi revente et batterie (prix de chaque heure)
  const tFields = () => (has("economies") === "est" ? ["prod", "imp", "exp", "chg", "dch", "evGrid"] : ["prod", "imp", "evGrid"]);
  function load(c) {
    const k = c.key;
    if (c.fam === "meta") {
      const ids = [...new Set(REG.flatMap((r) => candidates(r).map((x) => x.id)))];
      return ws({ type: "recorder/get_statistics_metadata", statistic_ids: ids });
    }
    if (c.fam === "cov") {
      // Tous les candidats valables (pas seulement les choisis) : le choix dépend de leur couverture
      const ids = [...new Set(REG.filter((r) => r.kind !== "mean").flatMap((r) => (OKC.get(r.f) || []).map((x) => x.id)))];
      const [y, m] = ymd(COV_REQ); c.end = 0;   // lue une fois (une nouvelle statistique se voit au rechargement)
      return during(ids, "month", TZ.at(y, m - 1, 1), Date.now(), ["change"]).then((r) => parseCov(r, ids));
    }
    if (c.fam === "h") { const s = dayStart(k), e = dayStart(addDays(k, 1)); c.end = e; return during([...sumIds(), fid("soc")].filter(Boolean), "hour", s, e, ["change", "mean"]).then((r) => parseHours(r, k, e + 15 * 6e4 <= Date.now())); }
    if (c.fam === "t") { const s = monthStart(k), e = monthStart(nextMonth(k)); c.end = e; return during([...new Set(tFields().map(fid).filter(Boolean))], "hour", s, e, ["change"]).then(parseMonthHours); }
    // Fin de requête juste avant minuit : HA arrondit à la case suivante (le dernier jour est compris ; le suivant non)
    if (c.fam === "d") { const s = monthStart(k), e = monthStart(nextMonth(k)); c.end = e; return during(sumIds(), "day", s, e - 1, ["change"]).then((r) => parseBuckets(r, (ms) => TZ.key(ms))); }
    if (c.fam === "s") { const [, f] = k.split("|"); return single(fid(f), { calendar: { period: "day" } }).then((r) => (r && Number.isFinite(r.change) ? Math.max(0, r.change) : null)); }
    // Échantillon brut du diagnostic : tous les types, pour voir la forme réelle des données (state, sum, change, mean)
    const ids = [...sumIds(), fid("soc")].filter(Boolean), tk = todayKey(), all = ["change", "sum", "state", "mean"];
    // Deux appels l'un après l'autre : le morceau n'occupe qu'une des deux places
    return during(ids, "hour", dayStart(tk), Date.now(), all)
      .then((hr) => during(ids, "day", dayStart(addDays(tk, -3)), dayStart(tk) - 1, all).then((dy) => ({ hourly_today: trim(hr, 4), daily_last3: trim(dy, 3) })));
  }
  const trim = (r, n) => Object.fromEntries(Object.entries(r || {}).map(([id, rows]) => [id, rows.slice(-n)]));

  /* ─── Lecture des réponses ────────────────────────────────────────── */
  const NEG = new Map(), SPIKES = new Map(), SUSPECT = new Map();
  // Plafonds : par heure (au-delà : pic écarté) et par jour (au-delà : on lit les heures du jour pour trouver le pic).
  // kWc lus dans les noms des onduleurs (« Izy 2 000 W ») ; illisibles : un plafond large
  const kwc = () => { const v = (C.onduleurs_noms || []).reduce((a, n) => a + (parseInt(String(n).replace(/\D/g, ""), 10) || 0), 0) / 1000; return v > 0 ? v : 12; };
  const CAPS = () => { const p = Math.max(40, 12 * kwc()); return { prod: p, exp: p, imp: 200, chg: 40, dch: 40, evSun: 120, evGrid: 120, ev: 120, savings: 50 }; };
  const CAPH = () => { const p = Math.max(3, 1.3 * kwc()); return { prod: p, exp: p, imp: 36, chg: 12, dch: 12, evSun: 22, evGrid: 22, savings: 10, impHp: 36, impHc: 36, impHsc: 36 }; };
  // Une journée d'un compteur, heure par heure : pic écarté (au-delà du plafond, rapporté aux heures écoulées depuis la
  // ligne d'avant : un rattrapage après une coupure de HA reste permis), variation négative ramenée à 0 et reprise sur les
  // heures suivantes ; journée terminée : ce qui n'a pas été repris est retiré des dernières heures (Σ = chiffre du jour)
  function cleanDay(rows, f, id, final, from) {
    const cap = CAPH()[f] || Infinity;
    let debt = 0, prev = from - HOUR;
    const out = rows.map((r) => {
      const raw = Number.isFinite(r.change) ? r.change : 0;
      let v = raw;
      if (v < 0) { NEG.set(`${id}@${r.start}`, { id, f, at: r.start, raw }); debt -= v; v = 0; }
      else {
        if (debt > 0) { const t = Math.min(v, debt); v -= t; debt -= t; }
        const allow = cap * Math.max(1, Math.round((r.start - prev) / HOUR));
        if (v > allow) { SPIKES.set(`${f}|${r.start}`, { f, id, at: r.start, k: TZ.key(r.start), raw, cut: v, cap: allow }); v = 0; }
      }
      prev = r.start;
      return { start: r.start, v, raw, mean: r.mean };
    });
    if (final) for (let i = out.length - 1; i >= 0 && debt > 1e-12; i--) { const t = Math.min(out[i].v, debt); out[i].v -= t; debt -= t; }
    return out;
  }
  // Quantité écartée (pics) d'un champ sur une journée
  const spikeSum = (f, k) => { let s = 0; SPIKES.forEach((x) => { if (x.f === f && x.k === k) s += x.cut; }); return s; };
  const sortRows = (res, id) => (res && res[id] ? res[id].filter((r) => Number.isFinite(r.start)).sort((a, b) => a.start - b.start) : null);
  // Un jour par heure : 24 cases en heure locale de HA (la 2 h doublée en octobre est additionnée, absente en mars)
  function parseHours(res, k, final) {
    const slots = {}, rows = {};
    for (const f of [...SUMS, "soc"]) {
      if (f === "soc") {
        const id = fid("soc"), list = id && res[id] ? res[id].filter((r) => Number.isFinite(r.mean)) : [];
        const acc = H24.map(() => []); list.forEach((r) => acc[TZ.parts(r.start).h].push(r.mean));
        slots.soc = acc.map((a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN));
        continue;
      }
      const id = fid(f), list = sortRows(res, id); if (!list) continue;
      const s = cleanDay(list, f, id, final, dayStart(k));
      rows[f] = s;
      const a = new Float64Array(24), raw = new Float64Array(24);
      s.forEach((r) => { const h = TZ.parts(r.start).h; a[h] += r.v; raw[h] += r.raw; });
      slots[f] = a; slots[f + "Raw"] = raw;
    }
    // Heure écrite = au moins une ligne d'un compteur d'énergie (production d'abord)
    const ref = rows.prod || rows.imp || Object.values(rows)[0] || [];
    const cnt = new Int8Array(24); ref.forEach((r) => { cnt[TZ.parts(r.start).h]++; });
    return { key: k, slots, n: cnt, rows };
  }
  // Un mois par heure : par jour, 24 cases par champ (répartition par tarif, économies estimées, forme de la production)
  function parseMonthHours(res) {
    const days = new Map(), rows = {}, now = Date.now();
    for (const f of tFields()) {
      const id = fid(f), list = sortRows(res, id); if (!list) continue;
      const byDay = new Map();
      list.forEach((r) => { const k = TZ.key(r.start); if (!byDay.has(k)) byDay.set(k, []); byDay.get(k).push(r); });
      rows[f] = [];
      byDay.forEach((dr, k) => {
        const s = cleanDay(dr, f, id, dayStart(addDays(k, 1)) + 15 * 6e4 <= now, dayStart(k));
        rows[f].push(...s);
        if (!days.has(k)) days.set(k, {});
        const d = days.get(k), a = (d[f] = d[f] || new Float64Array(24));
        s.forEach((r) => { a[TZ.parts(r.start).h] += r.v; });
      });
    }
    return { days, rows };
  }
  // Jours : champ → Map(clé → valeur), et la valeur brute (contrôle C2) ; une journée négative (compteur corrigé) est
  // ramenée à 0 et reprise sur les suivantes du mois
  function parseBuckets(res, keyOf) {
    const out = {};
    for (const f of SUMS) {
      const id = fid(f), list = sortRows(res, id); if (!list) continue;
      const m = new Map(), raw = new Map();
      let debt = 0;
      list.forEach((r) => {
        const k = keyOf(r.start), rv = Number.isFinite(r.change) ? r.change : 0;
        let v = rv;
        if (v < 0) { NEG.set(`${id}@${r.start}`, { id, f, at: r.start, raw: rv, day: true }); debt -= v; v = 0; }
        else if (debt > 0) { const t = Math.min(v, debt); v -= t; debt -= t; }
        m.set(k, (m.get(k) || 0) + v); raw.set(k, (raw.get(k) || 0) + rv);
      });
      out[f] = m; out[f + "Raw"] = raw;
    }
    return out;
  }
  // Couverture : mois de la première ligne de chaque statistique, et les lignes mensuelles brutes
  function parseCov(res, ids) {
    const first = new Map(), rows = new Map();
    for (const id of ids) {
      const list = sortRows(res, id);
      if (!list || !list.length) { first.set(id, "none"); continue; }
      first.set(id, TZ.key(list[0].start).slice(0, 7));
      rows.set(id, new Map(list.map((r) => [TZ.key(r.start).slice(0, 7), Number.isFinite(r.change) ? r.change : 0])));
    }
    return { first, rows };
  }

  /* ─── Construction des journées ───────────────────────────────────── */
  const NUM = ["prod", "cons", "self", "chg", "dch", "imp", "exp", "hp", "hc", "hsc", "ev", "evSun", "evGrid", "evHp", "evHc", "evHsc", "savings"];
  const blank = (extra) => NUM.reduce((o, f) => ((o[f] = NaN), o), { ...extra });
  const tariffAt = (h) => BZ.tariffAt(h);
  const derive = (o) => {
    o.cons = Math.max(0, o.prod - o.exp + o.imp - o.chg + o.dch);
    o.self = Math.max(0, o.prod - o.exp - o.chg);
    return o;
  };
  // Économies sans statistique : estimées heure par heure (soleil direct et batterie au prix du tarif de cette heure,
  // surplus au prix de revente) ; sans les heures, au prix des heures pleines (dit comme tel)
  const resale = () => Number(C.prix_revente_kwh) || 0;
  const estHour = (x, h) => (Math.max(0, x.prod - x.exp - x.chg) + x.dch) * BZ.TARIFS[tariffAt(h)].price() + x.exp * resale();
  const estimate = (o) => (o.self + o.dch) * BZ.TARIFS.hp.price() + o.exp * resale();
  const estSlots = (S, w = () => 1) => {
    if (!S || !S.prod || !S.exp || !S.chg || !S.dch) return NaN;
    return H24.reduce((a, h) => a + (w(h) ? estHour({ prod: S.prod[h] * w(h), exp: S.exp[h] * w(h), chg: S.chg[h] * w(h), dch: S.dch[h] * w(h) }, h) : 0), 0);
  };
  const absentList = () => ["energie", "voiture"].filter((g) => has(g) === false);
  const hData = (k) => { const c = chunks.get(`h:${k}`); return c && c.data ? c.data : null; };
  // Achat (et recharge réseau) par tarif d'un jour passé : compteurs à tarifs s'ils collent à l'achat du jour, sinon heure par heure
  function splitOf(k, imp, D, ev) {
    const o = { hp: NaN, hc: NaN, hsc: NaN, evHp: NaN, evHc: NaN, evHsc: NaN, splitLoading: false };
    const hd = hData(k);
    let hrs = hd ? hd.slots : null;
    const tarif = has("tarifs") && D && D.impHp && D.impHp.has(k) && D.impHc.has(k) && D.impHsc.has(k) ? [D.impHp.get(k), D.impHc.get(k), D.impHsc.get(k)] : null;
    const tarifOk = tarif && Math.abs(tarif[0] + tarif[1] + tarif[2] - imp) <= Math.max(0.05, 0.02 * imp);
    const needEv = ev && has("voiture") === true, needImp = Number.isFinite(imp) && !tarifOk;
    if (!hrs && (needImp || needEv)) {
      const T = need("t", monthOf(k), 1);
      if (T.data) hrs = T.data.days.get(k) || {}; else { o.splitLoading = !T.err; o.splitError = !!T.err; }
    }
    if (tarifOk) [o.hp, o.hc, o.hsc] = tarif;
    else if (hrs && Number.isFinite(imp)) { o.hp = o.hc = o.hsc = 0; if (hrs.imp) H24.forEach((h) => { o[tariffAt(h)] += hrs.imp[h]; }); }
    if (!needEv) return o;
    if (hrs) { o.evHp = o.evHc = o.evHsc = 0; if (hrs.evGrid) H24.forEach((h) => { o["ev" + cap(tariffAt(h))] += hrs.evGrid[h]; }); }
    return o;
  }
  const cap = (s) => s[0].toUpperCase() + s.slice(1);
  const memo = new Map();
  function dayRow(date) {
    const k = typeof date === "string" ? date : pageKey(date), tk = todayKey(), d = typeof date === "string" ? dayDate(date) : date;
    if (k === tk) return todayRow(d);
    if (k > tk) return blank({ date: d });
    const m = memo.get(k);
    if (m && m.seq === seq) { touch(k, m.row); return { ...m.row, date: d }; }
    const row = buildDay(k);
    memo.set(k, { seq, row });
    return { ...row, date: d };
  }
  // Les morceaux que lit une journée mémorisée sont redemandés (relance après un échec, rafraîchissement)
  const touch = (k, row) => { if (!row.nocovAll) need("d", monthOf(k), 0); };
  // Les compteurs d'une journée passée, tels que lus (par jour), sans répartition par tarif : couverture de chaque champ,
  // pics écartés, journée invraisemblable (au-delà du plafond du jour : ses heures sont lues pour trouver l'heure du pic ;
  // si la journée reste invraisemblable sans elle, elle est écartée). null tant qu'un morceau manque (wait)
  const bases = new Map();
  function dayBase(k) {
    const m = bases.get(k);
    if (m && m.seq === seq) return m.b;
    const b = dayBase0(k);
    bases.set(k, { seq, b });
    return b;
  }
  function dayBase0(k) {
    const mk = monthOf(k);
    // Rien de lisible ce jour-là (avant tous les compteurs) : pas d'appel
    const any = DAYF.some((f) => FIELDS[f] && mk >= firstOf(fid(f)));
    let D = null;
    if (any) {
      const Dc = need("d", mk, 0);
      D = Dc.data;
      if (!D) return { wait: Dc.err ? { error: true } : { loading: true } };
    }
    const o = {}, st = {};
    let gap = false, nocov = false, wait = false;
    for (const f of DAYF) {
      st[f] = coverOf(f, k, D);
      if (st[f] === "absent") { o[f] = NaN; continue; }
      if (st[f] === "pre") { o[f] = 0; continue; }
      if (st[f] === "no") { o[f] = NaN; nocov = true; continue; }
      const v = D[f] ? D[f].get(k) : undefined;
      if (v == null) { o[f] = 0; if (GROUPS.energie.includes(f)) gap = true; continue; }   // aucune ligne ce jour-là (HA arrêté)
      o[f] = v - spikeSum(f, k);
      const capD = CAPS()[f];
      if (o[f] > capD) {
        const hc = need("h", k, 0);
        if (!hc.data && !hc.err) wait = true;
        else { SUSPECT.set(`${k}:${f}`, { key: k, f, raw: o[f], cap: capD }); o[f] = 0; o.suspect = true; }   // même sans le pic, trop : écartée
      }
    }
    if (wait) return { wait: { loading: true } };
    if (o.evSun + o.evGrid > CAPS().ev) { SUSPECT.set(`${k}:ev`, { key: k, f: "ev", raw: o.evSun + o.evGrid, cap: CAPS().ev }); o.evSun = o.evGrid = 0; o.suspect = true; }
    return { o, st, D, any, gap, nocov };
  }
  function buildDay(k) {
    if (!metaOk()) return blank(META.status === "error" ? { error: true } : { loading: true });
    const absent = absentList();
    if (has("energie") === false) return blank({ absent });
    const B = dayBase(k);
    if (B.wait) return blank(B.wait);
    const { st, D, any, gap, nocov } = B, o = { ...B.o };
    if (has("voiture") !== true) o.evSun = o.evGrid = NaN;
    Object.assign(o, splitOf(k, o.imp, D, st.evGrid === "yes"));
    if (st.evGrid === "pre" || st.evGrid === "no") o.evHp = o.evHc = o.evHsc = st.evGrid === "no" ? NaN : 0;
    if (o.suspect && o.evSun === 0 && o.evGrid === 0) o.evHp = o.evHc = o.evHsc = 0;
    derive(o);
    o.ev = o.evSun + o.evGrid;
    const eco = has("economies");
    if (eco === "est") Object.assign(o, estDay(k, o, st.prod === "pre"));
    else if (eco !== true) o.savings = NaN;
    if (gap) o.gap = true;
    if (nocov) { o.nocov = true; if (!any) o.nocovAll = true; }
    if (st.prod === "pre") o.pre = true;
    if (absent.length) o.absent = absent;
    return o;
  }
  // Économies estimées d'un jour passé : ses heures (lues pour le jour, ou celles du mois) au prix de chaque heure
  function estDay(k, o, pre) {
    if (pre) return { savings: 0, est: true };
    if (!Number.isFinite(o.prod + o.exp + o.chg + o.dch)) return { savings: NaN, est: true };
    const hd = hData(k);
    let S = hd ? hd.slots : null;
    if (!S) { const T = need("t", monthOf(k), 1); if (T.data) S = T.data.days.get(k) || null; else if (!T.err) return { savings: NaN, est: true, splitLoading: true }; }
    const v = estSlots(S);
    return Number.isFinite(v) ? { savings: v, est: true } : { savings: estimate(o), est: true, estHp: true };
  }

  /* ─── Aujourd'hui ─────────────────────────────────────────────────── */
  // Heures déjà écrites par HA + reste du compteur du jour en direct (heure en cours, ou l'heure d'avant si HA ne l'a pas
  // encore écrite : sa ligne arrive vers HH:00:10). Le reste est inconnu (pas d'heure inventée) quand le compteur n'a pas
  // de statistiques, quand elles ne commencent qu'aujourd'hui, ou quand HA n'écrit plus les heures depuis un moment
  function todayParts() {
    const now = Date.now(), p = TZ.parts(now), cur = p.h, k = todayKey();
    const c = need("h", k, 0), T = BZ.today();
    const live = { prod: T.prod, imp: T.imp, exp: T.exp, chg: T.chg, dch: T.dch, savings: T.savings,
      evSun: has("voiture") === true ? todaySoFar("evSun") : NaN, evGrid: has("voiture") === true ? todaySoFar("evGrid") : NaN };
    if (!c.data) return { k, cur, p, T, live, ok: false, err: !!c.err };
    const n = c.data.n, S = c.data.slots;
    const lag = cur > 0 && !n[cur - 1] && p.mi < 12;
    const remSlot = lag ? cur - 1 : cur;
    const stale = remSlot > 0 && !n[remSlot - 1] && !dstSkipped(k, remSlot - 1);
    const done = {}, rem = {};
    for (const f of Object.keys(live)) {
      const s = S[f]; done[f] = s ? H24.reduce((a, h) => a + (h < cur ? s[h] : 0), 0) : 0;
      // Capteur du jour arrondi (ou en retard de quelques minutes) un peu sous les heures écrites : les heures font foi,
      // la somme des cases reste le chiffre du jour. Écart plus grand : le capteur est gardé et le contrôle C1 le signale
      if (Number.isFinite(live[f]) && live[f] < done[f] && done[f] - live[f] <= tolC1(f, live[f])) live[f] = done[f];
      const startsToday = FIELDS[f] && FIRST.get(fid(f)) === monthOf(k) && knownFrom(f) === k;
      rem[f] = Number.isFinite(live[f]) && s && !startsToday && !stale ? Math.max(0, live[f] - done[f]) : NaN;
    }
    if (lag && !c.lagTimer) {   // l'heure d'avant n'est pas encore écrite : on la relit dans une et dans six minutes
      c.lagTimer = true;
      [6e4, 36e4].forEach((ms) => setTimeout(() => { c.lagTimer = false; enqueue(c, 1); }, ms));
    }
    return { k, cur, p, T, live, ok: true, n, S, lag, remSlot, done, rem };
  }
  function todayRow(date) {
    const P = todayParts(), L = P.live;
    const o = { date, prod: L.prod, imp: L.imp, exp: L.exp, chg: L.chg, dch: L.dch, savings: L.savings, partial: true };
    o.cons = o.prod - o.exp + o.imp - o.chg + o.dch; o.self = Math.max(0, o.prod - o.exp - o.chg);   // même calcul que BZ.today()
    const eco = has("economies");
    if (!Number.isFinite(o.savings) && eco === "est") {
      o.est = true;
      // Heures écrites au prix de leur heure, plus le reste de l'heure en cours au prix de cette heure
      if (P.ok && P.S.prod && P.S.exp && P.S.chg && P.S.dch) {
        const r = P.rem, done = estSlots(P.S, (h) => (h < P.cur ? 1 : 0)), more = estHour({ prod: r.prod, exp: r.exp, chg: r.chg, dch: r.dch }, P.remSlot);
        o.savings = done + (Number.isFinite(more) ? more : 0);
        if (!Number.isFinite(o.savings)) { o.savings = estimate(o); o.estHp = true; }
      } else if (P.ok || P.err) { o.savings = estimate(o); o.estHp = true; } else o.savings = NaN;
    }
    o.evSun = P.live.evSun; o.evGrid = P.live.evGrid; o.ev = o.evSun + o.evGrid;
    if (has("voiture") === false) o.absent = ["voiture"];
    Object.assign(o, { hp: NaN, hc: NaN, hsc: NaN, evHp: NaN, evHc: NaN, evHsc: NaN });
    if (P.ok) {
      const sp = { hp: 0, hc: 0, hsc: 0, evHp: 0, evHc: 0, evHsc: 0 }, kRem = tariffAt(P.remSlot);
      H24.forEach((h) => { if (h >= P.cur) return; const k = tariffAt(h); if (P.S.imp) sp[k] += P.S.imp[h]; if (P.S.evGrid) sp["ev" + cap(k)] += P.S.evGrid[h]; });
      sp[kRem] += P.rem.imp; sp["ev" + cap(kRem)] += P.rem.evGrid;
      Object.assign(o, sp);
      if (has("voiture") !== true) o.evHp = o.evHc = o.evHsc = NaN;
    } else o.splitLoading = !P.err;
    // En attente : l'achat par tarif (heures du jour, splitLoading) ; la voiture (nombre « jusqu'à maintenant », evLoading)
    if (has("voiture") === true && !Number.isFinite(o.ev)) o.evLoading = true;
    if (META.status !== "ok" && META.status !== "error") o.loading = true;
    return o;
  }
  // Prévision de l'heure : Solcast heure par heure si l'attribut existe, sinon le reste prévu du jour réparti
  // comme la production des 7 derniers jours (étiquetée estimation), sinon rien
  function hourlyForecast(P) {
    const fc = new Float64Array(24), id = C.prevision_jour_kwh, a = id ? BZ.attr(id, "detailedHourly") || BZ.attr(id, "detailedForecast") : null;
    if (Array.isArray(a) && a.length) {
      const ts = a.map((x) => Date.parse(x.period_start)).filter(Number.isFinite), step = ts.length > 1 ? Math.max(0.25, Math.min(1, (ts[1] - ts[0]) / HOUR)) : 1;
      a.forEach((x) => { const t = Date.parse(x.period_start), v = Number(x.pv_estimate); if (Number.isFinite(t) && Number.isFinite(v) && TZ.key(t) === P.k) fc[TZ.parts(t).h] += v * step; });
      return { fc, est: false };
    }
    const left = Math.max(0, (Number.isFinite(P.T.forecast) ? P.T.forecast : 0) - (P.ok ? P.done.prod : 0));
    if (!(left > 0)) return { fc, est: false };
    const shape = new Float64Array(24);
    for (let i = 1; i <= 7; i++) {
      const k = addDays(P.k, -i), hd = hData(k);
      const day = hd ? hd.slots : (() => { const t = need("t", monthOf(k), 2); return t.data ? t.data.days.get(k) : null; })();
      if (day && day.prod) H24.forEach((h) => { shape[h] += day.prod[h]; });
    }
    const w = H24.reduce((s, h) => s + (h >= P.cur ? shape[h] : 0), 0);
    if (w > 0) H24.forEach((h) => { if (h >= P.cur) fc[h] = (left * shape[h]) / w; });
    return { fc, est: w > 0 };
  }
  const slotOf = (h, extra) => ({ h, label: `${h}h`, tariff: tariffAt(h), ...extra });
  // Une heure écrite par HA : compteurs de l'heure, conso et soleil direct déduits, niveau moyen de la batterie
  // (st : couverture du jour ; avant les panneaux, production et batterie à 0 ; avant un compteur, inconnu)
  function filled(S, h, n, extra, st) {
    const o = slotOf(h, extra);
    for (const f of DAYF) o[f] = st && st[f] === "pre" ? 0 : st && (st[f] === "no" || st[f] === "absent") ? NaN : S[f] ? S[f][h] : NaN;
    const eco = has("economies");
    if (eco !== true) o.savings = eco === "est" ? (st && st.prod === "pre" ? 0 : estHour(o, h)) : NaN;
    derive(o);
    if (!Number.isFinite(o.cons)) o.cons = null;
    o.soc = S.soc ? S.soc[h] : NaN;
    if (n > 1) o.dst = "double";
    return o;
  }
  function hours() {
    const P = todayParts(), { fc, est } = hourlyForecast(P);
    if (!P.ok) return H24.map((h) => slotOf(h, { future: h > P.cur, current: h === P.cur, prod: h > P.cur ? fc[h] : NaN, cons: null, fc: fc[h], fcEst: est || undefined, loading: !P.err, error: P.err || undefined }));
    return H24.map((h) => {
      const base = { future: h > P.cur, current: h === P.cur };
      if (h > P.cur) return slotOf(h, { ...base, prod: fc[h], cons: null, fc: fc[h], fcEst: est || undefined });
      if (h === P.remSlot) {
        const o = slotOf(h, { ...base, partial: true, fc: h === P.cur ? fc[h] : undefined });
        for (const f of DAYF) o[f] = P.rem[f];
        if (has("economies") === "est" && !Number.isFinite(o.savings)) o.savings = estHour(o, h);
        derive(o);
        if (!Number.isFinite(o.prod)) { o.prod = 0; o.cons = null; o.unknown = true; }
        else if (!Number.isFinite(o.cons)) o.cons = null;
        o.soc = NaN;
        return o;
      }
      if (h === P.cur) return slotOf(h, { ...base, partial: true, prod: 0, cons: 0, imp: 0, exp: 0, chg: 0, dch: 0, savings: 0, fc: fc[h] });   // l'heure d'avant est encore en cours d'écriture
      if (!P.n[h]) return slotOf(h, { ...base, prod: 0, cons: null, gap: true, dst: dstSkipped(P.k, h) ? "skipped" : undefined });
      return filled(P.S, h, P.n[h], base);
    });
  }
  // Heure locale qui n'existe pas (passage à l'heure d'été)
  const dstSkipped = (k, h) => { const [y, m, d] = ymd(k), t = TZ.at(y, m - 1, d, h); return TZ.parts(t).h !== h; };
  // Couverture de chaque champ un jour passé (le mois de la première ligne d'un compteur se lit par jour)
  function coverDay(k) {
    const mk = monthOf(k), late = DAYF.some((f) => FIELDS[f] && FIRST.get(fid(f)) === mk);
    const D = late ? need("d", mk, 0) : null;
    if (late && !D.data) return null;
    const st = {}; DAYF.forEach((f) => { st[f] = coverOf(f, k, D && D.data); });
    return st;
  }
  const covered = (st) => DAYF.some((f) => st[f] === "yes");
  function hoursOf(date) {
    const k = pageKey(date);
    if (k === todayKey()) return hours();
    const wait = (err) => H24.map((h) => slotOf(h, { prod: NaN, cons: null, loading: !err, error: err || undefined }));
    if (!metaOk()) return wait(META.status === "error");
    const st = coverDay(k);
    if (!st) return wait(false);
    if (!covered(st)) return H24.map((h) => slotOf(h, { prod: 0, cons: null, pre: st.prod === "pre" || undefined, nocov: true }));
    const c = need("h", k, 0);
    if (!c.data) return wait(!!c.err);
    return H24.map((h) => (c.data.n[h] ? filled(c.data.slots, h, c.data.n[h], {}, st) : slotOf(h, { prod: 0, cons: null, gap: true, dst: dstSkipped(k, h) ? "skipped" : undefined })));
  }
  // Une journée passée arrêtée à l'heure H (décimale, heure de HA) : heures entières avant H, plus la part de l'heure entamée
  function cut(date, H) {
    const k = typeof date === "string" ? date : pageKey(date), d = typeof date === "string" ? dayDate(date) : date;
    if (!metaOk()) return blank({ date: d, loading: META.status !== "error", error: META.status === "error" || undefined });
    if (has("energie") === false) return blank({ date: d, absent: absentList() });
    const st = coverDay(k);
    if (!st) return blank({ date: d, loading: true });
    const pre = st.prod === "pre";
    if (!covered(st)) return Object.assign(blank({ date: d, nocov: true, nocovAll: true }), pre ? { prod: 0, exp: 0, chg: 0, dch: 0, self: 0, savings: 0, evSun: 0, pre: true } : {});
    const c = need("h", k, 0);
    if (!c.data) return blank({ date: d, loading: !c.err, error: !!c.err || undefined });
    const S = c.data.slots, hh = Math.floor(H), fr = H - hh, w = (h) => (h < hh ? 1 : h === hh ? fr : 0);
    const o = { date: d, hp: 0, hc: 0, hsc: 0, evHp: 0, evHc: 0, evHsc: 0 };
    let nocov = false;
    for (const f of DAYF) {
      if (st[f] === "pre") o[f] = 0;
      else if (st[f] === "no" || st[f] === "absent") { o[f] = NaN; if (st[f] === "no") nocov = true; }
      else o[f] = S[f] ? H24.reduce((a, h) => a + S[f][h] * w(h), 0) : 0;
    }
    H24.forEach((h) => { const t = tariffAt(h); if (S.imp) o[t] += S.imp[h] * w(h); if (S.evGrid) o["ev" + cap(t)] += S.evGrid[h] * w(h); });
    if (!Number.isFinite(o.imp)) o.hp = o.hc = o.hsc = NaN;
    derive(o);
    if (has("voiture") !== true || st.evGrid === "no") o.evSun = o.evGrid = o.evHp = o.evHc = o.evHsc = NaN;
    o.ev = o.evSun + o.evGrid;
    const eco = has("economies");
    if (eco === "est") { o.savings = pre ? 0 : estSlots(S, w); o.est = true; } else if (eco !== true) o.savings = NaN;
    if (nocov) o.nocov = true;
    if (pre) o.pre = true;
    return o;
  }

  /* ─── Mois, années, périodes ──────────────────────────────────────── */
  // Somme de journées. Inconnu (en chargement) = inconnu ; un jour sans historique (avant un compteur) n'est pas compté
  // (et le compte des jours manquants suit) ; un champ inconnu tous les jours reste inconnu
  function sumRows(rows) {
    const o = {};
    for (const f of NUM) {
      let s = 0, seen = false, unknown = false;
      for (const x of rows) {
        const v = x[f];
        if (v == null) { seen = true; continue; }
        if (Number.isFinite(v)) { s += v; seen = true; } else if (!x.nocov) unknown = true;
      }
      o[f] = unknown ? NaN : seen ? s : rows.length ? NaN : 0;
    }
    o.loading = rows.some((x) => x.loading); o.error = rows.some((x) => x.error); o.est = rows.some((x) => x.est); o.estHp = rows.some((x) => x.estHp);
    o.gaps = rows.reduce((a, x) => a + (x.gap ? 1 : x.gaps || 0), 0);
    o.nocov = rows.reduce((a, x) => a + (x.nocovDays != null ? x.nocovDays : x.nocov ? 1 : 0), 0);
    o.splitLoading = rows.some((x) => x.splitLoading);
    o.suspect = rows.some((x) => x.suspect);
    if (rows.length && rows.every((x) => x.pre)) o.pre = true;
    const ab = [...new Set(rows.flatMap((x) => x.absent || []))]; if (ab.length) o.absent = ab;
    return o;
  }
  const finish = (o) => { if (o.nocov) { o.nocovDays = o.nocov; o.nocov = true; } else delete o.nocov; return o; };
  // Mois m (0-11) de l'année y : la somme de ses journées (jusqu'à lastDay, ou aujourd'hui pour le mois en cours)
  function monthSum(y, m, lastDay) {
    const mk = `${y}-${pad(m + 1)}`, tk = todayKey(), cm = monthOf(tk);
    if (mk > cm) return blank({});
    const last = lastDay != null ? Math.min(lastDay, daysIn(mk)) : mk === cm ? +tk.slice(8) : daysIn(mk);
    return finish(sumRows(Array.from({ length: last }, (_, i) => dayRow(`${mk}-${pad(i + 1)}`))));
  }
  // Journées de a à b (clés comprises) ; H : la dernière journée arrêtée à cette heure (aujourd'hui l'est déjà)
  function span(a, b, H) {
    const rows = [];
    for (let k = a; k <= b; k = addDays(k, 1)) rows.push(H != null && k === b && k !== todayKey() ? cut(k, H) : dayRow(k));
    return finish(sumRows(rows));
  }
  // Une période et celle d'avant, à l'identique : seulement ce qui est connu des deux côtés (panneaux posés, compteurs
  // existants), même durée, la période d'avant arrêtée à la même heure quand la période en cours finit maintenant.
  //  shift(clé d'avant) → clé de la période en cours au même rang
  function like({ a, b, pa, pb, live, group = "energie", shift }) {
    const cf = compareFrom(group);
    if (cf == null) return { loading: true, prevTotal: blank({ loading: true }), cmpTotal: null };
    if (pb < cf) return { none: true, from: cf, before: pb < SOLAR0 && group !== "voiture", prevTotal: blank({}), cmpTotal: null };
    const pa2 = pa < cf ? cf : pa, a2 = pa2 === pa ? a : shift(pa2);
    const prevTotal = span(pa2, pb, live ? nowH() : null);
    return { prevTotal, cmpTotal: a2 === a ? null : span(a2, b), partial: pa2 !== pa, from: a2, pfrom: pa2 };
  }
  // Décalages usuels d'une période à la précédente (jours ; même jour du mois ; même jour de l'année)
  const shifts = {
    days: (n) => (k) => addDays(k, n),
    month: (mk) => (k) => `${mk}-${pad(Math.min(+k.slice(8), daysIn(mk)))}`,
    year: (y) => (k) => { const mm = k.slice(5, 7); return `${y}-${mm}-${pad(Math.min(+k.slice(8), daysIn(`${y}-${mm}`)))}`; },
  };

  /* ─── Voiture, économies, prévisions ──────────────────────────────── */
  // Recharge réseau par tarif entre deux instants (séance en cours) : heures écrites + reste du jour à l'heure en cours
  function evSplitBetween(from, to) {
    const o = { evHp: NaN, evHc: NaN, evHsc: NaN };
    if (!Number.isFinite(from) || !Number.isFinite(to) || has("voiture") !== true || to - from > 7 * DAY) return o;
    const sp = { evHp: 0, evHc: 0, evHsc: 0 }, from0 = from - (from % HOUR + HOUR) % HOUR, tk = todayKey();
    for (let k = TZ.key(from); k <= TZ.key(to); k = addDays(k, 1)) {
      const c = need("h", k, 1);
      if (!c.data) return o;
      (c.data.rows.evGrid || []).forEach((r) => { if (r.start >= from0 && r.start < to) sp["ev" + cap(tariffAt(TZ.parts(r.start).h))] += r.v; });
    }
    if (TZ.key(to) === tk) {
      const P = todayParts();
      if (!P.ok || !Number.isFinite(P.rem.evGrid)) return o;
      sp["ev" + cap(tariffAt(P.remSlot))] += P.rem.evGrid;
    }
    return sp;
  }
  // Aujourd'hui jusqu'à maintenant (statistique « un seul nombre », précise à 5 min) : voiture, ou compteur du jour indisponible
  function todaySoFar(f) {
    if (!metaOk() || !fid(f)) return NaN;
    const c = need("s", `${todayKey()}|${f}`, 0);
    return c.data != null ? c.data : NaN;
  }
  // Économies sur 365 jours / depuis le 1er janvier, sur les journées connues seulement (pics écartés) :
  // { v, from (premier jour compté), days (jours comptés depuis la mise en service), full (fenêtre entière connue) }
  function savingsWindow(w) {
    const eco = has("economies");
    if (eco !== true && eco !== "est") return { v: NaN };
    const tk = todayKey(), from0 = w === "ytd" ? `${tk.slice(0, 4)}-01-01` : addDays(tk, -364);
    let kf = "0000-01-01";
    for (const f of eco === true ? ["savings"] : ["prod", "exp", "chg", "dch"]) { const k = knownFromEff(f); if (k == null) return { v: NaN, loading: true }; kf = maxKey(kf, k); }
    if (kf > tk) return { v: NaN };
    const from = maxKey(from0, kf);
    // Statistique d'économies : ses journées seulement (pas besoin de la répartition par tarif) ; estimées : les journées entières
    let r;
    if (eco === true) {
      if (!metaOk()) return { v: NaN, loading: true };
      let v = 0, loading = false, error = false;
      for (let k = from; k <= tk; k = addDays(k, 1)) {
        const x = k === tk ? todayRow(dayDate(k)) : dayBase(k), o = x.o || x;
        if (x.wait) { loading = loading || !!x.wait.loading; error = error || !!x.wait.error; continue; }
        if (Number.isFinite(o.savings)) v += o.savings; else if (!(x.st && x.st.savings === "no")) loading = true;
      }
      r = { savings: v, loading, error };
    } else r = span(from, tk);
    if (r.loading || r.error) return { v: NaN, loading: !!r.loading };
    const live = maxKey(from, SOLAR0);   // avant la mise en service : 0 connu, mais pas des jours « de rendement »
    return { v: r.savings, from, full: from === from0, days: live > tk ? 0 : dayNum(tk) - dayNum(live) + 1 };
  }
  // Jours suivants : capteurs de prévision de config.js (demain, jour 3…) ; au-delà, rien d'inventé
  function forecastDay(date) {
    const ids = Array.isArray(C.prevision_jours_kwh) ? C.prevision_jours_kwh : [], n = dayNum(pageKey(date)) - dayNum(todayKey());
    const v = n >= 1 && n <= ids.length ? BZ.num(ids[n - 1]) : NaN;
    return { date, prod: Number.isFinite(v) ? Math.max(0, v) : 0, forecast: true };
  }
  // Énergie : la journée heure par heure (heures écrites), niveau de batterie moyen de chaque heure + direct au bout
  function dayModel() {
    const P = todayParts(), soc = BZ.num(C.batterie_soc), H = P.cur + P.p.mi / 60 + P.p.s / 3600;
    const X = (t) => (H > 0 ? BZ.clamp(t / H, 0, 1) : 0), out = { prod: [], net: [], soc: [] };
    if (P.ok) H24.forEach((h) => {
      if (h >= P.cur || !P.n[h]) return;
      const S = P.S, x = X(h + 0.5);
      if (S.prod) out.prod.push([x, S.prod[h]]);
      if (S.exp && S.imp) out.net.push([x, S.exp[h] - S.imp[h]]);
      if (S.soc && Number.isFinite(S.soc[h])) out.soc.push([x, S.soc[h]]);
    });
    if (Number.isFinite(soc)) out.soc.push([1, soc]);
    return out;
  }

  /* ─── Contrôles de cohérence (C1 à C4) ─────────────────────────────── */
  const kw = (f) => (f === "savings" ? "€" : "kWh");
  function tolC1(f, live) { return f === "savings" ? 0.1 : Math.max(0.2, 0.03 * live); }
  const LBL = { prod: "Production", imp: "Achat réseau", exp: "Revente", chg: "Charge batterie", dch: "Décharge batterie", evSun: "Recharge solaire", evGrid: "Recharge réseau", savings: "Économies", impHp: "Achat HP", impHc: "Achat HC", impHsc: "Achat HSC", ev: "Recharge" };
  const fmt2 = (v, f) => `${BZ.fmt.n(v, 2)} ${kw(f)}`;
  // Compteur du jour en direct, en kWh (un compteur en Wh est converti) ; économies en €
  const liveOf = (f) => (f === "savings" ? BZ.num(C[LIVE_KEY[f]]) : BZ.energy(C[LIVE_KEY[f]]));
  function checks() {
    const out = [], tk = todayKey();
    // C1 : aujourd'hui, les heures écrites ne dépassent pas le compteur du jour en direct
    const h = chunks.get(`h:${tk}`), cur = TZ.parts(Date.now()).h;
    if (h && h.data) for (const f of Object.keys(LIVE_KEY)) {
      const live = liveOf(f), s = h.data.slots[f];
      if (!Number.isFinite(live) || !s) continue;
      const done = H24.reduce((a, x) => a + (x < cur ? s[x] : 0), 0), tol = tolC1(f, live);
      out.push({ id: "C1", f, ok: done <= live + tol, text: `${LBL[f]} : l'historique d'aujourd'hui (${fmt2(done, f)}) dépasse le compteur du jour (${fmt2(live, f)}).` });
    }
    // C2 : mois complets, somme des jours = ligne du mois (valeurs brutes de HA : ses deux réductions s'accordent)
    for (const c of chunks.values()) {
      if (c.fam !== "d" || !c.data || c.key >= monthOf(tk)) continue;
      for (const f of SUMS) {
        const M = COVROWS.get(fid(f));
        if (!c.data[f + "Raw"] || !M || !M.has(c.key)) continue;
        const sd = [...c.data[f + "Raw"].values()].reduce((a, v) => a + v, 0), mv = M.get(c.key);
        out.push({ id: "C2", f, ok: Math.abs(sd - mv) <= 0.01, text: `${LBL[f]}, ${c.key} : somme des jours ${fmt2(sd, f)} ≠ mois ${fmt2(mv, f)} (contrôle interne).` });
      }
    }
    // C3 : économies depuis la mise en service vs compteur cumulé (s'il a démarré ailleurs, simple info)
    const total = BZ.num(C.economies_total_eur), M = COVROWS.get(fid("savings"));
    if (has("economies") === true && Number.isFinite(total) && M && total > 0) {
      let s = 0; M.forEach((v, mk) => { if (mk >= monthOf(SOLAR0)) s += v; });
      SPIKES.forEach((x) => { if (x.f === "savings" && x.k >= SOLAR0) s -= x.cut; });
      out.push({ id: "C3", f: "savings", ok: Math.abs(s - total) <= 0.05 * total, level: "info", text: `Économies : ${BZ.fmt.n(s, 0)} € dans l'historique depuis ${SOLAR0}, ${BZ.fmt.n(total, 0)} € au compteur cumulé ; il a peut-être démarré à une autre date.` });
    }
    // C4 : hier, somme des heures affichées = chiffre du jour affiché
    const yk = addDays(tk, -1), Hy = chunks.get(`h:${yk}`), Dy = chunks.get(`d:${monthOf(yk)}`);
    if (Hy && Hy.data && Dy && Dy.data) {
      const row = dayRow(yk);
      for (const f of ["prod", "imp", "exp", "chg", "dch", ...(has("economies") === true ? ["savings"] : [])]) {
        const sl = Hy.data.slots[f], dv = row[f];
        if (!sl || !Number.isFinite(dv)) continue;
        const sh = sl.reduce((a, v) => a + v, 0);
        out.push({ id: "C4", f, ok: Math.abs(sh - dv) <= 0.01, text: `${LBL[f]}, hier : somme des heures ${fmt2(sh, f)} ≠ jour ${fmt2(dv, f)} (contrôle interne).` });
      }
    }
    return out;
  }

  /* ─── Diagnostic ──────────────────────────────────────────────────── */
  const WHY = {
    missing: (p, r) => `Pas d'historique pour ${r.label} : ajoute state_class: total_increasing à ce capteur (ou attends une heure, le temps que Home Assistant crée ses statistiques).`,
    nosum: (p, r) => `Pas d'historique pour ${r.label} : ce capteur n'a pas de cumul (state_class total_increasing ou total).`,
    measure: (p) => `${p.id} est une mesure (moyenne), pas un compteur : il lui faut state_class: total_increasing.`,
    nomean: (p, r) => `Pas d'historique pour ${r.label} : ce capteur n'a pas de moyenne (state_class: measurement).`,
    unit: (p, r) => `Unité ${p.unit || "absente"} au lieu de ${r.kind === "money" ? "€" : "kWh"} pour ${r.label}.`,
  };
  const de = (label) => label.replace(/^les /, "des ").replace(/^le /, "du ").replace(/^(la |l')/, "de $1");
  const fmtDay = (k) => { const [y, m, d] = ymd(k); return BZ.fmt.date(new Date(y, m - 1, d), { day: "numeric", month: "long", year: "numeric" }); };
  const fmtMonth = (mk) => { const [y, m] = ymd(mk); return `${BZ.MONTHS_LONG[m - 1]} ${y}`; };
  function issues() {
    const out = [];
    if (META.status === "error") out.push({ level: "warn", group: "history", transient: true, text: "Home Assistant n'a pas donné la liste de ses statistiques : l'historique réessaiera tout seul." });
    if (META.status === "ok") {
      for (const r of REG) {
        const cands = candidates(r), probs = PROBLEMS.filter((p) => p.f === r.f), got = FIELDS[r.f];
        if (!cands.length) continue;
        if (!got) {
          const p = probs[0] || { ...cands[0], why: "missing" };
          const level = r.group === "energie" ? "error" : r.group === "soc" ? "info" : r.group === "economies" && has("economies") === "est" ? "info" : "warn";
          out.push({ level, group: "history", id: p.id, key: p.key, text: WHY[p.why](p, r) + (r.group === "economies" && has("economies") === "est" ? " Les économies sont estimées avec tes tarifs." : "") });
          continue;
        }
        if (got.late) out.push({ level: "info", group: "history", id: got.id, key: got.key, text: `Historique ${de(r.label)} lu sur ce capteur : ${got.late.id} n'a de statistiques que depuis ${got.late.from === "9999-99" ? "jamais" : fmtMonth(got.late.from)}.` });
        else if (probs.length) out.push({ level: "info", group: "history", id: got.id, key: got.key, text: `Historique ${de(r.label)} lu sur ce capteur (${probs.map((p) => p.id).join(", ")} n'a pas de statistiques utilisables).` });
        // Compteur dont l'historique commence après la mise en service : avant, « — » (rien n'est inventé)
        if (r.kind !== "mean" && r.group !== "tarifs") {
          const kf = knownFrom(r.f), from = r.group === "voiture" ? "0000-01-01" : SOLAR0;
          if (kf && kf !== "0000-01-01" && kf > from && kf <= todayKey()) out.push({ level: "info", group: "history", id: got.id, key: got.key, text: `Historique ${de(r.label)} seulement depuis le ${fmtDay(kf)} : avant, Breezy affiche « — » et ne compare pas.` });
        }
      }
    }
    NEG.forEach((n) => out.push({ level: "info", group: "check", id: n.id, text: n.day ? `Correction négative ignorée le ${TZ.key(n.at)} (${BZ.fmt.n(n.raw, 2)} ${kw(n.f)}) : reprise sur les jours suivants.` : `Correction négative ignorée le ${TZ.key(n.at)} à ${TZ.parts(n.at).h} h (${BZ.fmt.n(n.raw, 2)} ${kw(n.f)}) : reprise sur les valeurs suivantes.` }));
    SPIKES.forEach((s) => out.push({ level: "warn", group: "check", id: s.id, text: `Valeur écartée le ${s.k} à ${TZ.parts(s.at).h} h : ${LBL[s.f] || s.f} = ${fmt2(s.raw, s.f)} en une heure, au-delà du plausible (${fmt2(s.cap, s.f)}). Souvent un compteur retombé à 0 puis revenu : retirée de la journée, du mois et des totaux.` }));
    SUSPECT.forEach((s) => out.push({ level: "warn", group: "check", text: `Valeur écartée le ${s.key} : ${LBL[s.f] || "Recharge"} = ${fmt2(s.raw, s.f)}, au-delà du plausible pour une journée (${fmt2(s.cap, s.f)}).` }));
    checks().filter((c) => !c.ok).forEach((c) => out.push({ level: c.level || "warn", group: "check", text: `${c.id} · ${c.text}` }));
    const failed = [...chunks.values()].filter((c) => c.status === "error");
    if (failed.length) out.push({ level: "info", group: "history", transient: true, text: `Home Assistant n'a pas répondu pour ${failed.length} morceau${failed.length > 1 ? "x" : ""} d'historique : nouvel essai automatique.` });
    return out;
  }
  // Échantillon brut (tous les types) pour « Copier le diagnostic » : demandé à l'ouverture du diagnostic
  function sample() {
    if (META.status !== "ok") return null;
    const c = need("x", todayKey(), 1);
    return c.data || null;
  }
  const debug = () => ({
    tz: tzName, start: SOLAR0, history_start: HSTART, meta: META.list, fields: FIELDS, problems: PROBLEMS,
    coverage: Object.fromEntries([...FIRST.entries()]), known_from: Object.fromEntries(DAYF.filter((f) => FIELDS[f]).map((f) => [f, knownFrom(f)])),
    chunks: [...chunks.values()].map((c) => [c.id, c.status, c.complete ? "fini" : "en cours", c.err ? c.err.code || String(c.err) : undefined]),
    samples: (chunks.get(`x:${todayKey()}`) || {}).data || null, negatives: [...NEG.values()], spikes: [...SPIKES.values()], suspects: [...SUSPECT.values()], checks: checks(), lastErrors: HA.errors,
  });

  /* ─── Démarrage, rafraîchissement, pause ───────────────────────────── */
  // Morceaux « vivants » (lus avant que HA ait fini de les écrire) : relus sur l'événement horaire, le minuteur, la reconnexion
  function refreshLive() {
    const tk = todayKey();
    for (const c of chunks.values()) {
      if (!c.data || c.complete || c.fam === "meta" || c.fam === "cov" || c.fam === "x") continue;
      if (c.fam === "s" && !c.key.startsWith(tk)) continue;   // nombres d'un jour passé : périmés
      enqueue(c, 1);
    }
  }
  function afterMeta() {
    screen(chunk("meta", "all").data);
    enqueue(chunk("cov", "all"), -1);
  }
  function afterCov() {
    const cv = chunk("cov", "all").data;
    FIRST = cv.first; COVROWS = cv.rows;
    resolve();
    // Préchargement : aujourd'hui, les 37 derniers jours, hier, les tarifs du mois, le début des compteurs créés tard
    const tk = todayKey(), cm = monthOf(tk);
    need("h", tk, 2);
    [...new Set([monthOf(addDays(tk, -36)), prevMonth(cm), cm])].forEach((mk) => { if (DAYF.some((f) => FIELDS[f] && firstOf(fid(f)) <= mk)) need("d", mk, 2); });
    if (has("voiture") === true) { todaySoFar("evSun"); todaySoFar("evGrid"); }
    need("h", addDays(tk, -1), 2);
    if (has("tarifs") !== true || has("voiture") === true || has("economies") === "est") { need("t", cm, 3); need("t", prevMonth(cm), 3); }
    DAYF.forEach((f) => { if (FIELDS[f]) knownFrom(f); });
  }
  let timers = [], unsub = null, dayNow = "", hourlyT = 0;
  function loadMeta() { META.status = "loading"; const c = chunk("meta", "all"); enqueue(c, -1); }
  function subscribe() {
    if (unsub) return;
    unsub = HA.subscribeEvents(() => { clearTimeout(hourlyT); hourlyT = setTimeout(refreshLive, 3000); }, "recorder_hourly_statistics_generated");
  }
  function startTimers() {
    stopTimers();
    const every = Math.max(1, Number(C.historique_rafraichir_min) || 10) * 6e4;
    timers.push(setInterval(refreshLive, every));
    timers.push(setInterval(() => { for (const c of chunks.values()) if (c.fam === "s" && c.data != null && c.key.startsWith(todayKey())) enqueue(c, 1); }, 5 * 6e4));
    // Changement de jour (dans le fuseau de HA) : hier est relu une fois fini d'écrire, le nouveau jour demandé au rendu
    timers.push(setInterval(() => { const k = todayKey(); if (k !== dayNow) { dayNow = k; seq++; refreshLive(); notify(); } }, 6e4));
  }
  const stopTimers = () => { timers.forEach(clearInterval); timers = []; };
  let started = false;
  function start() {
    if (started) return;
    started = true; dayNow = todayKey();
    loadMeta(); subscribe(); startTimers();
  }
  // Remise à zéro complète (fuseau changé, « Recharger l'historique ») : on oublie tout, métadonnées comprises
  function clear() {
    gen++; chunks.clear(); queue.length = 0; memo.clear(); bases.clear(); NEG.clear(); SPIKES.clear(); SUSPECT.clear();
    META = { status: "idle", list: null, by: null }; FIELDS = {}; PROBLEMS = []; OKC = new Map(); FIRST = new Map(); COVROWS = new Map(); seq++;
    loadingMark();
  }
  HA.on("ready", start);
  HA.on("meta", () => { if (HA.tz !== tzName) { tzName = HA.tz; TZ = makeTz(tzName); clear(); if (started) { loadMeta(); notify(); } } });
  HA.on("connection", (up) => { if (up && started && !paused) { if (META.status !== "ok") { if (META.list) enqueue(chunk("cov", "all"), -1); else loadMeta(); } refreshLive(); } });

  const provider = {
    day: dayRow, hours, hoursOf, forecastDay, forecastMonth: () => ({ prod: 0, forecast: true }), monthSum, todaySoFar, cut, dayModel,
    evSplitBetween, savingsWindow, has, span, like, shifts, sum: (rows) => finish(sumRows(rows)), nowH, key: pageKey, compareFrom, coverStart, knownFrom,
    get solarStart() { return SOLAR0; },
    status: () => ({ loading: META.status === "loading" || queue.length > 0 || inflight > 0, errors: [...chunks.values()].filter((c) => c.status === "error").length, inflight, lastFetch }),
    retry() { if (META.status === "error") { if (META.list) enqueue(chunk("cov", "all"), -1); else loadMeta(); } for (const c of chunks.values()) if (c.status === "error") { c.next = 0; enqueue(c, 0); } notify(); },
    refresh() { if (META.status !== "ok") { if (!META.list) loadMeta(); } else afterCov(); refreshLive(); notify(); },
    clear,
    pause() { paused = true; stopTimers(); clearTimeout(hourlyT); unsub = null; },   // le pont a déjà rendu l'abonnement à HA
    resume() { if (!paused) return; paused = false; if (!started) { start(); return; } subscribe(); startTimers(); refreshLive(); pump(); notify(); },
    get meta() { return META.list; }, get fields() { return FIELDS; },
    issues, sample, checks, debug,
  };
  BZ.useHistory(provider);
  if (HA.hass) start();
  BZ.extraActions = Object.assign(BZ.extraActions || {}, {
    "hist-retry": () => BZ.hist.retry(),
    "hist-reload": () => { BZ.hist.clear(); BZ.hist.refresh(); BZ.toast("Historique rechargé", "good"); },
  });
  // Console du navigateur : la forme réelle des données (métadonnées, échantillons, contrôles), sans jeton
  Object.defineProperty((window.BZ_DIAG = window.BZ_DIAG || {}), "history", { get: debug, configurable: true });
})();
;
// ═══ v3/js/dom.js
// Breezy HEMS V3 — rendu : met à jour le DOM existant au lieu de le remplacer.
// Garde le focus, la position de défilement, les transitions CSS et les animations
// en cours (la V1 reconstruisait toute la page à chaque action).
(() => {
  const BZ = window.BZ;

  function patchNode(a, b) {
    if (a.nodeType !== b.nodeType || a.nodeName !== b.nodeName || (a.nodeType === 1 && a.getAttribute("data-key") !== b.getAttribute("data-key"))) {
      a.replaceWith(b);
      return;
    }
    if (a.nodeType === 3 || a.nodeType === 8) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return; }
    if (a.nodeType !== 1) return;
    // Décor figé (data-static) : même empreinte, contenu inchangé, rien à comparer ni à toucher
    if (b.hasAttribute("data-static") && a.getAttribute("data-static") === b.getAttribute("data-static")) return;
    for (const { name } of [...a.attributes]) if (!b.hasAttribute(name)) a.removeAttribute(name);
    for (const { name, value } of [...b.attributes]) if (a.getAttribute(name) !== value) a.setAttribute(name, value);
    if ((a.tagName === "INPUT" || a.tagName === "SELECT") && a !== document.activeElement && a.value !== b.value) a.value = b.value;
    patchChildren(a, b);
  }
  function patchChildren(a, b) {
    const an = [...a.childNodes], bn = [...b.childNodes];
    bn.forEach((n, i) => (i < an.length ? patchNode(an[i], n) : a.appendChild(n)));
    for (let i = bn.length; i < an.length; i++) an[i].remove();
  }
  const tpl = document.createElement("template");
  // Remplace le contenu de `el` par `html` en touchant le moins de nœuds possible
  function morph(el, html) {
    tpl.innerHTML = html;
    const next = document.createElement(el.tagName);
    next.appendChild(tpl.content);
    patchChildren(el, next);
  }

  // Petit utilitaire de gabarit : ignore false / null / undefined et aplatit les tableaux
  const h = (strings, ...vals) => strings.reduce((out, s, i) => out + s + (i < vals.length ? flat(vals[i]) : ""), "");
  const flat = (v) => (v == null || v === false ? "" : Array.isArray(v) ? v.map(flat).join("") : String(v));
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

  Object.assign(BZ, { morph, h, esc });
})();
;
// ═══ v3/js/ui.js
// Breezy HEMS V3 — composants d'interface. Chaque fonction renvoie du HTML,
// sans style en ligne (sauf variables CSS de données : couleur, pourcentage).
(() => {
  const BZ = window.BZ;
  const { h, esc, fmt } = BZ;

  /* ─── Icônes : un seul jeu, trait 1,75, grille 24 ─────────────────── */
  const P = {
    overview: '<rect x="3" y="3" width="7.5" height="9" rx="2"/><rect x="13.5" y="3" width="7.5" height="5" rx="2"/><rect x="13.5" y="11" width="7.5" height="10" rx="2"/><rect x="3" y="15" width="7.5" height="6" rx="2"/>',
    energy: '<path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12z"/>',
    car: '<path d="M5 17H3.5a1 1 0 0 1-1-1v-3.3c0-.5.1-.9.4-1.3L5 8.2A2 2 0 0 1 6.7 7h8.6a2 2 0 0 1 1.5.7L19.5 11l1.4.4c.6.2 1.1.8 1.1 1.4V16a1 1 0 0 1-1 1H19"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M9 17h6"/>',
    home: '<path d="M3 10.2 12 3l9 7.2V20a1 1 0 0 1-1 1h-5v-6.5H9V21H4a1 1 0 0 1-1-1z"/>',
    insights: '<path d="M4 20V11M10 20V5M16 20v-6M22 20H2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    battery: '<rect x="2" y="7" width="17" height="10" rx="2.5"/><path d="M22 11v2"/><path d="M6 10.5v3M9.5 10.5v3"/>',
    grid: '<path d="M7 21 11 3h2l4 18"/><path d="M5.5 8h13M4 14h16"/><path d="m9 14 3-6 3 6"/>',
    bolt: '<path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12z"/>',
    plug: '<path d="M9 2v5M15 2v5M6 7h12v4a6 6 0 0 1-12 0zM12 17v5"/>',
    flame: '<path d="M12 22c4 0 7-2.8 7-7 0-4.5-4-6.8-4.6-11.5C11.5 5.6 10 8.3 10 10.4c-1-.7-1.8-1.9-2-3.3C6 9.1 5 11.9 5 15c0 4.2 3 7 7 7z"/>',
    drop: '<path d="M12 3s6 6.3 6 11a6 6 0 0 1-12 0c0-4.7 6-11 6-11z"/>',
    thermo: '<path d="M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0z"/>',
    bulb: '<path d="M9 18h6M10 21.5h4"/><path d="M12 2.5a6.5 6.5 0 0 0-4.2 11.4c.7.7 1.2 1.6 1.2 2.6h6c0-1 .5-1.9 1.2-2.6A6.5 6.5 0 0 0 12 2.5z"/>',
    blinds: '<path d="M3 3.5h18M5 3.5V18M19 3.5V18M5 7.5h14M5 11.5h14M5 15.5h14"/><path d="M12 18v3"/>',
    robot: '<rect x="3.5" y="8" width="17" height="12" rx="4"/><path d="M12 4v4M9 14h.01M15 14h.01"/>',
    speaker: '<rect x="5" y="2.5" width="14" height="19" rx="3"/><circle cx="12" cy="14.5" r="3.5"/><path d="M12 7h.01"/>',
    lock: '<rect x="4.5" y="11" width="15" height="10" rx="2.5"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/>',
    unlock: '<rect x="4.5" y="11" width="15" height="10" rx="2.5"/><path d="M8 11V7.5a4 4 0 0 1 7.7-1.5"/>',
    snow: '<path d="M12 2v20M3.3 7l17.4 10M3.3 17 20.7 7M9 4.2l3 1.8 3-1.8M9 19.8l3-1.8 3 1.8"/>',
    refresh: '<path d="M20.5 12a8.5 8.5 0 1 1-2.5-6l2.5 2.4"/><path d="M20.5 3.5v5h-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    leaf: '<path d="M5 20.5c0-9.3 5.4-15 15-16-.9 9.9-6.6 15.2-15 16z"/><path d="m5 20.5 8.5-8.5"/>',
    euro: '<path d="M17.5 6.5a7 7 0 1 0 0 11M4 10h9.5M4 14h9.5"/>',
    wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    gauge: '<path d="M12 14l4-4"/><path d="M3.3 17a9 9 0 1 1 17.4 0"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
    alert: '<path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    chevron: '<path d="m9 6 6 6-6 6"/>',
    up: '<path d="m6 15 6-6 6 6"/>',
    down: '<path d="m6 9 6 6 6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>',
    pause: '<rect x="6.5" y="5" width="3.5" height="14" rx="1" fill="currentColor"/><rect x="14" y="5" width="3.5" height="14" rx="1" fill="currentColor"/>',
    prev: '<path d="M18 5.5v13L8.5 12z" fill="currentColor"/><path d="M6 5.5v13"/>',
    next: '<path d="M6 5.5v13L15.5 12z" fill="currentColor"/><path d="M18 5.5v13"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    sack: '<path d="M8.5 4h7l-2 4c3 1.6 5.5 4.6 5.5 8.5a4.5 4.5 0 0 1-4.5 4.5h-5A4.5 4.5 0 0 1 5 16.5C5 12.6 7.5 9.6 10.5 8z"/>',
    dock: '<path d="M3 20h18M7 20v-4a5 5 0 0 1 10 0v4"/>',
    contrast: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>',
    power: '<path d="M12 3v8"/><path d="M6.3 7a8 8 0 1 0 11.4 0"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    left: '<path d="m15 6-6 6 6 6"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    more: '<circle cx="5.5" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="18.5" cy="12" r="1.3" fill="currentColor" stroke="none"/>',
    star: '<path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    tasks: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="m3.5 6 1.2 1.2L7 5M3.5 12l1.2 1.2L7 11M3.5 18l1.2 1.2L7 17"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M21.5 20a6.5 6.5 0 0 0-4-6"/>',
    chart: '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  };
  const icon = (name, cls = "") => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[name] || ""}</svg>`;

  /* ─── Valeur + unité (l'unité est toujours plus discrète) ──────────── */
  const val = ([v, u], cls = "") => h`<span class="val ${cls}"><span class="val-n">${v}</span>${u ? h`<span class="val-u">${u}</span>` : ""}</span>`;

  /* ─── Carte ────────────────────────────────────────────────────────
     Un seul modèle : en-tête (icône teintée, titre, sous-titre, action), corps. */
  // target : la carte est une cible de saut (action « spot ») ; son titre peut alors recevoir le focus
  const card = ({ title, sub, ic, tone = "accent", aside, link, body, cls = "", tag = "section", attrs = "", target = false }) => h`
    <${tag} class="card ${cls}" ${attrs}>
      ${title ? h`<header class="card-h">
        ${ic ? h`<span class="card-i" data-tone="${tone}">${icon(ic)}</span>` : ""}
        <div class="card-t"><h3 ${target ? 'tabindex="-1"' : ""}>${title}</h3>${sub ? h`<p>${sub}</p>` : ""}</div>
        ${aside || link ? h`<div class="card-a">${aside || ""}${link ? more(link) : ""}</div>` : ""}
      </header>` : ""}
      ${body}
    </${tag}>`;

  // Lien d'action discret « Voir tout → » (navigation ou action)
  const more = ({ label, to, act, args = {} }) => to
    ? h`<a class="more" href="${BZ.href(to)}">${label}${icon("arrow")}</a>`
    : h`<button type="button" class="more" data-act="${act}" ${dataArgs(args)}>${label}${icon("arrow")}</button>`;

  // Pastille d'état teintée (statut, type, priorité)
  const pill = (text, tone = "neutral", live = false) => h`<span class="pill ${live ? "is-live" : ""}" data-tone="${tone}">${text}</span>`;

  // Carte indicateur : icône ronde teintée, libellé, valeur, variation, mini-courbe
  const kpi = ({ label, ic, tone, value, delta: d = "", vs = "", spark = null, act, to }) => {
    const inner = h`<span class="kpi-i" data-tone="${tone}">${icon(ic)}</span>
      <span class="kpi-l">${label}</span>
      <span class="kpi-v">${value}</span>
      <span class="kpi-d">${d}${vs ? h`<span class="kpi-vs">${vs}</span>` : ""}</span>
      ${spark ? h`<span class="kpi-s" data-tone="${tone}">${spark}</span>` : ""}`;
    return to ? h`<a class="kpi" href="${BZ.href(to)}">${inner}</a>` : act ? h`<button type="button" class="kpi" data-act="${act}">${inner}</button>` : h`<div class="kpi">${inner}</div>`;
  };

  // Pastilles de filtre séparées (style maquette) : la sélection est teintée d'accent
  const pills = ({ name, options, value, label }) => h`
    <div class="pills" role="tablist" aria-label="${esc(label)}">
      ${options.map(([k, l, n]) => h`<button type="button" role="tab" aria-selected="${String(k === value)}" data-act="set" data-k="${name}" data-value="${k}">${l}${n != null ? h`<em>${n}</em>` : ""}</button>`)}
    </div>`;

  // Anneau segmenté (répartition) avec valeur au centre
  const donut = ({ parts, size = 132, stroke = 16, center = "", sub = "", label }) => {
    const r = (size - stroke) / 2, c = 2 * Math.PI * r, tot = parts.reduce((a, p) => a + p.v, 0) || 1;
    const gap = parts.filter((p) => p.v > 0).length > 1 ? 3 : 0;
    let acc = 0;
    const segs = parts.filter((p) => p.v > 0).map((p) => {
      const len = (p.v / tot) * c, seg = h`<circle data-tone="${p.tone}" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" stroke-dasharray="${Math.max(0.01, len - gap)} ${c}" stroke-dashoffset="${-acc}"/>`;
      acc += len; return seg;
    });
    return h`<div class="donut" style="--s:${size}px" role="img" aria-label="${esc(label || parts.map((p) => `${p.label} ${Number.isFinite(p.v) ? Math.round((p.v / tot) * 100) : "—"} %`).join(", "))}">
      <svg viewBox="0 0 ${size} ${size}"><circle class="donut-b" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}"/>${segs}</svg>
      <div class="donut-c"><b>${center}</b>${sub ? h`<span>${sub}</span>` : ""}</div></div>`;
  };

  // Avatar à initiales
  const avatar = (name, size = "") => h`<span class="avatar ${size}" aria-hidden="true">${esc(String(name || "?").trim()[0] || "?").toUpperCase()}</span>`;

  const badge = (text, tone = "neutral", live = false) => h`<span class="badge ${live ? "is-live" : ""}" data-tone="${tone}">${text}</span>`;
  const delta = (cur, prev, { invert = false, unit = "%" } = {}) => {
    if (!prev || !Number.isFinite(cur)) return "";   // valeur inconnue (historique en chargement) : pas de variation
    const d = unit === "pts" ? (cur - prev) * 100 : ((cur - prev) / prev) * 100;
    if (!Number.isFinite(d) || Math.abs(d) < 0.5) return h`<span class="delta">=</span>`;
    const good = invert ? d < 0 : d > 0;
    return h`<span class="delta ${good ? "is-good" : "is-bad"}">${icon(d > 0 ? "up" : "down")}${fmt.n(Math.abs(d))} ${unit}</span>`;
  };

  /* ─── Contrôles ────────────────────────────────────────────────────
     Tous les contrôles sont de vrais boutons, accessibles au clavier, avec
     un état « en cours » pendant l'appel au service. */
  const btn = ({ label, ic, act, args = {}, kind = "secondary", size = "", pending = false, disabled = false, cls = "", aria }) => h`
    <button class="btn btn-${kind} ${size ? `btn-${size}` : ""} ${cls}" type="button" data-act="${act}" ${dataArgs(args)} ${pending ? 'aria-busy="true"' : ""} ${disabled ? "disabled" : ""} ${aria ? `aria-label="${esc(aria)}"` : ""}>
      ${ic ? icon(ic) : ""}${label ? h`<span>${label}</span>` : ""}
    </button>`;
  const dataArgs = (args) => Object.entries(args).map(([k, v]) => `data-${k}="${esc(v)}"`).join(" ");

  const toggle = ({ on, act, args = {}, label, pending = false }) => h`
    <button class="toggle" type="button" role="switch" aria-checked="${String(on)}" aria-label="${esc(label)}" data-act="${act}" ${dataArgs(args)} ${pending ? 'aria-busy="true"' : ""}><span class="toggle-k"></span></button>`;

  const stepper = ({ value, act, args = {}, label, unit = "", pending = false, min, max, cur }) => h`
    <div class="stepper" role="group" aria-label="${esc(label)}">
      <button type="button" data-act="${act}" ${dataArgs({ ...args, d: -1 })} aria-label="Diminuer" ${cur <= min ? "disabled" : ""}>${icon("minus")}</button>
      <output ${pending ? 'aria-busy="true"' : ""}>${value}<small>${unit}</small></output>
      <button type="button" data-act="${act}" ${dataArgs({ ...args, d: 1 })} aria-label="Augmenter" ${cur >= max ? "disabled" : ""}>${icon("plus")}</button>
    </div>`;

  const segmented = ({ name, options, value, label }) => h`
    <div class="seg" role="tablist" aria-label="${esc(label)}" style="--n:${options.length};--i:${Math.max(0, options.findIndex(([k]) => k === value))}">
      <span class="seg-ind" aria-hidden="true"></span>
      ${options.map(([k, l]) => h`<button type="button" role="tab" aria-selected="${String(k === value)}" data-act="set" data-k="${name}" data-value="${k}">${l}</button>`)}
    </div>`;

  // Jauge linéaire : valeur, repère optionnel (limite), couleur de données
  const meter = ({ value, mark, tone = "neutral", label, size = "" }) => h`
    <div class="meter ${size ? `meter-${size}` : ""}" data-tone="${tone}" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(value)}" ${label ? `aria-label="${esc(label)}"` : ""}>
      <span class="meter-f" style="--v:${BZ.clamp(value, 0, 100)}%"></span>${mark != null ? h`<span class="meter-m" style="--v:${mark}%"></span>` : ""}
    </div>`;

  // Anneau : progression circulaire avec contenu au centre
  const ring = ({ value, tone = "neutral", size = 96, stroke = 8, mark, inner = "", label }) => {
    const r = (size - stroke) / 2, c = 2 * Math.PI * r, v = BZ.clamp(value, 0, 100);
    return h`<div class="ring" data-tone="${tone}" style="--s:${size}px" role="img" aria-label="${esc(label || `${Math.round(v)} %`)}">
      <svg viewBox="0 0 ${size} ${size}"><circle class="ring-b" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}"/>
        <circle class="ring-f" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - v / 100)}"/>
        ${mark != null ? h`<circle class="ring-m" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke + 4}" stroke-dasharray="2 ${c}" stroke-dashoffset="${-c * mark / 100}"/>` : ""}</svg>
      <div class="ring-c">${inner}</div></div>`;
  };

  // Statistique : libellé, grande valeur, contexte
  const stat = ({ label, value, sub, tone, extra = "" }) => h`
    <div class="stat" ${tone ? `data-tone="${tone}"` : ""}><span class="stat-l">${label}</span><span class="stat-v">${value}</span>${sub ? h`<span class="stat-s">${sub}</span>` : ""}${extra}</div>`;

  // État vide : explique pourquoi c'est vide et ce qu'on peut faire
  const empty = ({ ic, title, text, action = "" }) => h`<div class="empty">${icon(ic)}<strong>${title}</strong><p>${text}</p>${action}</div>`;

  // Légende de série (toujours un libellé à côté de la couleur)
  const legend = (items) => h`<ul class="legend">${items.map(([label, tone, v]) => h`<li data-tone="${tone}"><i></i>${label}${v != null ? h`<b>${v}</b>` : ""}</li>`)}</ul>`;

  /* ─── Notifications ───────────────────────────────────────────────── */
  let toastTimer;
  function toast(text, tone = "neutral") {
    const el = document.getElementById("toast");
    // Coche pour une réussite ou une information, alerte pour un refus ou un échec (warn, bad)
    el.innerHTML = h`<span class="toast-i" data-tone="${tone}">${icon(tone === "bad" || tone === "warn" ? "alert" : "check")}</span><span>${esc(text)}</span>`;
    el.classList.add("is-on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("is-on"), 2600);
  }

  Object.assign(BZ, { icon, val, card, more, pill, kpi, pills, donut, avatar, badge, delta, btn, toggle, stepper, segmented, meter, ring, stat, empty, legend, toast, dataArgs });
})();
;
// ═══ v3/js/charts.js
// Breezy HEMS V3 — graphiques SVG. Une seule infobulle partagée, navigable au clavier.
// Toutes les couleurs viennent des variables CSS de données (--solar, --battery…).
(() => {
  const BZ = window.BZ;
  const { h, esc, fmt, icon } = BZ;
  const REG = new Map();          // id -> description du graphique (pour l'infobulle)
  let uid = 0;
  const nid = (p) => `${p}${++uid}`;

  // Courbe lissée (Catmull-Rom -> Bézier), sans dépassement sous zéro
  function smooth(pts) {
    if (pts.length < 2) return "";
    let d = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += ` C${p1[0] + (p2[0] - p0[0]) / 6},${p1[1] + (p2[1] - p0[1]) / 6} ${p2[0] - (p3[0] - p1[0]) / 6},${p2[1] - (p3[1] - p1[1]) / 6} ${p2[0]},${p2[1]}`;
    }
    return d;
  }
  const niceMax = (v) => { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)), n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; };

  /* ─── Mini-courbe ─────────────────────────────────────────────────── */
  const spark = (data, tone = "solar", { w = 120, h: hh = 36, area = true } = {}) => {
    // Valeurs inconnues (NaN : historique en chargement) traitées comme des trous ; moins de 2 points : pas de courbe
    if (data.some((x) => x != null && !Number.isFinite(x))) data = data.map((x) => (Number.isFinite(x) ? x : null));
    if (data.filter((x) => x != null).length < 2) return "";
    const v = data.filter((x) => x != null), max = Math.max(...v, 0.0001), min = Math.min(...v, 0);
    const pts = data.map((x, i) => (x == null ? null : [(i / (data.length - 1)) * w, hh - 2 - ((x - min) / (max - min || 1)) * (hh - 6)])).filter(Boolean);
    const d = smooth(pts);
    return h`<svg class="spark" data-tone="${tone}" viewBox="0 0 ${w} ${hh}" preserveAspectRatio="none" aria-hidden="true">
      ${area ? h`<path class="spark-a" d="${d} L${pts[pts.length - 1][0]},${hh} L${pts[0][0]},${hh} Z"/>` : ""}<path class="spark-l" d="${d}"/></svg>`;
  };

  /* ─── Barres (empilables) ─────────────────────────────────────────────
     series: [{ key, label, tone, values[] }]  · buckets: [{ key, current, forecast }] */
  function bars({ buckets, series, unit = "kWh", dec = 1, height = 200, avg = true, label, labelEvery = 1, footer }) {
    const id = nid("c"), W = 600, H = height, PB = 22, PT = 14;
    const totals = buckets.map((_, i) => series.reduce((a, s) => a + (s.values[i] || 0), 0));
    const max = niceMax(Math.max(...totals) * 1.05), n = buckets.length, slot = W / n, bw = Math.max(3, Math.min(34, slot * 0.62));
    const y = (v) => PT + (1 - v / max) * (H - PT - PB);
    const real = totals.filter((_, i) => !buckets[i].forecast), mean = real.reduce((a, b) => a + b, 0) / (real.length || 1);
    const grid = [0, 0.5, 1].map((k) => h`<line class="gl" x1="0" x2="${W}" y1="${y(max * k)}" y2="${y(max * k)}"/>`);
    const cols = buckets.map((b, i) => {
      let base = 0;
      const x = slot * i + (slot - bw) / 2;
      const segs = series.map((s) => { const v = s.values[i] || 0; if (v <= 0) return ""; const y1 = y(base + v), y0 = y(base); base += v; return h`<rect x="${x}" y="${y1}" width="${bw}" height="${Math.max(0, y0 - y1 - (base < totals[i] ? 1.5 : 0))}" rx="${Math.min(4, bw / 3)}" data-tone="${s.tone}"/>`; });
      return h`<g class="bar ${b.current ? "is-cur" : ""} ${b.forecast ? "is-fc" : ""}">${segs}</g>`;
    });
    const labels = buckets.map((b, i) => (i % labelEvery === 0 || b.current ? h`<span class="ax ${b.current ? "is-cur" : ""}" style="--x:${((slot * i + slot / 2) / W) * 100}%">${esc(b.key)}</span>` : ""));
    REG.set(id, { type: "bars", n, slot, W, buckets, series, unit, dec, totals });
    return h`<figure class="chart" data-chart="${id}" tabindex="0" aria-label="${esc(label)}. Flèches gauche et droite pour parcourir.">
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${grid}${avg && real.length > 1 ? h`<line class="avg" x1="0" x2="${W}" y1="${y(mean)}" y2="${y(mean)}"/>` : ""}${cols}<rect class="hl" x="0" y="${PT}" width="${slot}" height="${H - PT - PB}"/></svg>
      <div class="axis" aria-hidden="true">${labels}</div>
      ${avg && real.length > 1 ? h`<span class="avg-l" style="--y:${(y(mean) / H) * 100}%">moy. ${fmt.n(mean, dec)}</span>` : ""}
      ${footer || ""}</figure>`;
  }

  /* ─── Aires / courbes superposées ─────────────────────────────────── */
  function lines({ labels, series, unit = "kWh", dec = 1, height = 200, label, labelEvery = 1, band, now }) {
    const id = nid("c"), W = 600, H = height, PB = band ? 30 : 22, PT = 12, n = labels.length;
    const all = series.flatMap((s) => s.values.filter((v) => v != null)), max = niceMax(Math.max(...all, 0.1) * 1.08);
    const x = (i) => (i / (n - 1)) * W, y = (v) => PT + (1 - v / max) * (H - PT - PB);
    const grid = [0, 0.5, 1].map((k) => h`<line class="gl" x1="0" x2="${W}" y1="${y(max * k)}" y2="${y(max * k)}"/>`);
    const paths = series.map((s) => {
      const pts = s.values.map((v, i) => (v == null ? null : [x(i), y(v)])).filter(Boolean);
      if (pts.length < 2) return "";
      const d = smooth(pts);
      return h`<g data-tone="${s.tone}" class="${s.dashed ? "is-dashed" : ""}">${s.area ? h`<path class="ln-a" d="${d} L${pts[pts.length - 1][0]},${y(0)} L${pts[0][0]},${y(0)} Z"/>` : ""}<path class="ln" d="${d}"/></g>`;
    });
    // Bande des tarifs sous l'axe (heures pleines / creuses / super creuses)
    const bandSvg = band ? band.map((k, i) => h`<rect class="band" data-tariff="${k}" x="${x(i) - (i === 0 ? 0 : W / (n - 1) / 2)}" y="${H - PB + 6}" width="${W / (n - 1)}" height="4"/>`) : "";
    const lab = labels.map((l, i) => (i % labelEvery === 0 ? h`<span class="ax ${i === 0 ? "is-start" : i === n - 1 ? "is-end" : ""}" style="--x:${(x(i) / W) * 100}%">${esc(l)}</span>` : ""));
    REG.set(id, { type: "lines", n, W, labels, series, unit, dec, x });
    return h`<figure class="chart" data-chart="${id}" tabindex="0" aria-label="${esc(label)}. Flèches gauche et droite pour parcourir.">
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${grid}${paths}${now != null ? h`<line class="now" x1="${x(now)}" x2="${x(now)}" y1="${PT}" y2="${H - PB}"/>` : ""}${bandSvg}
        <line class="cross" y1="${PT}" y2="${H - PB}"/></svg>
      <div class="axis" aria-hidden="true">${lab}</div></figure>`;
  }

  /* ─── Infobulle partagée (souris, toucher et clavier) ─────────────── */
  const tip = () => document.getElementById("tip");
  function showTip(fig, i) {
    const c = REG.get(fig.dataset.chart);
    if (!c) return;
    i = BZ.clamp(i, 0, c.n - 1);
    fig.dataset.i = i;
    const svg = fig.querySelector("svg"), r = svg.getBoundingClientRect();
    let xPx, rows, title;
    if (c.type === "bars") {
      xPx = r.left + ((c.slot * i + c.slot / 2) / c.W) * r.width;
      const hl = svg.querySelector(".hl"); hl.setAttribute("x", c.slot * i); hl.classList.add("is-on");
      const b = c.buckets[i];
      title = b.tipTitle || b.key;
      rows = b.forecast ? [["Prévu", fmt.n(c.series.reduce((a, s) => a + (s.values[i] || 0), 0), c.dec), "neutral"]]
        : c.series.map((s) => [s.label, fmt.n(s.values[i] || 0, c.dec), s.tone]);
      if (!b.forecast && c.series.length > 1) rows.push(["Total", fmt.n(c.totals[i], c.dec), null]);
    } else {
      xPx = r.left + (c.x(i) / c.W) * r.width;
      const cr = svg.querySelector(".cross"); cr.setAttribute("x1", c.x(i)); cr.setAttribute("x2", c.x(i)); cr.classList.add("is-on");
      title = c.labels[i];
      rows = c.series.filter((s) => s.values[i] != null).map((s) => [s.label, fmt.n(s.values[i], c.dec), s.tone]);
      c.series.forEach((s) => s.detail && s.values[i] != null && s.detail(i).forEach(([l, v]) => rows.push([l, fmt.n(v, c.dec), "sub"])));
    }
    const t = tip();
    t.innerHTML = h`<strong>${esc(title)}</strong>${rows.map(([l, v, tone]) => h`<div class="tip-r ${tone === "sub" ? "is-sub" : ""}">${tone && tone !== "sub" ? h`<i data-tone="${tone}"></i>` : ""}<span>${l}</span><b>${v}${tone === "sub" ? "" : ` ${c.unit}`}</b></div>`)}`;
    t.classList.add("is-on");
    const tw = t.offsetWidth, th = t.offsetHeight;
    const left = BZ.clamp(xPx - tw / 2, 8, innerWidth - tw - 8), top = Math.max(8, r.top - th - 10);
    t.style.transform = `translate(${left}px, ${top < 8 ? r.bottom + 10 : top}px)`;
  }
  function hideTip(fig) {
    tip().classList.remove("is-on");
    if (fig) fig.querySelectorAll(".hl, .cross").forEach((e) => e.classList.remove("is-on"));
  }
  let active = null;
  document.addEventListener("pointermove", (e) => {
    const fig = e.target.closest && e.target.closest(".chart");
    if (active && active !== fig) { hideTip(active); active = null; }
    if (!fig) return;
    const c = REG.get(fig.dataset.chart); if (!c) return;
    const r = fig.querySelector("svg").getBoundingClientRect(), px = ((e.clientX - r.left) / r.width) * c.W;
    const i = c.type === "bars" ? Math.floor(px / c.slot) : Math.round((px / c.W) * (c.n - 1));
    active = fig; showTip(fig, i);
  }, { passive: true });
  document.addEventListener("pointerleave", () => active && hideTip(active));
  document.addEventListener("scroll", () => active && (hideTip(active), (active = null)), { passive: true, capture: true });
  document.addEventListener("keydown", (e) => {
    const fig = document.activeElement && document.activeElement.closest && document.activeElement.closest(".chart");
    if (!fig || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
    const c = REG.get(fig.dataset.chart), cur = fig.dataset.i != null ? +fig.dataset.i : c.n - 1;
    e.preventDefault();
    showTip(fig, e.key === "Home" ? 0 : e.key === "End" ? c.n - 1 : cur + (e.key === "ArrowLeft" ? -1 : 1));
  });
  document.addEventListener("focusout", (e) => e.target.classList && e.target.classList.contains("chart") && hideTip(e.target));

  /* ─── Barre empilée 100 % (répartition) ───────────────────────────── */
  const split = (parts, { label } = {}) => {
    const t = parts.reduce((a, p) => a + p.v, 0) || 1;
    return h`<div class="split" role="img" aria-label="${esc(label || parts.map((p) => `${p.label} ${Number.isFinite(p.v) ? Math.round((p.v / t) * 100) : "—"} %`).join(", "))}">
      ${parts.filter((p) => p.v > 0).map((p) => h`<span data-tone="${p.tone}" style="--w:${(p.v / t) * 100}%" title="${esc(p.label)}"></span>`)}</div>`;
  };

  Object.assign(BZ, { spark, bars, lines, split, smooth, niceMax, resetCharts: () => REG.clear() });
})();
;
// ═══ v3/js/flow.js
// Breezy HEMS V3 — schéma des flux en direct. Deux dispositions dans le même composant :
// en ligne (cartes larges) et en croix autour de la maison (cartes étroites, mobile).
// Le conteneur choisit via @container : aucune logique de taille d'écran en JS.
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, val } = BZ;

  const speed = (w) => `${BZ.clamp(2.6 - w / 1400, 0.55, 2.6).toFixed(2)}s`;
  const width = (w) => BZ.clamp(1.5 + w / 1100, 1.5, 5).toFixed(2);
  const IDLE = 15;   // sous 15 W, une liaison est considérée au repos

  // États des nœuds (libellé, puissance, note, teinte) : partagés par le schéma, la page Énergie et la maison
  function nodes(L) {
    const batState = Math.abs(L.bat) < IDLE ? "Veille" : L.bat > 0 ? "Charge" : "Décharge";
    const gridState = Math.abs(L.grid) < IDLE ? "Équilibre" : L.grid < 0 ? "Revente" : "Achat";
    return {
      sun: { ic: "sun", tone: "solar", label: "Soleil", w: L.solar, note: "3 onduleurs" },
      home: { ic: "home", tone: "home", label: "Maison", w: L.house, note: "hors voiture" },
      bat: { ic: "battery", tone: "battery", label: "Batterie", w: Math.abs(L.bat), note: `${fmt.n(BZ.num(BZ.C.batterie_soc))} % · ${batState}`, state: batState, soc: BZ.num(BZ.C.batterie_soc), dir: L.bat < -15 ? "in" : "out" },
      grid: { ic: "grid", tone: L.grid > 15 ? "bad" : "grid", label: "Réseau", w: Math.abs(L.grid), note: gridState, state: gridState, dir: L.grid > 15 ? "in" : "out" },
      car: { ic: "car", tone: "ev", label: "e-Niro", w: L.car, note: L.charging ? `${fmt.n(BZ.num(BZ.C.voiture_soc))} % · ${fmt.n(L.evSolarShare * 100)} % soleil` : L.plugged ? "Branchée" : "Débranchée", soc: BZ.num(BZ.C.voiture_soc) },
    };
  }

  /* Qui alimente qui, en ce moment. Les capteurs ne donnent qu'un total par nœud ; on répartit dans l'ordre
     de l'autoconsommation : le soleil sert d'abord la maison, puis la voiture, la batterie, et le reste part au
     réseau ; la batterie puis le réseau couvrent ce qui manque. → [{ from: "sun" | "bat" | "grid", to: "house" | "car" | "bat" | "grid", w }] */
  function routes(L) {
    const src = { sun: Math.max(0, L.solar), bat: Math.max(0, -L.bat), grid: Math.max(0, L.grid) };
    const dst = { house: Math.max(0, L.house), car: Math.max(0, L.car), bat: Math.max(0, L.bat), grid: Math.max(0, -L.grid) };
    const out = [];
    for (const from of ["sun", "bat", "grid"]) for (const to of ["house", "car", "bat", "grid"]) {
      if (from === to) continue;
      const w = Math.min(src[from], dst[to]);
      if (w > 0) { src[from] -= w; dst[to] -= w; out.push({ from, to, w }); }
    }
    return out;
  }

  // Une liaison : trait de fond + trait animé dans le sens réel de l'énergie
  const link = (d, tone, w, reverse) => h`<path class="fl-bg" d="${d}"/>${w >= 15 ? h`<path class="fl-go ${reverse ? "is-rev" : ""}" data-tone="${tone}" d="${d}" style="--sp:${speed(w)};--sw:${width(w)}"/>` : ""}`;

  const node = (k, n, pos) => h`
    <div class="fn fn-${k} ${n.w < 15 && k !== "home" ? "is-idle" : ""}" data-tone="${n.tone}" style="--x:${pos[0]}%;--y:${pos[1]}%">
      <span class="fn-i">${icon(n.ic)}${n.soc != null ? h`<svg class="fn-soc" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="18.5" pathLength="100" style="--p:${n.soc}"/></svg>` : ""}</span>
      <span class="fn-t"><span class="fn-l">${n.label}</span>${val(fmt.power(n.w), "fn-v")}<span class="fn-n">${n.note}</span></span>
    </div>`;

  function flow({ compact = false } = {}) {
    const L = BZ.live(), N = nodes(L);
    // Disposition en ligne : soleil → maison → (batterie, réseau, voiture)
    const P = { sun: [12, 50], home: [43, 50], bat: [84, 16], grid: [84, 50], car: [84, 84] };
    const X = (p) => p * 10, Y = (p) => p * 3.4;
    const curve = (a, b) => { const x1 = X(P[a][0]) + 70, y1 = Y(P[a][1]), x2 = X(P[b][0]) - 78, y2 = Y(P[b][1]), mx = (x1 + x2) / 2; return `M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`; };
    const pill = (a, b, w, tone) => { if (w < 15) return ""; const mx = (X(P[a][0]) + 70 + X(P[b][0]) - 78) / 2, my = (Y(P[a][1]) + Y(P[b][1])) / 2; return h`<span class="fl-pill" data-tone="${tone}" style="--x:${mx / 10}%;--y:${(my / 340) * 100}%">${fmt.powerText(w)}</span>`; };
    const wide = h`<div class="flow-wide">
      <svg viewBox="0 0 1000 340" preserveAspectRatio="none" aria-hidden="true">
        ${link(curve("sun", "home"), "solar", L.solar)}
        ${link(curve("home", "bat"), "battery", Math.abs(L.bat), L.bat < 0)}
        ${link(curve("home", "grid"), L.grid > 0 ? "bad" : "grid", Math.abs(L.grid), L.grid > 0)}
        ${link(curve("home", "car"), "ev", L.car)}
      </svg>
      ${pill("sun", "home", L.solar, "solar")}${pill("home", "bat", Math.abs(L.bat), "battery")}${pill("home", "grid", Math.abs(L.grid), L.grid > 0 ? "bad" : "grid")}${pill("home", "car", L.car, "ev")}
      ${Object.entries(N).map(([k, n]) => node(k, n, P[k]))}
    </div>`;
    // Disposition en croix : la maison au centre
    const Q = { sun: [50, 14], bat: [15, 50], home: [50, 50], grid: [85, 50], car: [50, 86] };
    const seg = (a, b) => { const [x1, y1] = Q[a], [x2, y2] = Q[b], dx = x2 - x1, dy = y2 - y1, l = Math.hypot(dx, dy), r1 = a === "home" ? 14 : 10, r2 = b === "home" ? 14 : 10; return `M${x1 + (dx / l) * r1},${y1 + (dy / l) * r1} L${x2 - (dx / l) * r2},${y2 - (dy / l) * r2}`; };
    const cross = h`<div class="flow-cross">
      <svg viewBox="0 0 100 100" aria-hidden="true">
        ${link(seg("sun", "home"), "solar", L.solar)}
        ${link(seg("home", "bat"), "battery", Math.abs(L.bat), L.bat < 0)}
        ${link(seg("home", "grid"), L.grid > 0 ? "bad" : "grid", Math.abs(L.grid), L.grid > 0)}
        ${link(seg("home", "car"), "ev", L.car)}
      </svg>
      ${Object.entries(N).map(([k, n]) => node(k, n, Q[k]))}
    </div>`;
    const summary = `Soleil ${fmt.powerText(L.solar)}, maison ${fmt.powerText(L.house)}, batterie ${fmt.powerText(Math.abs(L.bat))} ${L.bat >= 0 ? "en charge" : "en décharge"}, réseau ${fmt.powerText(Math.abs(L.grid))} ${L.grid < 0 ? "revendus" : "achetés"}, voiture ${fmt.powerText(L.car)}.`;
    return h`<div class="flow ${compact ? "is-compact" : ""}" role="img" aria-label="${summary}">${wide}${cross}</div>`;
  }

  BZ.flow = flow;
  BZ.flowNodes = nodes;
  BZ.flowRoutes = routes;
  BZ.FLOW_IDLE = IDLE;
})();
;
// ═══ v3/js/house.js
// Breezy HEMS V3 — « Ta maison en direct » : le héros mobile de la page Énergie, et sa version compacte en haut
// de l'Aperçu (BZ.house({ compact: true }) : même dessin et mêmes flux, cadrés plus serré, cinq pastilles).
// Une maquette isométrique façon argile : panneaux sur le toit, batterie dans le jardin, e-Niro sous l'abri
// vitré avec sa borne, poteau et ligne du réseau, ballon d'eau chaude derrière la fenêtre, poêle qui fume.
// Comme le schéma « Flux en direct », tout passe par un nœud central : le coffret électrique (onduleurs et
// tableau) posé sur le mur, sous la gouttière. Le soleil y descend par la gouttière ; il repart vers la maison
// (fenêtre éclairée), la borne de l'e-Niro, et par la goulotte de la façade vers la batterie et le réseau.
// L'énergie circule en points lumineux le long de ces trajets, dans le sens réel : plus la puissance monte,
// plus ils sont nombreux, rapides et lumineux.
// Trois calques superposés :
//  1. le décor (SVG calculé une fois : un rendu de la page ne le touche pas) ;
//  2. les flux (SVG animé par l'API Web Animations : les animations vivent sur les nœuds, BZ.morph ne change
//     que des attributs, donc rien ne redémarre toutes les 5 s ; la vitesse change sans à-coup) ;
//  3. les pastilles (vrais boutons : clavier et lecteur d'écran).
(() => {
  const BZ = window.BZ;
  const { h, esc, fmt, icon, C, num } = BZ;

  /* ─── Projection isométrique 2:1 ────────────────────────────────────
     Monde : x vers la droite-bas, y vers la gauche-bas, z vers le haut (1 unité ≈ 1 m).
     Écran : unités du viewBox. Seules les faces +x, +y et +z sont visibles. */
  const VW = 360, VH = 300, K = 9.1, OX = 150.9, OY = 92;
  const P = (x, y, z = 0) => [OX + (x - y) * K, OY + ((x + y) * K) / 2 - z * K];
  const r1 = (v) => Math.round(v * 10) / 10;
  const xy = (p) => `${r1(p[0])},${r1(p[1])}`;
  const pts = (a) => a.map((p) => xy(P(...p))).join(" ");
  const pg = (cls, a) => `<polygon class="${cls}" points="${pts(a)}"/>`;
  const poly = (a) => "M" + a.map(xy).join("L");   // tracé écran d'une suite de points écran
  // Pavé : ses trois faces visibles (avant-gauche y = y1, avant-droite x = x1, dessus z = z1)
  const box = (cls, [x0, y0, z0], [x1, y1, z1]) =>
    pg(`${cls} fy`, [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]]) +
    pg(`${cls} fx`, [[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]]) +
    pg(`${cls} fz`, [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]]);
  // Repères locaux : on dessine à plat sur une face, la matrice projette (rectangles, cercles, dégradés)
  const onY = (y) => `matrix(${K} ${K / 2} 0 ${-K} ${r1(OX - y * K)} ${r1(OY + (y * K) / 2)})`;   // (x, z) sur le plan y
  const onX = (x) => `matrix(${-K} ${K / 2} 0 ${-K} ${r1(OX + x * K)} ${r1(OY + (x * K) / 2)})`;  // (y, z) sur le plan x
  const onZ = (z) => `matrix(${K} ${K / 2} ${-K} ${K / 2} ${OX} ${r1(OY - z * K)})`;              // (x, y) sur le plan z
  const at = (x, y, z) => { const [X, Y] = P(x, y, z); return { x: r1(X), y: r1(Y) }; };

  // Toit à deux pans, faîtage selon y (le pignon regarde l'avant-gauche, les panneaux le soleil à droite)
  const R = { x0: 6, x1: 13, y0: 2, y1: 10.5, wall: 4.4, ridgeX: 9.5, ridgeZ: 7.7, o: 0.45 };
  const run = R.ridgeX - R.x0, rise = R.ridgeZ - R.wall, slope = Math.hypot(run, rise);
  const SC = run / slope, SS = rise / slope;                       // cosinus, sinus de la pente
  const eaveZ = R.wall - R.o * (rise / run), eaveX = R.x1 + R.o;   // bas du pan droit (débord compris)
  // Pan droit : u = distance le long de la pente depuis l'égout, v = y
  const f3 = (v) => +v.toFixed(3);
  const onRoof = (lift = 0) => `matrix(${f3(-SC * K)} ${f3(-(SC / 2 + SS) * K)} ${-K} ${K / 2} ${f3(OX + eaveX * K)} ${f3(OY + (eaveX * K) / 2 - (eaveZ + lift) * K)})`;
  const roofPt = (u, v, lift = 0.08) => [eaveX - u * SC, v, eaveZ + u * SS + lift];

  // Rectangle à coins arrondis (plan z) : [x, y, angle de la normale sortante en degrés], sens horaire depuis l'est
  function rrect(x0, y0, x1, y1, r, n = 6) {
    const out = [], arc = (cx, cy, a0) => { for (let i = 0; i <= n; i++) { const d = a0 + (90 * i) / n, a = (d * Math.PI) / 180; out.push([cx + r * Math.cos(a), cy + r * Math.sin(a), d]); } };
    arc(x1 - r, y0 + r, -90); arc(x1 - r, y1 - r, 0); arc(x0 + r, y1 - r, 90); arc(x0 + r, y0 + r, 180);
    return out;
  }

  // Enveloppe convexe de points écran (chaîne monotone) : silhouette de la voiture pour le masque de la verrière
  function hull(pts0) {
    const a = pts0.slice().sort((p, q) => p[0] - q[0] || p[1] - q[1]), cr = (o, p, q) => (p[0] - o[0]) * (q[1] - o[1]) - (p[1] - o[1]) * (q[0] - o[0]);
    const lo = [], hi = [];
    for (const p of a) { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
    for (const p of a.reverse()) { while (hi.length > 1 && cr(hi[hi.length - 2], hi[hi.length - 1], p) <= 0) hi.pop(); hi.push(p); }
    return lo.slice(0, -1).concat(hi.slice(0, -1));
  }

  /* ─── Implantation ─────────────────────────────────────────────────── */
  // e-Niro (4,4 × 1,8 m) garée sous l'abri. L'abri est assez bas (2,5 m) et assez large pour qu'aucune pièce
  // de sa structure ne passe devant la voiture à l'écran : poteaux et poutres restent à côté d'elle.
  const CAR = { x0: 15.0, x1: 16.8, y0: 3.7 };
  CAR.y1 = CAR.y0 + 4.45;
  const CP = { x0: 13.5, x1: 20.22, y0: 3.35, y1: 11.35, z: 2.5, px: 19.95 };   // abri : verrière, poteaux en px
  const POLE = [1.4, 12.9], INS = [1.4, 12.05, 7.84], INS2 = [1.4, 13.75, 7.84];   // poteau, isolateurs (traverse selon y)
  const BRK = [6.12, 10.6, 3.95];                   // potelet de la façade (arrivée de la ligne)
  const PORT = [15.9, CAR.y1 + 0.02, 0.66];         // prise de l'e-Niro (dans la calandre)
  const WB = { y0: 9.3, y1: 9.98, z0: 0.98, z1: 1.92 };   // borne murale (mur droit)
  const WBX = [13.27, 9.64, 1.05];                  // sortie du câble de la borne
  // Coffret (onduleurs + tableau) sur le mur droit, sous la gouttière, au-dessus de la borne : le nœud central
  const HUB = { x0: 13, x1: 13.3, y0: 9.12, y1: 10.16, z0: 2.44, z1: 3.32 };
  const HUBF = [13.15, HUB.y1 + 0.01, 2.86], HUBB = [13.15, HUB.y0 - 0.01, 2.62], HUBT = [13.15, 9.65, HUB.z1 + 0.01], HUBD = [13.15, 9.64, HUB.z0 - 0.01];
  const BUSZ = 3.6, RISER = 6.65;                   // goulotte de façade (au-dessus des fenêtres), descente vers la batterie
  const GUT = { x: 13.56, z: 3.95 };                // gouttière (collecte des panneaux)
  const FLUE = [11.0, 1.95, 7.7 - (11.0 - 9.5) * (3.3 / 3.5)];   // pied du conduit du poêle, sur le pan des panneaux
  const ATTIC = [R.ridgeX, R.y1, 5.7];               // œil-de-bœuf du pignon

  /* ─── Trajets de l'énergie (points écran) ─────────────────────────── */
  const bez = (a, c, b, n = 14) => Array.from({ length: n + 1 }, (_, i) => { const t = i / n, s = 1 - t; return [s * s * a[0] + 2 * s * t * c[0] + t * t * b[0], s * s * a[1] + 2 * s * t * c[1] + t * t * b[1]]; });
  const line = (...w) => w.map((p) => P(...p));
  // Ligne aérienne : chaînette approchée (flèche au milieu)
  const sag = (a, b, d, n = 16) => Array.from({ length: n + 1 }, (_, i) => { const t = i / n; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t + 4 * d * t * (1 - t)]; });
  // La ligne publique arrive de la gauche (direction monde (−1, +1)) et s'arrête juste au-delà du bord du décor :
  // tout le trajet animé est visible, rien ne tourne hors champ
  const edge = (p, d) => P(p[0] - d, p[1] + d, p[2] + 0.2);
  const reach = (p) => (P(...p)[0] + 3) / (2 * K);   // recul (selon x et y) qui amène le point 3 unités hors du cadre
  const wireIn = sag(edge(INS, reach(INS)), P(...INS), 2.4, 8);       // bord → isolateur
  const drop = sag(P(...INS), P(...BRK), 8);                            // isolateur → potelet (branchement)
  const cable = bez(P(...WBX), P(14.7, 9.55, -0.5), P(...PORT));
  // Nœud central → coin de la façade → goulotte, le long du haut du mur avant
  const busPts = [HUBF, [13.02, 10.53, 2.86], [13.02, 10.53, BUSZ]];
  const toBat = [[RISER, 10.53, BUSZ], [RISER, 10.53, 0.08], [RISER, 11.45, 0.06], [4.45, 11.45, 0.1]];
  const toBrk = [[6.3, 10.53, BUSZ], [6.16, 10.58, 3.78]];
  const lanes = [2.88, 6.2, 9.52].map((v) => line(roofPt(4.9, v), roofPt(-0.06, v)));
  const rev = (a) => a.slice().reverse();
  // Chaque trajet : points, puis le morceau qui porte la flèche fixe (mouvement réduit) : [de, à] en indices
  const mk = (a, from, to) => ({ pts: a, seg: [from, to] });
  const gridOutPts = [...line(...busPts, ...toBrk), ...drop.slice().reverse(), ...rev(wireIn).slice(1)];
  const gOut0 = busPts.length + toBrk.length, gOut1 = gOut0 + drop.length - 1;   // morceau potelet → isolateur
  const batInPts = line(...busPts, ...toBat);
  const nb = batInPts.length;
  const ROUTES = {
    sun0: mk(lanes[0], 0, 1), sun1: mk(lanes[1], 0, 1), sun2: mk(lanes[2], 0, 1),
    sun: mk(line([GUT.x, 2.7, GUT.z], [GUT.x, 9.56, GUT.z], [13.4, 9.62, 3.6], HUBT), 0, 1),
    gridOut: mk(gridOutPts, gOut0, gOut1), gridIn: mk(rev(gridOutPts), gridOutPts.length - 1 - gOut1, gridOutPts.length - 1 - gOut0),
    batIn: mk(batInPts, nb - 2, nb - 1), batOut: mk(rev(batInPts), 0, 1),
    car: mk([...line(HUBD, [13.13, 9.64, WB.z1], [13.27, 9.64, 1.6]), ...cable], 3, 3 + cable.length - 1),
    home: mk(line(HUBB, [13.02, 9.05, 2.2], [13.02, 5.1, 2.2]), 1, 2),
  };
  // Teintes : celles du schéma partagé (flow.js) ; la consommation de la maison prend la lumière intérieure (jaune
  // chaud), jamais le rouge de l'achat. Les voies des panneaux brillent par-dessus les cellules (fusion « screen »).
  const LINKS = {
    sun0: { cap: 3, tone: "solar", lane: 1, lag: 0, spd: 0.94 }, sun1: { cap: 3, tone: "solar", lane: 1, lag: 1 / 3, spd: 1.03 }, sun2: { cap: 3, tone: "solar", lane: 1, lag: 2 / 3, spd: 0.98 },
    sun: { cap: 4, tone: "solar" },
    gridIn: { cap: 4, tone: "bad" }, gridOut: { cap: 4, tone: "grid" },
    batIn: { cap: 4, tone: "battery" }, batOut: { cap: 4, tone: "battery" },
    car: { cap: 4, tone: "ev" },
    home: { cap: 3, tone: "light" },
  };
  // Longueur, images clés régulièrement espacées (vitesse constante, fondu aux extrémités), flèche fixe (mouvement réduit)
  for (const [k, L] of Object.entries(LINKS)) {
    const p = (L.pts = ROUTES[k].pts), cum = [0];
    for (let i = 1; i < p.length; i++) cum.push(cum[i - 1] + Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]));
    L.len = cum[cum.length - 1];
    const pos = (d) => { let i = 1; while (i < cum.length - 1 && cum[i] < d) i++; const t = (d - cum[i - 1]) / (cum[i] - cum[i - 1] || 1); return [p[i - 1][0] + (p[i][0] - p[i - 1][0]) * t, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * t]; };
    const n = Math.max(8, Math.round(L.len / 3)), fade = Math.min(0.18, 7 / L.len);
    L.frames = Array.from({ length: n + 1 }, (_, i) => {
      const t = i / n, [X, Y] = pos(t * L.len);
      return { offset: t, transform: `translate(${X.toFixed(2)}px,${Y.toFixed(2)}px)`, opacity: Math.min(1, t / fade, (1 - t) / fade) };
    });
    const [s0, s1] = ROUTES[k].seg, am = (cum[s0] + cum[s1]) / 2, m = pos(am - 1), m2 = pos(am + 1);
    L.mid = { x: r1((m[0] + m2[0]) / 2), y: r1((m[1] + m2[1]) / 2), a: Math.round((Math.atan2(m2[1] - m[1], m2[0] - m[0]) * 180) / Math.PI) };
    L.d = poly(p);
  }

  /* ─── Décor ─────────────────────────────────────────────────────────
     Les éléments principaux se touchent aussi sur le dessin (hh-tap + data-act, même gestionnaire que le
     reste de l'application) ; au clavier et au lecteur d'écran, ce sont les pastilles qui portent ces actions. */
  let ART = null;
  function art() {
    if (ART) return ART;
    const o = [];
    /* Îlot : dessus en gazon, tranche arrondie (ombrée à gauche, éclairée à droite) */
    const I = { x0: 0, y0: 0, x1: 21, y1: 14.6, r: 1.6, t: 1.4 };
    const ring = rrect(I.x0, I.y0, I.x1, I.y1, I.r);
    // Tranche visible : normales tournées vers l'observateur (entre −45° et 135°)
    const fr = ring.filter(([, , d]) => d >= -45 && d <= 135);
    const top = ring.map(([x, y]) => [x, y, 0]);
    const band = [...fr.map(([x, y]) => [x, y, 0]), ...fr.slice().reverse().map(([x, y]) => [x, y, -I.t])];
    const sx = P(I.x1, I.y1)[0], sr = I.r * K;
    o.push(`<ellipse class="hh-isl-sh" filter="url(#hh-blur6)" cx="${r1(P(I.x1 / 2, I.y1 / 2, -I.t)[0])}" cy="${r1(P(I.x1, I.y1, -I.t)[1] - 6)}" rx="140" ry="15"/>`);
    o.push(`<defs><linearGradient id="hh-side" gradientUnits="userSpaceOnUse" x1="${r1(sx - sr * 1.2)}" x2="${r1(sx + sr * 1.2)}" y1="0" y2="0"><stop offset="0" class="hh-st-sy"/><stop offset="1" class="hh-st-sx"/></linearGradient>
      <linearGradient id="hh-depth" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="${r1(P(0, I.y1, 0)[1])}" y2="${r1(P(I.x1, I.y1, -I.t)[1])}"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".16"/></linearGradient></defs>`);
    o.push(pg("hh-isl-side", band), pg("hh-isl-depth", band));
    o.push(pg("hh-isl-lip", [...fr.map(([x, y]) => [x, y, 0]), ...fr.slice().reverse().map(([x, y]) => [x, y, -0.32])]));
    o.push(pg("hh-isl-top", top));
    // Bandes de tonte sur la pelouse (très discrètes)
    o.push(`<g class="hh-mow" transform="${onZ(0)}" clip-path="url(#hh-clip-top)">${[2, 6, 10, 14, 18].map((x) => `<rect x="${x}" y="0" width="2" height="${I.y1}"/>`).join("")}</g>`);
    o.push(`<clipPath id="hh-clip-top"><polygon points="${ring.map(([x, y]) => `${r1(x)},${r1(y)}`).join(" ")}"/></clipPath>`);
    // Allée pavée sous l'abri, pas japonais devant la porte, dalle de la batterie
    o.push(`<g transform="${onZ(0.01)}">
      <rect class="hh-drive" x="13.55" y="2.3" width="6.9" height="11.6" rx=".5"/>
      ${[4.1, 5.9, 7.7, 9.5, 11.3, 13.1].map((y) => `<rect class="hh-joint" x="13.55" y="${y}" width="6.9" height=".07"/>`).join("")}
      ${[[7.35, 11.15], [7.6, 12.4], [7.35, 13.65]].map(([x, y]) => `<rect class="hh-step" x="${x}" y="${y}" width="1.35" height=".85" rx=".3"/>`).join("")}
      <rect class="hh-bed" x="9.4" y="10.62" width="3.5" height=".95" rx=".45"/>
    </g>`);

    /* Ombres douces (une seule couche floue), puis ombres de contact de la voiture (posée sur l'allée) */
    o.push(`<g class="hh-shadow" filter="url(#hh-blur)" transform="${onZ(0)}">
      <polygon points="5.2,2.6 13.2,2.6 13.6,10.9 5.2,11.5"/>
      <rect x="${CAR.x0 - 0.4}" y="${CAR.y0 - 0.2}" width="2.6" height="5" rx=".7"/>
      <rect x="2.4" y="10.8" width="2.6" height="1.7" rx=".4"/>
      <circle cx="0.8" cy="4.8" r="1.7"/><circle cx="16.4" cy="1.2" r="1.3"/>
      <rect x="${CP.px - 0.05}" y="${CP.y0 + 0.05}" width=".9" height=".6"/><rect x="${CP.px - 0.05}" y="${CP.y1 - 0.4}" width=".9" height=".6"/>
    </g>`);
    {
      const wy = [CAR.y0 + 0.9, CAR.y0 + 3.7];
      o.push(`<g class="hh-ao" filter="url(#hh-blur1)" transform="${onZ(0.01)}">
        <rect x="${CAR.x0 + 0.08}" y="${CAR.y0 + 0.1}" width="${r1(CAR.x1 - CAR.x0 - 0.16)}" height="${r1(CAR.y1 - CAR.y0 - 0.2)}" rx=".35"/>
        ${wy.map((y) => `<ellipse cx="${CAR.x1 - 0.17}" cy="${y}" rx=".24" ry=".46"/><ellipse cx="${CAR.x0 + 0.17}" cy="${y}" rx=".24" ry=".46"/>`).join("")}
      </g>`);
    }

    /* Arbres du fond */
    const tree = (x, y, z, rr) => {
      const b = P(x, y, 0), c = P(x, y, z);
      return `<g class="hh-tree">
        <rect class="hh-trunk" x="${r1(b[0] - 1.6)}" y="${r1(c[1])}" width="3.2" height="${r1(b[1] - c[1])}" rx="1.4"/>
        <circle class="hh-leaf" cx="${r1(c[0] - rr * 0.42)}" cy="${r1(c[1] + rr * 0.18)}" r="${r1(rr * 0.72)}"/>
        <circle class="hh-leaf" cx="${r1(c[0] + rr * 0.38)}" cy="${r1(c[1] + rr * 0.1)}" r="${r1(rr * 0.78)}"/>
        <circle class="hh-leaf" cx="${r1(c[0])}" cy="${r1(c[1] - rr * 0.38)}" r="${r1(rr * 0.82)}"/>
        <circle class="hh-leaf-hi" cx="${r1(c[0] + rr * 0.3)}" cy="${r1(c[1] - rr * 0.62)}" r="${r1(rr * 0.42)}"/>
      </g>`;
    };
    o.push(tree(1.0, 4.4, 4.8, 15), tree(16.8, 0.9, 4.7, 14));

    /* Maison : mur droit (sous l'abri), puis pignon en façade */
    o.push(pg("hh-wall fx", [[R.x1, R.y0, 0], [R.x1, R.y1, 0], [R.x1, R.y1, R.wall], [R.x1, R.y0, R.wall]]));
    o.push(`<g transform="${onX(R.x1)}">
      <rect class="hh-plinth" x="${R.y0}" y="0" width="${R.y1 - R.y0}" height=".32"/>
      <rect class="hh-frame" x="3.7" y="1.45" width="2.4" height="1.95" rx=".06"/><rect class="hh-win" x="3.84" y="1.58" width="2.12" height="1.69"/>
      <rect class="hh-glow" x="3.84" y="1.58" width="2.12" height="1.69"/>
      <rect class="hh-mull" x="4.86" y="1.58" width=".08" height="1.69"/>
      <rect class="hh-eave-sh" x="${R.y0}" y="3.85" width="${R.y1 - R.y0}" height=".55"/>
    </g>`);
    o.push(pg("hh-wall fy", [[R.x0, R.y1, 0], [R.x1, R.y1, 0], [R.x1, R.y1, R.wall], [R.ridgeX, R.y1, R.ridgeZ], [R.x0, R.y1, R.wall]]));
    o.push(`<g transform="${onY(R.y1)}">
      <rect class="hh-plinth" x="${R.x0}" y="0" width="${R.x1 - R.x0}" height=".32"/>
      <polygon class="hh-eave-sh" points="${R.x0},${R.wall} ${R.ridgeX},${R.ridgeZ} ${R.x1},${R.wall} ${R.x1},${R.wall - 0.5} ${R.ridgeX},${R.ridgeZ - 0.55} ${R.x0},${R.wall - 0.5}"/>
      <rect class="hh-frame" x="7.22" y="0" width="1.56" height="2.78" rx=".05"/>
      <rect class="hh-door" x="7.36" y=".02" width="1.28" height="2.64"/>
      <rect class="hh-win" x="7.56" y="1.25" width=".2" height="1.15"/><rect class="hh-glow" x="7.56" y="1.25" width=".2" height="1.15"/>
      <rect class="hh-handle" x="8.36" y="1.18" width=".07" height=".52"/>
      <circle class="hh-lamp" cx="9.05" cy="2.3" r=".15"/>
      <g class="hh-tap" data-act="open-sheet" data-sheet="ballon">
      <rect class="hh-frame" x="10.18" y=".86" width="2.34" height="2.6" rx=".06"/>
      <rect class="hh-room" x="10.32" y="1" width="2.06" height="2.32"/><rect class="hh-glow" x="10.32" y="1" width="2.06" height="2.32"/>
      <g class="hh-tank">
        <rect class="hh-tank-b" x="10.8" y="1.02" width="1.08" height="2.05" rx=".5" ry=".22"/>
        <rect class="hh-tank-h" x="10.8" y="1.02" width="1.08" height="2.05" rx=".5" ry=".22"/>
        <rect class="hh-tank-l" x="10.95" y="1.5" width=".14" height="1.2" rx=".07"/>
        <path class="hh-pipe" d="M11.15 1.02V.98M11.55 1.02V.98"/>
      </g>
      <polygon class="hh-refl" points="10.32,2.2 11.2,3.32 11.75,3.32 10.32,1.5"/>
      <rect class="hh-sill" x="10.05" y=".72" width="2.6" height=".15"/>
      </g>
      <g class="hh-oculus">
        <circle class="hh-frame" cx="${R.ridgeX}" cy="${ATTIC[2]}" r=".62"/>
        <circle class="hh-room" cx="${R.ridgeX}" cy="${ATTIC[2]}" r=".5"/><circle class="hh-glow-a" cx="${R.ridgeX}" cy="${ATTIC[2]}" r=".5"/>
        <path class="hh-oc-m" d="M${R.ridgeX} ${ATTIC[2] - 0.5}V${ATTIC[2] + 0.5}M${R.ridgeX - 0.5} ${ATTIC[2]}H${R.ridgeX + 0.5}"/>
        <path class="hh-oc-r" d="M${R.ridgeX - 0.38} ${ATTIC[2] + 0.12}A.4 .4 0 0 1 ${R.ridgeX - 0.08} ${ATTIC[2] + 0.38}"/>
        <rect class="hh-sill" x="${R.ridgeX - 0.42}" y="${ATTIC[2] - 0.72}" width=".84" height=".1" rx=".03"/>
      </g>
    </g>`);
    // Auvent de la porte
    o.push(box("hh-canopy", [7.05, R.y1, 2.9], [8.95, R.y1 + 0.75, 3.05]));
    // Lumière des fenêtres sur la pelouse (soir, nuit)
    o.push(`<g class="hh-spill" filter="url(#hh-blur)" transform="${onZ(0.02)}"><ellipse cx="11.3" cy="11.75" rx="1.5" ry=".85"/><ellipse cx="8" cy="11.6" rx=".8" ry=".55"/></g>`);
    // Massif devant la fenêtre
    o.push([[9.9, 11.1, 0.42], [10.9, 11.15, 0.5], [11.9, 11.1, 0.44], [12.7, 11.15, 0.36]].map(([x, y, rr]) => { const c = P(x, y, rr * 0.9); return `<circle class="hh-bush" cx="${r1(c[0])}" cy="${r1(c[1])}" r="${r1(rr * K)}"/>`; }).join(""));

    /* Réseau électrique de la maison : coffret, goulotte de façade, descente vers la batterie, borne */
    // Goulotte : du coffret au coin, puis tout le haut de la façade jusqu'au potelet ; descente le long du mur
    o.push(`<path class="hh-conduit" d="${poly(line(...busPts, [6.3, 10.53, BUSZ], ...toBrk))}"/>`);
    o.push(`<path class="hh-conduit" d="${poly(line([RISER, 10.53, BUSZ], [RISER, 10.53, 0.08]))}"/>`);
    o.push(`<path class="hh-conduit" d="${poly(line(HUBB, [13.02, 9.05, 2.2], [13.02, 6.15, 2.2]))}"/>`);
    o.push(box("hh-metal", [6.02, R.y1, 3.6], [6.2, R.y1 + 0.18, 4.15]));
    // Borne murale (boîtier, anneau lumineux) et liaison au coffret
    o.push(`<path class="hh-conduit" d="${poly(line(HUBD, [13.13, 9.64, WB.z1]))}"/>`);
    o.push(box("hh-wb", [13, WB.y0, WB.z0], [13.26, WB.y1, WB.z1]));
    o.push(`<g transform="${onX(13.27)}"><circle class="hh-wb-ring" cx="${WBX[1]}" cy="1.5" r=".2"/><circle class="hh-wb-led" cx="${WBX[1]}" cy="1.5" r=".09"/></g>`);
    // Coffret : boîtier clair, petit écran et voyant (ambre quand les panneaux produisent)
    o.push(box("hh-hub", [HUB.x0, HUB.y0, HUB.z0], [HUB.x1, HUB.y1, HUB.z1]));
    o.push(`<g transform="${onX(HUB.x1 + 0.01)}"><rect class="hh-hub-d" x="9.28" y="2.84" width=".66" height=".3" rx=".04"/><circle class="hh-hub-led" cx="10.0" cy="2.64" r=".06"/>
      <rect class="hh-hub-v" x="9.28" y="2.56" width=".5" height=".045"/><rect class="hh-hub-v" x="9.28" y="2.66" width=".5" height=".045"/></g>`);
    // Câble rangé (voiture débranchée) : boucle accrochée sous la borne
    o.push(`<path class="hh-cable hh-cable-off" d="M${xy(P(...WBX))}C${xy(P(13.6, 10.3, 0.4))} ${xy(P(13.9, 9.5, 0.25))} ${xy(P(13.3, 9.47, 0.9))}"/>`);

    /* Toit : pan arrière (liseré), pan des panneaux avec le conduit du poêle, rives */
    o.push(pg("hh-roof-b", [[R.ridgeX, R.y0 - R.o, R.ridgeZ], [R.x0 - R.o, R.y0 - R.o, eaveZ], [R.x0 - R.o, R.y1 + R.o, eaveZ], [R.ridgeX, R.y1 + R.o, R.ridgeZ]]));
    o.push(pg("hh-roof", [[R.ridgeX, R.y0 - R.o, R.ridgeZ], [R.ridgeX, R.y1 + R.o, R.ridgeZ], [eaveX, R.y1 + R.o, eaveZ], [eaveX, R.y0 - R.o, eaveZ]]));
    // Conduit inox du poêle à granulés (cylindre : corps dégradé, chapeau conique)
    {
      const fb = P(...FLUE), ft = P(FLUE[0], FLUE[1], FLUE[2] + 1.35), w = 2 * Math.SQRT2 * 0.15 * K, e = w / 4;
      o.push(`<g class="hh-flue"><rect class="hh-flue-b" x="${r1(ft[0] - w / 2)}" y="${r1(ft[1])}" width="${r1(w)}" height="${r1(fb[1] - ft[1])}"/>
        <ellipse class="hh-flue-r" cx="${r1(ft[0])}" cy="${r1(ft[1] + 3)}" rx="${r1(w / 2 + 0.6)}" ry="${r1(e + 0.3)}"/>
        <path class="hh-flue-c" d="M${r1(ft[0] - w / 2 - 2.2)},${r1(ft[1] - 1.4)}L${r1(ft[0])},${r1(ft[1] - 4.6)}L${r1(ft[0] + w / 2 + 2.2)},${r1(ft[1] - 1.4)}Q${r1(ft[0])},${r1(ft[1])} ${r1(ft[0] - w / 2 - 2.2)},${r1(ft[1] - 1.4)}Z"/></g>`);
    }
    // Panneaux : 2 rangées × 5, cadre alu, cellules, reflet
    const cols = [2.08, 3.74, 5.4, 7.06, 8.72], rows = [[0.42, 2.12], [2.66, 2.12]];
    o.push(`<g class="hh-tap" data-act="spot" data-spot="en-sun" transform="${onRoof(0.07)}">
      <rect class="hh-pv-rail" x=".3" y="1.96" width="4.6" height="8.46" rx=".08"/>
      ${rows.map(([u, du]) => cols.map((v) => `<rect class="hh-pv" x="${u}" y="${v}" width="${du}" height="1.56" rx=".05"/>
        <path class="hh-pv-cell" d="M${u + du / 3} ${v}v1.56M${u + (2 * du) / 3} ${v}v1.56M${u} ${v + 0.78}h${du}"/>`).join("")).join("")}
      <rect class="hh-pv-sheen" x=".3" y="1.96" width="4.6" height="8.46"/>
    </g>`);
    o.push(`<path class="hh-ridge" d="M${xy(P(R.ridgeX, R.y0 - R.o, R.ridgeZ + 0.04))}L${xy(P(R.ridgeX, R.y1 + R.o, R.ridgeZ + 0.04))}"/>`);
    o.push(`<g transform="${onX(eaveX)}"><rect class="hh-fascia fx" x="${R.y0 - R.o}" y="${r1((eaveZ - 0.28) * 100) / 100}" width="${R.y1 - R.y0 + 2 * R.o}" height=".28"/></g>`);
    o.push(`<g transform="${onY(R.y1 + R.o)}"><polygon class="hh-fascia fy" points="${R.x0 - R.o},${eaveZ} ${R.ridgeX},${R.ridgeZ} ${eaveX},${eaveZ} ${eaveX},${eaveZ - 0.3} ${R.ridgeX},${R.ridgeZ - 0.32} ${R.x0 - R.o},${eaveZ - 0.3}"/></g>`);
    // Gouttière sous les panneaux : elle recueille les voies du soleil et descend dans le coffret
    o.push(box("hh-gutter", [eaveX, R.y0 - R.o + 0.05, 3.8], [eaveX + 0.2, R.y1 + R.o - 0.05, 3.95]));
    o.push(`<path class="hh-conduit hh-down" d="${poly(line([GUT.x, 9.6, 3.82], [13.4, 9.62, 3.6], HUBT))}"/>`);

    /* Abri vitré : poteaux, borne déjà posée, e-Niro, puis poutres et verrière */
    o.push(box("hh-post", [CP.px, CP.y0 + 0.1, 0], [CP.px + 0.25, CP.y0 + 0.35, CP.z - 0.2]));
    // e-Niro : caisse argile lavande, vitrages sombres, prise lumineuse dans la calandre
    // Silhouette de crossover : caisse haute, capot court, hayon presque vertical, bas de caisse et passages de roue noirs
    const cx0 = CAR.x0, cx1 = CAR.x1, cy0 = CAR.y0, cy1 = CAR.y1, ci0 = 15.13, ci1 = 16.67, Y = (d) => r1((cy0 + d) * 100) / 100;
    const ws = Y(3.42), wt = Y(2.7), rt = Y(0.36), rr = Y(0.16), zb = 0.34, zw = 1.06, zr = 1.68, zh = 0.98, zn = 0.86;
    o.push(`<g class="hh-car hh-tap" data-act="nav" data-to="vehicle">
      ${pg("hh-car-t", [[cx0, cy0, zw], [cx1, cy0, zw], [cx1, rr, zw], [cx0, rr, zw]])}
      ${pg("hh-car-t", [[cx0, rr, zw], [ci0, rr, zw], [ci0, ws, zw], [cx0, ws, zw]])}
      ${pg("hh-car-t", [[ci1, rr, zw], [cx1, rr, zw], [cx1, ws, zw], [ci1, ws, zw]])}
      ${pg("hh-car-x", [[ci1, rr, zw], [ci1, ws, zw], [ci1, wt, zr], [ci1, rt, zr]])}
      <g transform="${onX(ci1)}">
        <polygon class="hh-car-gl" points="${r1(rr + 0.16)},${zw + 0.04} ${r1(ws - 0.12)},${zw + 0.04} ${r1(wt + 0.04)},${zr - 0.07} ${r1(rt + 0.05)},${zr - 0.07}"/>
        <polygon class="hh-car-x" points="${Y(1.68)},${zw} ${Y(1.86)},${zw} ${Y(1.82)},${zr} ${Y(1.66)},${zr}"/>
        <polygon class="hh-car-hi" points="${r1(rt + 0.3)},${zr - 0.1} ${Y(1.4)},${zr - 0.1} ${Y(1.1)},${zw + 0.1} ${r1(rr + 0.45)},${zw + 0.1}"/>
      </g>
      ${pg("hh-car-t", [[ci0, rt, zr], [ci1, rt, zr], [ci1, wt, zr], [ci0, wt, zr]])}
      <path class="hh-car-rail" d="M${xy(P(ci0 + 0.16, rt + 0.1, zr + 0.03))}L${xy(P(ci0 + 0.16, wt - 0.15, zr + 0.03))}M${xy(P(ci1 - 0.16, rt + 0.1, zr + 0.03))}L${xy(P(ci1 - 0.16, wt - 0.15, zr + 0.03))}"/>
      ${pg("hh-car-gl hh-car-ws", [[ci0, ws, zw], [ci1, ws, zw], [ci1, wt, zr], [ci0, wt, zr]])}
      ${pg("hh-car-hi", [[ci0 + 0.25, ws - 0.05, zw + 0.05], [ci0 + 0.75, ws - 0.05, zw + 0.05], [ci0 + 1.05, wt + 0.05, zr - 0.04], [ci0 + 0.55, wt + 0.05, zr - 0.04]])}
      ${pg("hh-car-t", [[cx0, ws, zw], [cx1, ws, zw], [cx1, cy1 - 0.28, zh], [cx0, cy1 - 0.28, zh]])}
      ${pg("hh-car-t2", [[cx0, cy1 - 0.28, zh], [cx1, cy1 - 0.28, zh], [cx1, cy1, zn], [cx0, cy1, zn]])}
      <g transform="${onX(cx1)}">
        <polygon class="hh-car-x" points="${cy0},${zb} ${cy1},${zb} ${cy1},${zn} ${r1(cy1 - 0.28)},${zh} ${ws},${zw} ${cy0},${zw}"/>
        <polygon class="hh-car-clad" points="${cy0},${zb} ${cy1},${zb} ${cy1},${zb + 0.26} ${cy0},${zb + 0.26}"/>
        <path class="hh-car-line" d="M${Y(1.78)} ${zb + 0.22}V${zw - 0.03}M${r1(cy0 + 0.1)} .84H${ws}"/>
        ${[Y(0.9), Y(3.7)].map((y) => `<circle class="hh-arch" cx="${y}" cy=".36" r=".5"/><circle class="hh-tire" cx="${y}" cy=".36" r=".36"/><circle class="hh-rim" cx="${y}" cy=".36" r=".21"/>`).join("")}
        <rect class="hh-tail" x="${cy0}" y=".86" width=".1" height=".14"/>
        <rect class="hh-headx" x="${r1(cy1 - 0.22)}" y=".72" width=".2" height=".08"/>
      </g>
      <g transform="${onY(cy1)}">
        <polygon class="hh-car-y" points="${cx0 + 0.1},${zb} ${cx1 - 0.1},${zb} ${cx1},.48 ${cx1},${zn} ${cx0},${zn} ${cx0},.48"/>
        <rect class="hh-car-clad" x="${cx0 + 0.12}" y="${zb}" width="${r1(cx1 - cx0 - 0.24)}" height=".12" rx=".04"/>
        <rect class="hh-head" x="${cx0 + 0.04}" y=".72" width=".5" height=".07" rx=".035"/><rect class="hh-head" x="${r1(cx1 - 0.54)}" y=".72" width=".5" height=".07" rx=".035"/>
        <rect class="hh-grille" x="${cx0 + 0.45}" y=".4" width="${r1(cx1 - cx0 - 0.9)}" height=".14" rx=".05"/>
        <rect class="hh-port" x="${r1(PORT[0] - 0.16)}" y=".58" width=".32" height=".16" rx=".05"/>
      </g>
    </g>`);
    // Câble branché (recharge)
    o.push(`<path class="hh-cable hh-cable-on" d="${poly(cable)}"/>`);
    // Verrière : seul le verre passe devant la voiture ; il s'efface là où il la couvre (masque tiré de sa
    // silhouette), pour que l'e-Niro reste nette. Poutres et poteau avant restent à côté d'elle, pleins.
    {
      const body = [], cabin = [];
      for (const x of [cx0, cx1]) { for (const y of [cy0, cy1]) body.push(P(x, y, 0.06), P(x, y, zn)); body.push(P(x, cy0, zw), P(x, ws, zw), P(x, cy1 - 0.28, zh)); }
      for (const x of [ci0, ci1]) cabin.push(P(x, rr, zw), P(x, ws, zw), P(x, rt, zr), P(x, wt, zr));
      o.push(`<mask id="hh-carm" maskUnits="userSpaceOnUse" x="0" y="0" width="${VW}" height="${VH}"><rect width="${VW}" height="${VH}" fill="#fff"/>
        <g class="hh-carm" filter="url(#hh-blur1)">${[body, cabin].map((a) => `<polygon points="${hull(a).map(xy).join(" ")}"/>`).join("")}</g></mask>`);
    }
    o.push(box("hh-post", [CP.px, CP.y1 - 0.35, 0], [CP.px + 0.25, CP.y1 - 0.1, CP.z - 0.2]));
    o.push(box("hh-beam", [CP.x0, CP.y0, CP.z - 0.18], [CP.x1, CP.y0 + 0.09, CP.z]));
    o.push(box("hh-beam", [CP.px - 0.02, CP.y0, CP.z - 0.2], [CP.x1, CP.y1, CP.z]));
    o.push(`<g mask="url(#hh-carm)"><g transform="${onZ(CP.z + 0.01)}"><rect class="hh-glass" x="${CP.x0}" y="${CP.y0}" width="${r1(CP.x1 - CP.x0)}" height="${CP.y1 - CP.y0}"/>${[5.35, 7.35, 9.35].map((y) => `<rect class="hh-glass-m" x="${CP.x0}" y="${y}" width="${r1(CP.x1 - CP.x0)}" height=".07"/>`).join("")}
      <polygon class="hh-glass-hi" points="15.4,${CP.y0} 16.5,${CP.y0} 14.6,${CP.y1} ${CP.x0},${CP.y1} ${CP.x0},10.5"/></g></g>`);
    o.push(box("hh-beam", [CP.x0, CP.y1 - 0.09, CP.z - 0.18], [CP.x1, CP.y1, CP.z]));

    /* Batterie (3 modules + boîtier de tête) sur sa dalle, gaine vers la façade */
    o.push(`<path class="hh-duct" d="${poly(line(...toBat.slice(1)))}"/>`);
    o.push(`<g class="hh-tap" data-act="spot" data-spot="en-bat">`);
    o.push(box("hh-pad", [2.72, 10.72, 0], [4.7, 12.2, 0.12]));
    o.push(box("hh-bat-core", [3.1, 11.1, 0.12], [4.3, 11.82, 2.36]));
    [[0.14, 0.8], [0.86, 1.52], [1.58, 2.24]].forEach(([z0, z1]) => o.push(box("hh-bat", [3.0, 11.0, z0], [4.4, 11.9, z1])));
    o.push(box("hh-bat-hub", [2.96, 10.96, 2.3], [4.44, 11.94, 2.7]));
    o.push(`<g transform="${onY(11.94)}"><rect class="hh-bat-led" x="3.25" y="2.48" width=".98" height=".07" rx=".035"/></g>
      <g transform="${onY(11.9)}"><rect class="hh-bat-track" x="4.12" y=".3" width=".12" height="1.82" rx=".06"/></g></g>`);

    /* Réseau : poteau, traverse, isolateurs, coffret du compteur, lignes */
    const ph = P(POLE[0], POLE[1], 0), pt = P(POLE[0], POLE[1], 8.2);
    o.push(`<g class="hh-tap" data-act="spot" data-spot="en-grd"><rect class="hh-hit" x="${r1(ph[0] - 12)}" y="${r1(pt[1])}" width="34" height="${r1(ph[1] - pt[1] + 6)}"/>`);
    o.push(box("hh-meter", [2.1, 13.05, 0], [2.9, 13.55, 1.35]));
    o.push(`<g transform="${onY(13.55)}"><rect class="hh-meter-d" x="2.25" y=".78" width=".5" height=".3" rx=".05"/><circle class="hh-meter-led" cx="2.5" cy=".52" r=".07"/></g>`);
    o.push(`<path class="hh-wire" d="${poly(sag(edge(INS2, reach(INS2)), P(...INS2), 2, 8))}"/>`);
    o.push(box("hh-pole", [POLE[0] - 0.16, POLE[1] - 0.16, 0], [POLE[0] + 0.16, POLE[1] + 0.16, 7.6]));
    o.push(box("hh-pole", [POLE[0] - 0.12, 11.85, 7.38], [POLE[0] + 0.12, 13.95, 7.58]));
    o.push(box("hh-ins", [1.33, INS[1] - 0.07, 7.58], [1.47, INS[1] + 0.07, 7.84]), box("hh-ins", [1.33, INS2[1] - 0.07, 7.58], [1.47, INS2[1] + 0.07, 7.84]), "</g>");
    o.push(`<path class="hh-wire" d="${poly([...wireIn, ...drop.slice(1)])}"/>`);

    /* Buissons du premier plan (ceux du coin avant, hh-bush-f, cèdent la place à l'étiquette « En direct » de l'Aperçu) */
    o.push([[5.2, 13.4, 0.5], [5.85, 13.95, 0.36], [20.55, 12.6, 0.42], [20.3, 13.45, 0.3]].map(([x, y, rr]) => { const c = P(x, y, rr * 0.9); return `<circle class="hh-bush${x > 20 ? " hh-bush-f" : ""}" cx="${r1(c[0])}" cy="${r1(c[1])}" r="${r1(rr * K)}"/>`; }).join(""));

    ART = {
      // Contenu du SVG du décor : injecté une fois après le rendu (voir after()), jamais recomparé par BZ.morph
      inner: `<defs>
          <filter id="hh-blur" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="2.2"/></filter>
          <filter id="hh-blur1" x="-10%" y="-10%" width="120%" height="120%"><feGaussianBlur stdDeviation="1.1"/></filter>
          <filter id="hh-blur6" x="-30%" y="-80%" width="160%" height="260%"><feGaussianBlur stdDeviation="7"/></filter>
          <linearGradient id="hh-pvg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" class="hh-st-pv1"/><stop offset="1" class="hh-st-pv2"/></linearGradient>
          <linearGradient id="hh-sheen" x1="0" y1="0" x2="1" y2="1"><stop offset=".18" stop-color="#fff" stop-opacity="0"/><stop offset=".42" stop-color="#fff" stop-opacity=".34"/><stop offset=".5" stop-color="#fff" stop-opacity=".1"/><stop offset=".62" stop-color="#fff" stop-opacity=".22"/><stop offset=".8" stop-color="#fff" stop-opacity="0"/></linearGradient>
          <linearGradient id="hh-tankg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" class="hh-st-t1"/><stop offset=".55" class="hh-st-t2"/><stop offset="1" class="hh-st-t3"/></linearGradient>
          <linearGradient id="hh-heat" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ff7a3d" stop-opacity=".95"/><stop offset=".6" stop-color="#ffb04a" stop-opacity=".55"/><stop offset="1" stop-color="#ffd27a" stop-opacity=".15"/></linearGradient>
          <linearGradient id="hh-steel" x1="0" y1="0" x2="1" y2="0"><stop offset="0" class="hh-st-s1"/><stop offset=".45" class="hh-st-s2"/><stop offset="1" class="hh-st-s3"/></linearGradient>
          <radialGradient id="hh-warm" cx=".42" cy=".4" r=".7"><stop offset="0" stop-color="#fff4d6"/><stop offset=".55" stop-color="#ffd27e"/><stop offset="1" stop-color="#f3a948"/></radialGradient>
          <radialGradient id="hh-leafg" cx=".68" cy=".28" r=".85"><stop offset="0" class="hh-st-l1"/><stop offset="1" class="hh-st-l2"/></radialGradient>
          <linearGradient id="hh-isl" gradientUnits="userSpaceOnUse" x1="${r1(P(I.x1, 0)[0])}" y1="${r1(P(I.x1, 0)[1])}" x2="${r1(P(0, I.y1)[0])}" y2="${r1(P(0, I.y1)[1])}"><stop offset="0" class="hh-st-g1"/><stop offset="1" class="hh-st-g2"/></linearGradient>
        </defs>
        ${o.join("")}`,
    };
    return ART;
  }

  /* ─── Données en direct ─────────────────────────────────────────── */
  const IDLE = BZ.FLOW_IDLE || 15;
  const has = Number.isFinite, pw = (w) => (has(w) ? fmt.powerText(w) : "—");   // capteur indisponible : « — »
  const speed = (w) => BZ.clamp(12 + 19 * Math.sqrt(w / 1000), 12, 58);          // unités du viewBox par seconde
  // Nombre de points visibles : il ne dépend que de la puissance (1 sous 200 W, 2 sous 600 W, 3 sous 1,5 kW, 4 au-delà),
  // jamais de la longueur du trajet : la source principale reste la plus dense, même sur un trajet court
  const TIERS = [200, 600, 1500];
  const tier = (w) => 1 + TIERS.filter((t) => w >= t).length;
  // Avec hystérésis (±20 % autour de chaque seuil) : les variations de quelques watts ne font pas apparaître
  // ni disparaître de points. Un changement d'un seul palier attend un deuxième relevé qui le confirme (au moins
  // 4 s plus tard) ; un grand écart (deux paliers ou plus) s'affiche tout de suite.
  const memo = {};
  function count(k, w, cap) {
    if (!(w >= IDLE)) { delete memo[k]; return 0; }
    const want = Math.min(cap, tier(w)), m = memo[k], now = Date.now();
    if (!m || Math.abs(want - m.n) > 1) { memo[k] = { n: want }; return want; }
    if (m.n >= Math.min(cap, tier(w * 0.8)) && m.n <= Math.min(cap, tier(w * 1.2))) { m.wait = 0; return m.n; }
    if (m.wait === want && now - m.since >= 4000) { m.n = want; m.wait = 0; }
    else if (m.wait !== want) { m.wait = want; m.since = now; }
    return m.n;
  }
  // Six places par trajet, en douzièmes du cycle : chaque palier garde un espacement régulier, et passer de 2 à 4
  // points n'en ajoute que deux (les autres ne bougent pas)
  const SLOTS = [0, 3, 4, 6, 8, 9];
  const VIS = { 1: [0], 2: [0, 6], 3: [0, 4, 8], 4: [0, 3, 6, 9] };
  // Trait et points suivent la puissance (même logique que la largeur des liaisons de flow.js)
  const sat = (w) => BZ.clamp(w / 2500, 0, 1);

  // Jour ou nuit : l'heure qu'il est (lever et coucher du soleil), pas la production. Une matinée grise ou un
  // onduleur en panne gardent un ciel de jour. Entité sun.sun de Home Assistant si elle existe, sinon calcul
  // approché pour la position de la maison (zone.home, sinon le centre de la France).
  function daylight(now = new Date()) {
    const s = BZ.st("sun.sun");
    if (s === "above_horizon" || s === "below_horizon") return s === "above_horizon";
    const z = BZ.ent("zone.home").attributes || {}, lat = +(C.latitude ?? z.latitude ?? 46.6), lon = +(C.longitude ?? z.longitude ?? 2.4), r = Math.PI / 180;
    const N = Math.round((Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()) - Date.UTC(now.getUTCFullYear(), 0, 0)) / 864e5);
    const decl = -23.44 * Math.cos((360 / 365) * (N + 10) * r);
    const cosH = (Math.sin(-0.833 * r) - Math.sin(lat * r) * Math.sin(decl * r)) / (Math.cos(lat * r) * Math.cos(decl * r));
    if (cosH <= -1 || cosH >= 1) return cosH <= -1;   // jour ou nuit polaires
    const B = (360 / 365) * (N - 81) * r, eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B);
    const noon = 720 - 4 * lon - eot, half = (4 * Math.acos(cosH)) / r;   // minutes UTC
    const d = ((now.getUTCHours() * 60 + now.getUTCMinutes() - noon + 2160) % 1440) - 720;
    return Math.abs(d) < half;
  }

  function state() {
    const L = BZ.live(), N = BZ.flowNodes(L);
    const soc = num(C.batterie_soc), carSoc = num(C.voiture_soc), heat = BZ.isOn(C.ballon_chauffe) || num(C.ballon_boost) === 1;
    const need = L.house + L.car, auto = !has(need) || !has(L.grid) ? NaN : need > 0 ? BZ.clamp(1 - Math.max(0, L.grid) / need, 0, 1) : 1;
    const sunOn = L.solar >= IDLE;
    const on = {
      sun0: L.solar, sun1: L.solar, sun2: L.solar, sun: L.solar,
      gridIn: L.grid > IDLE ? L.grid : 0, gridOut: L.grid < -IDLE ? -L.grid : 0,
      batIn: L.bat > IDLE ? L.bat : 0, batOut: L.bat < -IDLE ? -L.bat : 0,
      car: L.charging && L.car >= IDLE ? L.car : 0,
      home: L.house,
    };
    // D'où vient ce que consomment la maison et la voiture (répartition partagée : flow.js)
    const fed = { sun: 0, bat: 0, grid: 0 };
    for (const r of BZ.flowRoutes(L)) if (r.to === "house" || r.to === "car") fed[r.from] += r.w;
    // Lumière des fenêtres : suit la consommation de la maison
    const glow = has(L.house) ? BZ.clamp(0.25 + Math.max(0, L.house) / 1800, 0.25, 1) : 0.5;
    // Nuit : pas de production ET le soleil est couché. En journée sans production, le ciel reste de jour.
    const night = !sunOn && !daylight();
    return { L, N, T: BZ.today(), soc, carSoc, heat, auto, fed, glow, on, sunOn, carOn: on.car > 0, night, smoke: BZ.st(C.poele) !== "off", temp: num(C.ballon_temp) };
  }

  // Phrase en direct : d'où vient l'énergie consommée, puis l'autonomie (le détail du réseau est sur sa pastille)
  const FROM = { sun: "du soleil", bat: "de la batterie", grid: "du réseau" };
  function summary(S) {
    const { L, fed } = S, tot = fed.sun + fed.bat + fed.grid, known = has(L.solar) && has(L.grid) && has(L.bat);
    const main = ["sun", "bat", "grid"].reduce((a, k) => (fed[k] > fed[a] ? k : a), "sun");
    const rest = known && tot < IDLE;
    const who = !known ? "Mesures en attente" : rest ? "Consommation au repos" : `${fed[main] / tot > 0.95 ? "Tout vient" : "Surtout"} ${FROM[main]}`;
    const tone = !has(S.auto) ? "neutral" : S.auto > 0.95 ? "good" : S.auto > 0.5 ? "warn" : "bad";
    const grid = !has(L.grid) ? "réseau sans mesure" : L.grid < -IDLE ? `tu revends ${pw(-L.grid)}` : L.grid > IDLE ? `tu achètes ${pw(L.grid)}` : "réseau à l'équilibre";
    // wait : aucune mesure en direct (l'étiquette « En direct » de l'Aperçu se met alors en veille)
    return { who, tone, a: has(S.auto) && known && !rest ? `${fmt.n(S.auto * 100)} % autonome` : "", grid, wait: !known };
  }
  // Ce que dit chaque élément, en toutes lettres (description du dessin, détail des pastilles)
  function words(S) {
    const { L } = S, b = L.bat, g = L.grid;
    const soc = (v) => (has(v) ? `à ${fmt.n(v)} %` : "(charge inconnue)");
    // Part du soleil dans la recharge : seulement si les deux mesures (soleil, réseau) de la borne existent
    const evS = Math.max(0, num(C.ve_solaire_w)), evG = Math.max(0, num(C.ve_reseau_w)), share = evS + evG > 0 ? `, ${fmt.n((evS / (evS + evG)) * 100)} % au soleil` : "";
    return {
      sun: !has(L.solar) ? "production inconnue" : S.night ? "pas de production, il fait nuit" : S.sunOn ? `${pw(L.solar)} produits` : "pas de production pour l'instant",
      home: has(L.house) ? `${pw(L.house)} consommés, hors voiture` : "consommation inconnue",
      bat: `${soc(S.soc)}, ${!has(b) ? "puissance inconnue" : Math.abs(b) < IDLE ? "en veille" : `${b > 0 ? "en charge" : "en décharge"} à ${pw(Math.abs(b))}`}`,
      grid: !has(g) ? "échange inconnu" : Math.abs(g) < IDLE ? "à l'équilibre" : `${pw(Math.abs(g))} ${g < 0 ? "revendus" : "achetés"}`,
      car: `${soc(S.carSoc)}, ${S.carOn ? `en charge à ${pw(L.car)}${share}` : L.plugged ? "branchée" : "débranchée"}`,
      boil: `${has(S.temp) ? `à ${fmt.n(S.temp)} °C` : "(température inconnue)"}${S.heat ? ", en chauffe" : ""}`,
    };
  }

  /* ─── Pastilles ─────────────────────────────────────────────────── */
  // at : point d'attache sur le dessin ; pos : point de la pastille où aboutit le repère (unités du viewBox) ;
  // row / side : rangée (haut, bas) et place dans la rangée (l = à gauche, c = au milieu, r = à droite).
  // Libellé visible = début du nom accessible (WCAG 2.5.3), puis le détail et l'action.
  function chips(S, W) {
    // États et teintes : ceux du schéma partagé (flow.js), pour parler comme le reste de l'application
    const { L, N, carOn } = S, g = L.grid, b = L.bat, batIdle = !(Math.abs(b) >= IDLE), gridIdle = !(Math.abs(g) >= IDLE);
    const batV = !has(b) ? "—" : batIdle ? N.bat.state : `${b > 0 ? "+" : "−"}${pw(Math.abs(b))}`;
    const gridV = !has(g) ? "—" : gridIdle ? N.grid.state : `${g < 0 ? "−" : "+"}${pw(Math.abs(g))}`;
    const carV = carOn ? pw(L.car) : L.charging ? "Branchée" : N.car.note;   // en charge sans puissance : simplement branchée
    const sunV = !has(L.solar) ? "—" : S.night ? "Nuit" : pw(L.solar);
    const boilV = has(S.temp) ? `${fmt.n(S.temp)} °C` : S.heat ? "En chauffe" : "—";
    const pc = (v) => (has(v) ? `${fmt.n(v)} %` : "");
    return [
      { k: "grid", tone: N.grid.tone, ic: N.grid.ic, l: N.grid.label, v: gridV, sub: gridIdle || !has(g) ? "" : N.grid.state.toLowerCase(), idle: gridIdle, at: at(...INS), pos: [12, 12], side: "l",
        act: "spot", spot: "en-grd", say: !has(g) || !gridIdle ? W.grid : "", go: "Afficher la carte Réseau" },
      { k: "home", tone: "accent", ic: N.home.ic, l: N.home.label, v: pw(L.house), idle: !has(L.house), at: at(ATTIC[0], ATTIC[1], ATTIC[2] + 0.64), pos: [190, 12], side: "c",
        act: "nav", to: "insights", say: has(L.house) ? "consommés hors voiture" : "consommation inconnue", go: "Voir le bilan" },
      { k: "sun", tone: N.sun.tone, ic: N.sun.ic, l: N.sun.label, v: sunV, idle: !S.sunOn, at: at(...roofPt(2.7, 4.55)), pos: [348, 12], side: "r",
        act: "spot", spot: "en-sun", say: S.sunOn ? "produits par les panneaux" : W.sun, go: "Afficher la production solaire" },
      { k: "bat", tone: N.bat.tone, ic: N.bat.ic, l: N.bat.label, x: pc(S.soc), v: batV, idle: batIdle, at: at(3.7, 11.94, 2.7), pos: [12, 250], side: "l",
        act: "spot", spot: "en-bat", say: !has(S.soc) ? "charge inconnue" : !has(b) || batIdle ? "" : b > 0 ? "en charge" : "en décharge", go: "Afficher la carte Batterie" },
      { k: "boil", tone: "heat", ic: S.heat ? "flame" : "drop", l: "Ballon", v: boilV, sub: S.heat && has(S.temp) ? "chauffe" : "", idle: !S.heat, at: at(11.35, R.y1, 0.8), pos: [184, 250], side: "c",
        act: "open-sheet", sheet: "ballon", say: has(S.temp) ? "" : "température inconnue", go: "Ouvrir le ballon" },
      { k: "car", tone: N.car.tone, ic: N.car.ic, l: N.car.label, x: pc(S.carSoc), v: carV, idle: !carOn, at: at(16.5, CAR.y0 + 0.5, 1.7), pos: [348, 250], side: "r",
        act: "nav", to: "vehicle", say: carOn ? "en charge" : !has(S.carSoc) ? "charge inconnue" : "", go: "Ouvrir la page Voiture" },
    ];
  }

  /* ─── Cadrages ──────────────────────────────────────────────────────
     Énergie : le dessin entier, pastilles en deux rangées de trois (positions pos ci-dessus).
     Aperçu (compact) : le même dessin vu d'un peu plus loin (marges sur les côtés, ciel et pied de l'îlot
     rognés), une scène bien moins haute ; les pastilles se posent dans les coins, à quelques pixels du bord.
     Le ballon n'y figure pas (pas un flux électrique de la maison ; il garde sa pastille sur Énergie). */
  const FRAMES = { full: { x: 0, y: 0, w: VW, h: VH }, compact: { x: -28, y: 26, w: 416, h: 258 } };
  // Aperçu : chaque pastille mène à sa carte de la page Énergie (atteinte puis signalée), au bilan ou à la voiture
  const OVER = { grid: ["energy", "en-grd", "Voir le réseau sur la page Énergie"], sun: ["energy", "en-sun", "Voir la production sur la page Énergie"],
    bat: ["energy", "en-bat", "Voir la batterie sur la page Énergie"] };
  // Pastilles de l'Aperçu : ce qui circule en ce moment, sans la charge (%) de la batterie et de la voiture, que la
  // carte Réserves de la même page affiche déjà (pas de doublon) ; le nom du lien de la maison la dit toujours.
  function compactChips(S, W) {
    const b = S.L.bat;
    return chips(S, W).filter((c) => c.k !== "boil").map((c) => {
      const o = OVER[c.k] ? { ...c, act: "nav", to: OVER[c.k][0], spot: OVER[c.k][1], go: OVER[c.k][2] } : { ...c };
      if (c.k === "bat") Object.assign(o, { x: "", say: !has(b) ? "puissance inconnue" : c.idle ? "" : b > 0 ? "en charge" : "en décharge" });
      if (c.k === "car") Object.assign(o, { x: "", say: S.carOn ? "en charge" : "" });
      return o;
    });
  }
  // Arrivée du repère d'une pastille (unités du viewBox), cachée sous la pastille
  function leadEnd(c, top, F, cp) {
    if (!cp) return { x: c.pos[0] + (c.side === "l" ? 16 : c.side === "r" ? -16 : 0), y: c.pos[1] + 20 };
    const k = F.w / 358;   // unités par pixel sur une scène de 358 px (téléphone de 390 px) ; ailleurs l'écart reste sous la pastille
    return { x: c.side === "l" ? F.x + 30 * k : c.side === "r" ? F.x + F.w - 30 * k : F.x + F.w / 2, y: top ? F.y + 24 * k : F.y + F.h - 24 * k };
  }

  /* ─── Rendu ─────────────────────────────────────────────────────── */
  function house({ compact: cp = false } = {}) {
    const S = state(), sum = summary(S), W = words(S), F = FRAMES[cp ? "compact" : "full"], vb = `${F.x} ${F.y} ${F.w} ${F.h}`;
    const CH = cp ? compactChips(S, W) : chips(S, W);
    // Flux : pour chaque trajet, 6 points (data-key stable) ; les inactifs restent dans le DOM, masqués
    const links = Object.entries(LINKS).map(([k, Ln]) => {
      // Capteur indisponible : trajet tracé comme au repos (jamais de NaN dans les attributs)
      const w = has(S.on[k]) ? S.on[k] : 0, live = w >= IDLE, n = count(k, Ln.lane ? w / 3 : w, Ln.cap), vis = VIS[n] || [];
      const s = sat(Ln.lane ? w / 2 : w), rh = (4.6 + 2.2 * s).toFixed(1), rc = (1.6 + 0.6 * s).toFixed(2), rw = (0.7 + 0.25 * s).toFixed(2);
      const style = `--tw:${(Ln.lane ? 1.3 + 0.5 * s : 1.2 + 2.2 * s).toFixed(2)};--to:${(Ln.lane ? 0.3 + 0.12 * s : 0.12 + 0.3 * s).toFixed(2)}`;
      return h`<g class="hh-ln ${Ln.lane ? "is-lane" : ""}" data-l="${k}" data-tone="${Ln.tone}" data-on="${live ? 1 : 0}" data-n="${n}" data-rate="${live ? ((speed(w) / V0) * (Ln.spd || 1)).toFixed(2) : 0}" style="${style}">
        <radialGradient id="hh-hg-${k}"><stop offset="0" class="hh-hg0"/><stop offset=".42" class="hh-hg1"/><stop offset="1" class="hh-hg2"/></radialGradient>
        <path class="hh-trail" d="${Ln.d}"/>
        ${SLOTS.map((sl) => h`<g class="hh-dot" data-key="${k}-${sl}" data-s="${sl}" data-v="${vis.includes(sl) ? 1 : 0}"><g class="hh-dm"><circle class="hh-dh" r="${rh}" fill="url(#hh-hg-${k})"/><circle class="hh-dc" r="${rc}"/><circle class="hh-dw" r="${rw}"/></g></g>`)}
        <path class="hh-arrow" d="M-3.2,-3.4L1.2,0L-3.2,3.4" transform="translate(${Ln.mid.x} ${Ln.mid.y}) rotate(${Ln.mid.a})"/>
      </g>`;
    });
    // Calque animé : fumée du poêle, niveau de la batterie, flux, repères des pastilles
    const chim = at(FLUE[0], FLUE[1], FLUE[2] + 1.45);
    const fx = h`<svg class="hh-fx" viewBox="${vb}" aria-hidden="true" focusable="false">
      <defs><radialGradient id="hh-puff"><stop offset="0" class="hh-st-p1"/><stop offset=".55" class="hh-st-p2"/><stop offset="1" class="hh-st-p3"/></radialGradient></defs>
      <g class="hh-smoke">${[0, 1, 2].map((i) => h`<ellipse style="--i:${i}" cx="${chim.x}" cy="${chim.y}" rx="4.6" ry="2.6"/>`)}</g>
      <g transform="${onY(11.9)}"><rect class="hh-bat-soc" x="4.12" y=".3" width=".12" height="${((1.82 * BZ.clamp(has(S.soc) ? S.soc : 0, 0, 100)) / 100).toFixed(3)}" rx=".06"/></g>
      <g class="hh-links">${links}</g>
      <g class="hh-leads">${CH.map((c, i) => {
        const end = leadEnd(c, i < 3, F, cp), r = (v) => Math.round(v * 10) / 10;
        return h`<g data-tone="${c.tone}" class="${c.idle ? "is-idle" : ""}"><path d="M${c.at.x},${c.at.y}L${r(end.x)},${r(end.y)}"/><circle cx="${c.at.x}" cy="${c.at.y}" r="2.3"/></g>`;
      })}</g>
    </svg>`;
    const label = `Ta maison en direct : ${sum.who.toLowerCase()}${sum.a ? `, ${sum.a}` : ""}. Soleil : ${W.sun} ; maison : ${W.home} ; batterie ${W.bat} ; réseau : ${W.grid} ; e-Niro ${W.car} ; ballon ${W.boil}.`;
    const flags = `data-run="${running() ? 1 : 0}" style="--glow:${S.glow.toFixed(2)}" data-sky="${S.night ? "night" : "day"}" data-sun="${S.sunOn ? 1 : 0}" data-heat="${S.heat ? 1 : 0}" data-smoke="${S.smoke ? 1 : 0}" data-car="${S.carOn ? "charging" : S.L.plugged ? "plugged" : "off"}" data-bat="${!(Math.abs(S.L.bat) >= IDLE) ? "idle" : S.L.bat > 0 ? "in" : "out"}"`;
    const chip = (c) => {
      const attrs = c.act === "nav" ? `href="${BZ.href(c.to)}" ${c.spot ? `data-spot="${c.spot}"` : ""}` : `type="button" data-act="${c.act}" ${c.spot ? `data-spot="${c.spot}"` : ""} ${c.sheet ? `data-sheet="${c.sheet}"` : ""}`;
      const tag = c.act === "nav" ? "a" : "button";
      const seen = `${c.l}${c.x ? ` ${c.x}` : ""} ${c.v}${c.sub ? ` ${c.sub}` : ""}`;
      return h`<${tag} class="hh-chip hh-c-${c.k} is-${c.side} ${c.x ? "has-x" : ""} ${c.idle ? "is-idle" : ""}" data-tone="${c.tone}" ${attrs} aria-label="${esc(`${seen}${c.say ? `, ${c.say}` : ""}. ${c.go}`)}">
        <span class="hh-cl">${icon(c.ic)}<span class="hh-cn">${c.l}</span>${c.x ? h`<span class="hh-cx">${c.x}</span>` : ""}</span><b class="hh-cv">${c.v}${c.sub ? h`<small> ${c.sub}</small>` : ""}</b></${tag}>`;
    };
    const say = h`<span class="hh-say"><b class="hh-who">${sum.who}</b>${sum.a ? h` <span class="hh-auto">· ${sum.a}</span>` : ""}</span>`;
    // Aperçu : toute la carte mène à la page Énergie. Le lien, de la taille de la carte, passe sous le dessin et les
    // pastilles (jamais de lien dans un lien) ; sa description en toutes lettres devient son nom, la phrase visible la
    // répète, on la tait. Sans aucune mesure, l'étiquette « En direct » se met en veille (point gris immobile).
    return h`<section class="hh ${cp ? "is-compact" : ""}" ${flags} aria-labelledby="hh-t">
      <h2 class="sr" id="hh-t">Ta maison en direct</h2>
      ${cp ? h`<a class="hh-go" href="${BZ.href("energy")}" aria-label="${esc(`${label} Voir le détail sur la page Énergie.`)}"></a>` : ""}
      <div class="hh-stage">
        <div class="hh-sky" aria-hidden="true"><i class="hh-sun"></i><i class="hh-moon"></i><i class="hh-stars"></i></div>
        <div class="hh-scene">
          <div class="hh-img" ${cp ? 'aria-hidden="true"' : `role="img" aria-label="${esc(label)}"`}><svg class="hh-art" data-static="${cp ? "hh-art-c" : "hh-art"}" viewBox="${vb}" aria-hidden="true" focusable="false"></svg></div>
          ${fx}
        </div>
        <div class="hh-chips" role="group" aria-label="Détail par appareil">
          <div class="hh-row is-top">${CH.slice(0, 3).map(chip)}</div>
          <div class="hh-row is-bot">${cp ? [chip(CH[3]), h`<span class="hh-live ${sum.wait ? "is-idle" : ""}" aria-hidden="true"><i class="hh-ping"></i>En direct</span>`, chip(CH[4])] : CH.slice(3).map(chip)}</div>
        </div>
      </div>
      ${cp ? h`<div class="hh-sum" aria-hidden="true">
        <p class="hh-now" data-tone="${sum.tone}">${say}</p>
      </div>` : h`<div class="hh-sum">
        <p class="hh-now" data-tone="${sum.tone}"><i class="hh-ping"></i>${say}</p>
        ${has(S.T.prod) ? h`<p class="hh-day">Aujourd'hui · <b>${fmt.kwhText(S.T.prod)}</b> produits${has(S.T.savings) ? h`<span class="hh-day-e"> · <b>${fmt.eur(S.T.savings)}</b> économisés</span>` : ""}</p>` : ""}
      </div>`}
    </section>`;
  }

  /* ─── Après chaque rendu ──────────────────────────────────────────────
     1. Décor : injecté une seule fois dans son SVG vide (data-static : BZ.morph ne le compare plus).
     2. Points : crée l'animation des nouveaux, ajuste la vitesse des autres (updatePlaybackRate garde
        la position). Mouvement réduit : aucune animation, des flèches fixes. */
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  const V0 = 20;   // vitesse de référence (unités du viewBox par seconde) pour playbackRate = 1
  // Maison hors de l'écran (page défilée) ou onglet caché : toutes les animations en pause, reprises telles quelles.
  // L'état passe aussi dans le gabarit (data-run) pour que BZ.morph ne l'efface pas ; il fige la fumée en CSS.
  // Une seule maison par page (Aperçu ou Énergie) : en changeant de page, l'observateur passe à la nouvelle ;
  // une maison retirée du document (page sans maison) n'est plus observée ni retenue.
  let inView = true, watched = null;
  const running = () => inView && !document.hidden;
  const io = "IntersectionObserver" in window ? new IntersectionObserver((es) => {
    for (const e of es) if (!e.target.isConnected) { io.unobserve(e.target); if (watched === e.target) watched = null; }
    const e = es.filter((x) => x.target === watched).pop();
    if (e) inView = e.isIntersecting;
    sync();
  }) : null;
  function sync() {
    const root = document.querySelector(".hh");
    if (!root) return;
    root.dataset.run = running() ? 1 : 0;
    animate(root);
  }
  document.addEventListener("visibilitychange", sync);
  function after() {
    const root = document.querySelector(".hh");
    if (!root) return;
    const svg = root.querySelector(".hh-art");
    if (svg && !svg.firstChild && root.offsetParent) svg.innerHTML = art().inner;   // tablette, bureau : jamais construit
    if (io && watched !== root) { if (watched) io.unobserve(watched); io.observe((watched = root)); }
    animate(root);
  }
  const pauseAll = (root) => root.querySelectorAll(".hh-dm").forEach((m) => { if (m._a && m._a.playState !== "paused") m._a.pause(); });
  function animate(root) {
    if (!root || reduce.matches || !Element.prototype.animate) return;
    // Maison masquée (tablette, bureau, téléphone à l'horizontale) : rien ne tourne pour rien
    if (!root.offsetParent) { pauseAll(root); return; }
    const go = running();
    root.querySelectorAll(".hh-ln").forEach((g) => {
      const Ln = LINKS[g.dataset.l], on = g.dataset.on === "1", rate = +g.dataset.rate || 1, dur = (Ln.len / V0) * 1000;
      const dots = [...g.querySelectorAll(".hh-dm")], slot = (m) => +m.parentNode.dataset.s / 12;
      dots.forEach((m) => {
        if (!m._a) {
          // Voies des panneaux décalées d'un tiers d'espacement l'une par rapport à l'autre (et vitesses
          // légèrement différentes) : les points scintillent au lieu de défiler en rangs
          const lag = (Ln.lag || 0) / Math.max(1, +g.dataset.n || 1);
          m._a = m.animate(Ln.frames, { duration: dur, iterations: Infinity, easing: "linear" });
          m._a.currentTime = ((slot(m) + lag) % 1) * dur;
          m._r = 1;
        }
        if (m._r !== rate) { m._r = rate; m._a.updatePlaybackRate ? m._a.updatePlaybackRate(rate) : (m._a.playbackRate = rate); }
      });
      // Points masqués : animation en pause (rien à calculer). À la reprise, chacun se recale sur le point de la
      // place 0 (toujours visible quand le trajet est actif), pour rester régulièrement espacés.
      const ref = dots[0]._a;
      dots.forEach((m, i) => {
        const show = go && on && m.parentNode.dataset.v === "1";
        if (!show && m._a.playState !== "paused") m._a.pause();
        else if (show && m._a.playState === "paused") {
          if (i && ref.playState !== "paused") m._a.currentTime = ref.currentTime + slot(m) * dur;   // au retour à l'écran, la place 0 repart en premier
          m._a.play();
        }
      });
    });
  }
  const schedule = () => Promise.resolve().then(after);
  reduce.addEventListener?.("change", () => { document.querySelectorAll(".hh-dm").forEach((m) => { if (m._a) { m._a.cancel(); m._a = null; } }); after(); });
  // Mêmes conditions que le CSS (house.css) : la maison n'existe à l'écran que sur un téléphone tenu droit
  matchMedia("(max-width: 767px) and (min-height: 501px), (max-width: 767px) and (orientation: portrait)").addEventListener?.("change", schedule);

  BZ.house = (...a) => { schedule(); return house(...a); };
})();
;
// ═══ v3/js/shared.js
// Breezy HEMS V3 — données dérivées partagées : suggestions (cloche), journée choisie,
// liste des appareils, index de recherche. Aucune mise en forme HTML ici.
(() => {
  const BZ = window.BZ;
  const { fmt, C, num, st, attr, isOn } = BZ;

  /* ─── Suggestions : déduites de l'état, triées par utilité ──────────── */
  BZ.alerts = () => {
    // Home Assistant : le diagnostic (entités introuvables…) passe en premier
    const L = BZ.live(), t = BZ.tariffNow(), out = BZ.haAlerts ? BZ.haAlerts() : [];
    const boost = num(C.ballon_boost) === 1;
    if (L.grid < -300 && !boost) out.push({ id: "surplus", tone: "grid", ic: "drop", title: `${fmt.powerText(-L.grid)} partent sur le réseau`, text: "Chauffer le ballon maintenant utilise ce surplus gratuit.", act: "boiler-boost", cta: "Chauffer le ballon" });
    const tremie = num(C.tremie_kg), days = tremie / num(C.conso_jour_kg);
    if (days < 2) out.push({ id: "pellets", tone: "warn", ic: "sack", title: `Trémie : ${fmt.n(tremie, 1)} kg`, text: `Environ ${fmt.n(days * 24)} h d'autonomie au rythme actuel.`, act: "open-sheet", args: { sheet: "poele" }, cta: "Ouvrir le poêle" });
    if (L.plugged && !L.charging && num(C.voiture_soc) < num(C.voiture_limite_pct)) out.push({ id: "car", tone: "ev", ic: "car", title: "e-Niro branchée, pas en charge", text: `${fmt.n(num(C.voiture_soc))} % · limite ${fmt.n(num(C.voiture_limite_pct))} %.`, act: "car-charge", cta: "Charger" });
    if (t.nextKey === "hsc" || t.key === "hsc") { const hrs = Math.max(0, Math.round((t.changeAt - Date.now()) / 36e5)); out.push({ id: "hsc", tone: "hsc", ic: "moon", title: t.key === "hsc" ? "Super creuses en cours" : `Super creuses dans ${hrs} h`, text: `${fmt.n(num(C.tarif_hsc), 4)} €/kWh de ${BZ.rangeLabel("hsc")}.` }); }
    const due = BZ.dt(C.poele_entretien); due.setMonth(due.getMonth() + C.poele_entretien_mois);
    const dj = fmt.inDays(due);
    if (dj < 45) out.push({ id: "stove-care", tone: "warn", ic: "wrench", title: `Entretien du poêle dans ${dj} j`, text: "Pense à prendre rendez-vous avant les grands froids." });
    return out;
  };

  /* ─── Journée choisie (flèches du sélecteur de date) ─────────────────
     offset 0 = aujourd'hui (capteurs), -1 = hier… Renvoie la journée, la veille
     et les 7 jours qui finissent ce jour-là (pour les mini-courbes). */
  BZ.dayView = (offset = 0) => {
    const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + offset);
    const at = (k) => { const x = new Date(d); x.setDate(x.getDate() + k); return BZ.day(x); };
    const cur = at(0), week = Array.from({ length: 7 }, (_, i) => at(i - 6));
    // Home Assistant : aujourd'hui (jusqu'à maintenant) est comparé à hier à la même heure, et seulement si hier est connu
    // (panneaux posés, compteurs existants) ; démo : la veille entière
    const HB = BZ.hist, cmp = HB && (() => { const k = HB.key(d), p = new Date(d); p.setDate(p.getDate() - 1); return HB.like({ a: k, b: k, pa: HB.key(p), pb: HB.key(p), live: offset === 0, shift: HB.shifts.days(1) }); })();
    const prev = cmp ? cmp.prevTotal : at(-1);
    // Historique Home Assistant pas encore arrivé (NaN) : autosuffisance inconnue, pas 100 %
    const aut = (x) => (x.cons ? 1 - x.imp / x.cons : Number.isFinite(x.cons) ? 0 : NaN);
    const V = { date: d, offset, isToday: offset === 0, cur, prev, week, autonomy: aut(cur), prevAutonomy: aut(prev), autWeek: week.map(aut) };
    if (HB) Object.assign(V, { loading: [cur, prev, ...week].some((x) => x.loading) || !!cmp.loading, absent: cur.absent || null, sameHour: offset === 0 && !cmp.none });
    return V;
  };

  /* ─── Appareils qui comptent maintenant (tableau de l'Aperçu) ─────────
     type : énergie / chauffage / maison ; statut : pastille teintée ; go : page ou panneau */
  BZ.deviceRows = () => {
    const L = BZ.live(), rows = [];
    const fin = new Date(Date.now() + num(C.voiture_minutes_restantes) * 6e4);
    rows.push({ k: "car", cat: "energy", ic: "car", tone: "ev", name: "Kia e-Niro", sub: L.charging ? `Recharge ${fmt.n(L.evSolarShare * 100)} % solaire · fin ${fmt.time(fin)}` : L.plugged ? "Branchée" : "Débranchée",
      type: ["Véhicule", "ev"], value: L.charging ? fmt.powerText(L.car) : `${fmt.n(num(C.voiture_soc))} %`, status: L.charging ? ["En charge", "ev", true] : L.plugged ? ["Branchée", "neutral"] : ["Débranchée", "neutral"], to: "vehicle" });
    rows.push({ k: "bat", cat: "energy", ic: "battery", tone: "battery", name: "Batterie SolarFlow", sub: `${fmt.n(num(C.batterie_soc))} % · ${fmt.kwhText(num(C.batterie_dispo_kwh))} disponibles`,
      type: ["Stockage", "battery"], value: fmt.powerText(Math.abs(L.bat)), status: Math.abs(L.bat) < 15 ? ["En veille", "neutral"] : L.bat > 0 ? ["Charge", "battery", true] : ["Décharge", "warn", true], to: "energy" });
    rows.push({ k: "sun", cat: "energy", ic: "sun", tone: "solar", name: "Panneaux solaires", sub: `3 onduleurs · ${fmt.kwhText(BZ.today().prod)} aujourd'hui`,
      type: ["Production", "solar"], value: fmt.powerText(L.solar), status: L.solar > 30 ? ["Produit", "good", true] : ["Nuit", "neutral"], to: "energy" });
    const stoveOn = st(C.poele) !== "off";
    rows.push({ k: "stove", cat: "heat", ic: "flame", tone: "heat", name: "Poêle à granulés", sub: stoveOn ? `${st(C.poele_statut)} · P${fmt.n(num(C.poele_puissance))} · trémie ${fmt.n(num(C.tremie_kg))} kg` : "Éteint",
      type: ["Chauffage", "heat"], value: `${fmt.n(attr(C.poele, "current_temperature"), 1)} °C`, status: stoveOn ? ["Allumé", "heat", true] : ["Éteint", "neutral"], sheet: "poele" });
    const boil = isOn(C.ballon_chauffe) || num(C.ballon_boost) === 1;
    rows.push({ k: "boiler", cat: "heat", ic: "drop", tone: "battery", name: "Ballon d'eau chaude", sub: `Consigne ${fmt.n(attr(C.ballon, "temperature"))} °C${num(C.ballon_boost) === 1 ? " · chauffe forcée" : ""}`,
      type: ["Chauffage", "heat"], value: `${fmt.n(num(C.ballon_temp))} °C`, status: boil ? ["Chauffe", "warn", true] : ["Au repos", "neutral"], sheet: "ballon" });
    const lights = C.lumieres.filter(isOn);
    rows.push({ k: "lights", cat: "home", ic: "bulb", tone: "light", name: "Lumières", sub: lights.length ? lights.map((id) => C.lumieres_noms[C.lumieres.indexOf(id)]).join(", ") : "Toutes éteintes",
      type: ["Maison", "light"], value: `${lights.length} / ${C.lumieres.length}`, status: lights.length ? ["Allumées", "light"] : ["Éteintes", "neutral"], to: "home" });
    if (isOn(C.prise_chambre)) rows.push({ k: "plug", cat: "home", ic: "plug", tone: "good", name: "Prise chambre", sub: `${fmt.kwhText(num(C.prise_chambre_kwh))} au total`,
      type: ["Maison", "good"], value: fmt.powerText(num(C.prise_chambre_w)), status: ["Allumée", "good"], to: "home" });
    const rs = st(C.robot);
    rows.push({ k: "robot", cat: "home", ic: "robot", tone: "battery", name: "Aspirateur", sub: `${fmt.n(num(C.robot_batterie))} % de batterie`,
      type: ["Maison", "battery"], value: { docked: "Base", cleaning: "Nettoie", returning: "Retour", idle: "Pause" }[rs] || rs, status: rs === "cleaning" ? ["Nettoie", "battery", true] : ["Sur sa base", "neutral"], sheet: "robot" });
    return rows;
  };

  /* ─── Index de recherche : pages + accessoires ────────────────────── */
  BZ.searchIndex = () => {
    const out = [
      { label: "Aperçu", sub: "Page", ic: "overview", tone: "accent", to: "overview" },
      { label: "Énergie", sub: "Page · réseau, batterie, solaire", ic: "energy", tone: "accent", to: "energy" },
      { label: "Bilan", sub: "Page · historique et rentabilité", ic: "insights", tone: "accent", to: "insights" },
      { label: "Voiture", sub: "Page · Kia e-Niro", ic: "car", tone: "accent", to: "vehicle" },
      { label: "Maison", sub: "Page · lumières, volets, chauffage", ic: "home", tone: "accent", to: "home" },
      { label: "Poêle à granulés", sub: "Chauffage", ic: "flame", tone: "heat", sheet: "poele" },
      { label: "Ballon d'eau chaude", sub: "Chauffage", ic: "drop", tone: "battery", sheet: "ballon" },
      { label: C.robot_nom || "Aspirateur", sub: "Aspirateur robot", ic: "robot", tone: "battery", sheet: "robot" },
      { label: "Multiprise", sub: "Appareil", ic: "plug", tone: "good", sheet: "strip" },
      { label: "HomePod salon", sub: "Musique", ic: "speaker", tone: "ev", sheet: "media" },
      ...C.volets_noms.map((n, i) => ({ label: `Volet ${n}`, sub: "Volet", ic: "blinds", tone: "battery", sheet: `cover:${i}` })),
      ...C.radiateurs_noms.map((n, i) => ({ label: `Radiateur ${n}`, sub: st(C.radiateurs[i]) !== "off" ? "Allumé · Entrée pour éteindre" : "Éteint · Entrée pour allumer", ic: "thermo", tone: "heat", act: "rad-power", args: { i } })),
      ...C.lumieres_noms.map((n, i) => ({ label: `Lumière ${n}`, sub: isOn(C.lumieres[i]) ? "Allumée · Entrée pour éteindre" : "Éteinte · Entrée pour allumer", ic: "bulb", tone: "light", act: "toggle", args: { entity: C.lumieres[i] } })),
    ];
    return out;
  };
  const norm = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  BZ.search = (q) => { const n = norm(q.trim()); if (!n) return []; return BZ.searchIndex().filter((x) => norm(`${x.label} ${x.sub}`).includes(n)).slice(0, 8); };
})();
;
// ═══ v3/js/sheets.js
// Breezy HEMS V3 — accessoires et panneaux de détail, partagés par toutes les pages
// (Maison, recherche, favoris, tableau des appareils de l'Aperçu).
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, btn, toggle, segmented, meter, C, num, st, attr, isOn, esc } = BZ;

  // Décrit un accessoire : famille, icône, état lisible, action rapide (icône) et panneau (texte).
  // toggle = l'icône bascule un état (aria-pressed) ; sinon l'icône ouvre le panneau.
  const ROBOT_STATE = { docked: "Sur sa base", cleaning: "Nettoie", returning: "Retour à la base", paused: "En pause", idle: "À l'arrêt", error: "Bloqué" };
  BZ.ROBOT_STATE = ROBOT_STATE;
  // Volet sans position (ouvert / fermé seulement) : 100 ou 0 d'après son état ; en mouvement ou indisponible : null
  const COVER_STATE = { opening: "En mouvement", closing: "En mouvement", unavailable: "Indisponible", unknown: "Inconnu" };
  const coverPos = (id) => { const p = attr(id, "current_position"); return p != null ? p : st(id) === "open" ? 100 : st(id) === "closed" ? 0 : null; };
  const coverText = (id, p) => (p == null ? COVER_STATE[st(id)] || st(id) : p === 0 ? "Fermé" : p === 100 ? "Ouvert" : `Ouvert à ${p} %`);
  BZ.coverPos = coverPos;
  function acc(kind, i) {
    if (kind === "light") { const id = C.lumieres[i]; return { id, cat: "lights", ic: "bulb", tone: "light", name: C.lumieres_noms[i], on: isOn(id), state: isOn(id) ? "Allumée" : "Éteinte", quick: "toggle", toggle: true, verb: "Allumer ou éteindre", sheet: `light:${i}` }; }
    if (kind === "cover") { const id = C.volets[i], p = coverPos(id); return { id, cat: "covers", ic: "blinds", tone: "battery", name: C.volets_noms[i], on: p > 0, pos: p, state: coverText(id, p), quick: "cover-flip", toggle: true, verb: "Ouvrir ou fermer", sheet: `cover:${i}` }; }
    if (kind === "rad") { const id = C.radiateurs[i], on = st(id) !== "off", t = C.radiateurs_temp[i]; return { id, cat: "heat", ic: "thermo", tone: "heat", name: C.radiateurs_noms[i], on, state: `${fmt.n(t ? num(t) : attr(id, "current_temperature"), 1)}°${on ? ` → ${fmt.n(attr(id, "temperature"), 1)}°` : " · éteint"}`, quick: "rad-power", toggle: true, verb: "Allumer ou éteindre le radiateur", args: { i } }; }
    if (kind === "stove") { const on = st(C.poele) !== "off", armed = BZ.ui && BZ.ui.armed === "stove"; return { id: C.poele, cat: "heat", ic: "flame", tone: "heat", name: "Poêle", on, armed, state: armed ? (on ? "Touche encore pour éteindre" : "Touche encore pour allumer") : on ? `${fmt.n(attr(C.poele, "current_temperature"), 1)}° · P${fmt.n(num(C.poele_puissance))}` : "Éteint", quick: "stove-power", toggle: true, verb: on ? "Éteindre le poêle (confirmation)" : "Allumer le poêle (confirmation)", sheet: "poele" }; }
    if (kind === "boiler") { const boost = num(C.ballon_boost) === 1, heating = isOn(C.ballon_chauffe) || boost; return { id: C.ballon_boost, cat: "heat", ic: "drop", tone: "heat", name: "Ballon", on: heating, state: heating ? `${fmt.n(num(C.ballon_temp))}° · chauffe → ${fmt.n(attr(C.ballon, "temperature"))}°` : `${fmt.n(num(C.ballon_temp))}° · au repos`, quick: "boiler-boost", toggle: true, verb: "Forcer la chauffe", sheet: "ballon" }; }
    if (kind === "plug") return { id: C.prise_chambre, cat: "devices", ic: "plug", tone: "good", name: "Prise chambre", on: isOn(C.prise_chambre), state: isOn(C.prise_chambre) ? fmt.powerText(num(C.prise_chambre_w)) : "Éteinte", quick: "toggle", toggle: true, verb: "Allumer ou éteindre", sheet: "plug" };
    if (kind === "strip") { const k = C.multiprise.filter(isOn).length; return { id: C.multiprise[0], cat: "devices", ic: "plug", tone: "good", name: "Multiprise", on: k > 0, state: `${k} sur ${C.multiprise.length} allumées`, sheet: "strip" }; }
    if (kind === "robot") { const s = st(C.robot); return { id: C.robot, cat: "devices", ic: "robot", tone: "battery", name: "Aspirateur", on: s === "cleaning" || s === "returning", anim: s === "cleaning" ? "is-cleaning" : "", state: `${ROBOT_STATE[s] || s} · ${fmt.n(num(C.robot_batterie))} %`, sheet: "robot" }; }
  }
  BZ.acc = acc;

  /* ─── Panneaux de détail ─────────────────────────────────────────── */
  // Curseur vertical : glisser ou flèches du clavier ; la commande part au relâchement
  const vslider = ({ kind, i = 0, value, min, max, step, tone, label, fmtv }) => h`
    <div class="vs" data-tone="${tone}" role="slider" tabindex="0" aria-label="${esc(label)}" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${value}" aria-valuetext="${esc(fmtv(value))}"
      data-vs="${kind}" data-i="${i}" data-min="${min}" data-max="${max}" data-step="${step}" data-value="${value}" style="--v:${((value - min) / (max - min)) * 100}%">
      <span class="vs-f"></span><output>${fmtv(value)}</output></div>`;

  // Curseur horizontal (volume) : même logique que le vertical, sur l'axe X
  const hslider = ({ kind, i = 0, value, min, max, step, tone, label, fmtv }) => h`
    <div class="vs is-h" data-tone="${tone}" data-orient="h" role="slider" tabindex="0" aria-label="${esc(label)}" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${value}" aria-valuetext="${esc(fmtv(value))}"
      data-vs="${kind}" data-i="${i}" data-min="${min}" data-max="${max}" data-step="${step}" data-value="${value}" style="--v:${((value - min) / (max - min)) * 100}%">
      <span class="vs-f"></span><output>${fmtv(value)}</output></div>`;

  /* ─── Lecteur : modèle, pochette, avancement ─────────────────────── */
  const loadedAt = Date.now();
  BZ.media = () => {
    const hp = C.homepod, s = st(hp), playing = s === "playing", dur = attr(hp, "media_duration") || 0;
    // Position réelle : position au dernier relevé + temps écoulé depuis (si lecture en cours)
    const upd = attr(hp, "media_position_updated_at"), since = playing ? (Date.now() - (upd ? Date.parse(upd) : loadedAt)) / 1000 : 0;
    const pos = Math.min(dur, (attr(hp, "media_position") || 0) + Math.max(0, since));
    let art = attr(hp, "entity_picture") || "";
    if (art && art.startsWith("/")) art = (C.ha_url || "").replace(/\/$/, "") + art;   // chemin relatif de Home Assistant
    return { active: ["playing", "paused"].includes(s), playing, dur, pos, art, title: attr(hp, "media_title"), artist: attr(hp, "media_artist"), album: attr(hp, "media_album_name") };
  };
  const mmss = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
  BZ.mediaArt = (M, size = "") => h`<span class="np-art ${size}">${M.art ? h`<img src="${esc(M.art)}" alt="" onerror="this.remove()">` : ""}<span class="np-gen ${M.playing ? "is-playing" : ""}" aria-hidden="true"><i></i><i></i><i></i><i></i></span></span>`;
  BZ.mediaProgress = (M) => M.dur ? h`<div class="np-prog" data-media-pos role="progressbar" aria-label="Avancement du morceau" aria-valuemin="0" aria-valuemax="${Math.round(M.dur)}" aria-valuenow="${Math.round(M.pos)}">
      <span class="np-cur">${mmss(M.pos)}</span><i><b style="--v:${(M.pos / M.dur) * 100}%"></b></i><span class="np-left">−${mmss(M.dur - M.pos)}</span></div>` : "";
  // L'avancement bouge chaque seconde sans redessiner toute la page
  setInterval(() => {
    const els = document.querySelectorAll("[data-media-pos]"); if (!els.length) return;
    const M = BZ.media(); if (!M.playing || !M.dur) return;
    els.forEach((el) => { el.querySelector(".np-cur").textContent = mmss(M.pos); el.querySelector(".np-left").textContent = `−${mmss(M.dur - M.pos)}`; el.querySelector("b").style.setProperty("--v", `${(M.pos / M.dur) * 100}%`); el.setAttribute("aria-valuenow", Math.round(M.pos)); });
  }, 1000);


  /* ─── Aspirateur robot : plan animé du rez-de-chaussée ────────────────
     Les zones de nettoyage (select de l'aspirateur) correspondent à des pièces du plan.
     En nettoyage, le robot suit un parcours en aller-retour dans la zone et laisse la
     surface nettoyée derrière lui ; au retour il rejoint sa base ; sur la base il charge. */
  const PLAN = {
    rooms: [
      { k: "Salon", x: 20, y: 20, w: 210, h: 130 },
      { k: "Cuisine", x: 230, y: 20, w: 150, h: 100 },
      { k: "Entrée", x: 230, y: 120, w: 150, h: 30 },
      { k: "Chambre 1", x: 20, y: 150, w: 180, h: 90, zone: "Chambres" },
      { k: "Chambre 2", x: 200, y: 150, w: 180, h: 90, zone: "Chambres" },
    ],
    doors: [[230, 70, 0, 26], [300, 120, 26, 0], [90, 150, 26, 0], [262, 150, 26, 0], [230, 128, 0, 18]],
    dock: { x: 362, y: 135 },
  };
  const zoneRooms = (z) => (/rez|tout/i.test(z || "") ? PLAN.rooms.filter((r) => r.k !== "Entrée") : PLAN.rooms.filter((r) => r.k === z || r.zone === z));
  // Parcours en aller-retour (boustrophédon) dans chaque pièce de la zone
  function sweep(rooms) {
    const pts = [];
    rooms.forEach((r) => {
      const x0 = r.x + 14, x1 = r.x + r.w - 14, rows = Math.max(2, Math.floor((r.h - 24) / 15));
      for (let k = 0; k <= rows; k++) { const y = r.y + 12 + (k * (r.h - 24)) / rows; pts.push(k % 2 ? [x1, y] : [x0, y], k % 2 ? [x0, y] : [x1, y]); }
    });
    return pts;
  }
  const pathOf = (pts) => pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
  const lenOf = (pts) => pts.reduce((a, p, i) => a + (i ? Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]) : 0), 0);
  const reduced = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Robot vu de dessus, l'avant vers +x (animateMotion l'oriente le long du trajet)
  const robotBody = (anim) => h`
    <g class="rb-bot">
      ${anim ? h`<circle class="rb-ping" r="12"><animate attributeName="r" values="12;38" dur="1.8s" repeatCount="indefinite"/><animate attributeName="opacity" values=".55;0" dur="1.8s" repeatCount="indefinite"/></circle>` : ""}
      <circle class="rb-shell" r="12"/>
      <path class="rb-bumper" d="M3.4 -10.5 A12 12 0 0 1 3.4 10.5"/>
      <circle class="rb-lidar" cx="-1.8" r="4.2"/>
      <circle class="rb-lidar-dot" cx="-1.8" r="1.4"/>
      <g class="rb-brush" transform="translate(8.6 -8.6)">${anim ? h`<animateTransform attributeName="transform" type="rotate" from="0" to="360" dur=".6s" repeatCount="indefinite" additive="sum"/>` : ""}<path d="M0 0 L4 -1.2 M0 0 L-1.2 4 M0 0 L-3 -3"/></g>
    </g>`;

  function robotScene(state, zone) {
    const rooms = zoneRooms(zone), pts = sweep(rooms), d = pathOf(pts), L = lenOf(pts), anim = !reduced();
    const D = PLAN.dock, sel = new Set(rooms.map((r) => r.k));
    const dur = Math.max(18, L / 26).toFixed(1);
    const last = pts[pts.length - 1] || [D.x, D.y], back = `M${last[0]} ${last[1]} L${last[0]} ${D.y} L${D.x} ${D.y}`;
    let bot;
    if (state === "cleaning") bot = anim
      ? h`<g><animateMotion dur="${dur}s" repeatCount="indefinite" rotate="auto" path="${d}"/>${robotBody(true)}</g>`
      : h`<g transform="translate(${pts[0][0]} ${pts[0][1]})">${robotBody(false)}</g>`;
    else if (state === "returning") bot = anim
      ? h`<g><animateMotion dur="6s" fill="freeze" rotate="auto" path="${back}"/>${robotBody(true)}</g>`
      : h`<g transform="translate(${D.x} ${D.y})">${robotBody(false)}</g>`;
    else if (state === "paused") bot = h`<g transform="translate(${pts[Math.floor(pts.length / 3)][0]} ${pts[Math.floor(pts.length / 3)][1]})">${robotBody(false)}<g class="rb-pause" transform="translate(0 -20)"><rect x="-9" y="-7" width="18" height="14" rx="7"/><path d="M-2.5 -3v6M2.5 -3v6"/></g></g>`;
    else bot = h`<g transform="translate(${D.x - 18} ${D.y}) rotate(180)">${robotBody(false)}</g>`;
    return h`<svg class="rb-plan rb-${state}" viewBox="0 0 400 260" role="img" aria-label="${esc(`Plan du rez-de-chaussée, zone ${zone || "—"}, aspirateur ${BZ.ROBOT_STATE[state] || state}`)}">
      ${PLAN.rooms.map((r) => h`<rect class="rb-room ${sel.has(r.k) ? "is-sel" : ""}" x="${r.x}" y="${r.y}" width="${r.w}" height="${r.h}" rx="3"/>`)}
      ${state === "cleaning" ? h`<path class="rb-done" d="${d}" pathLength="1">${anim ? h`<animate attributeName="stroke-dashoffset" from="1" to="0" dur="${dur}s" repeatCount="indefinite"/>` : ""}</path>` : ""}
      ${PLAN.doors.map(([x, y, w, hh]) => h`<rect class="rb-door" x="${x - (hh ? 2 : 0)}" y="${y - (w ? 2 : 0)}" width="${w || 4}" height="${hh || 4}"/>`)}
      ${PLAN.rooms.map((r) => h`<text class="rb-lab ${sel.has(r.k) ? "is-sel" : ""}" x="${r.x + 10}" y="${r.y + r.h - 9}">${r.k}</text>`)}
      <g class="rb-dock" transform="translate(${D.x} ${D.y})"><rect x="-4" y="-11" width="10" height="22" rx="3"/>${state === "docked" ? h`<circle class="rb-charge" cx="1" cy="0" r="2.2">${anim ? h`<animate attributeName="opacity" values="1;.25;1" dur="2s" repeatCount="indefinite"/>` : ""}</circle>` : ""}</g>
      ${bot}
    </svg>`;
  }

  BZ.robotSheet = () => {
    const id = C.robot, s = st(id), batt = num(C.robot_batterie), zone = st(C.robot_scene), zones = attr(C.robot_scene, "options") || [];
    const fans = attr(id, "fan_speed_list") || [], fan = attr(id, "fan_speed"), area = attr(id, "cleaned_area"), time = attr(id, "cleaning_time"), lastClean = attr(id, "last_clean");
    const cleaning = s === "cleaning", busy = BZ.isPending(id) || BZ.isPending(C.robot_scene);
    const headline = { cleaning: h`Nettoie : ${esc((zone || "").toLowerCase())}`, returning: "Retourne à sa base", paused: "En pause", error: "Bloqué, à vérifier", docked: batt >= 100 ? "Prêt, sur sa base" : "En charge sur sa base" }[s] || (BZ.ROBOT_STATE[s] || s);
    const stats = cleaning || s === "paused" ? [["Surface", area != null ? `${fmt.n(area)} m²` : "—"], ["Durée", time != null ? `${fmt.n(time)} min` : "—"], ["Aspiration", fan || "—"]]
      : [["Dernier passage", lastClean ? fmt.ago(lastClean) : "—"], ["Surface", area != null ? `${fmt.n(area)} m²` : "—"], ["Durée", time != null ? `${fmt.n(time)} min` : "—"]];
    return { full: true, ic: "robot", tone: "battery", title: C.robot_nom || "Aspirateur robot", sub: `${BZ.ROBOT_STATE[s] || s} · batterie ${fmt.n(batt)} %`,
      body: h`<div class="rb">
        <div class="rb-stage">
          <div class="rb-stage-h"><strong>Rez-de-chaussée</strong><span>${cleaning ? h`<i class="pulse" data-tone="battery"></i>Nettoyage en cours · ${esc((zone || "").toLowerCase())}` : s === "returning" ? "Retour vers la base" : s === "paused" ? "Arrêté en cours de route" : `Zone prête : ${esc((zone || "").toLowerCase())}`}</span></div>
          ${robotScene(s, zone)}
          <div class="rb-legend"><span><i class="is-sel"></i>Zone choisie</span>${cleaning ? h`<span><i class="is-done"></i>Déjà nettoyé</span>` : ""}<span><i class="is-dock"></i>Base</span></div>
        </div>
        <div class="rb-side">
          <div class="rb-head">
            ${BZ.ring({ value: batt, tone: batt < 20 ? "bad" : "battery", size: 84, stroke: 7, label: `Batterie ${fmt.n(batt)} %`, inner: h`<b>${fmt.n(batt)}<small>%</small></b>` })}
            <div><p class="rb-state">${BZ.pill(BZ.ROBOT_STATE[s] || s, cleaning ? "battery" : s === "error" ? "bad" : s === "returning" ? "ev" : "neutral", cleaning || s === "returning")}</p><h3>${headline}</h3></div>
          </div>
          <dl class="rb-stats">${stats.map(([k, v]) => h`<div><dt>${k}</dt><dd>${v}</dd></div>`)}</dl>
          <div class="field"><span>Zone à nettoyer</span>
            <div class="rb-zones" role="radiogroup" aria-label="Zone à nettoyer">${zones.map((z) => h`<button type="button" role="radio" aria-checked="${String(z === zone)}" data-act="robot-zone" data-value="${esc(z)}" ${cleaning ? "disabled" : ""}>${esc(z)}</button>`)}</div></div>
          ${fans.length ? h`<div class="field"><span>Puissance d'aspiration</span>${BZ.segmented({ name: "robotFan", label: "Puissance d'aspiration", value: fan, options: fans.map((f) => [f, f]) }).replace(/data-act="set" data-k="robotFan"/g, 'data-act="robot-fan"')}</div>` : ""}
          <div class="rb-acts">
            ${cleaning ? btn({ label: "Mettre en pause", ic: "pause", act: "robot", args: { cmd: "pause" }, kind: "primary", pending: busy })
              : btn({ label: s === "paused" ? "Reprendre" : "Lancer le nettoyage", ic: "play", act: "robot", args: { cmd: "start" }, kind: "primary", pending: busy, disabled: batt < 15 })}
            ${btn({ label: "Retour à la base", ic: "dock", act: "robot", args: { cmd: "return_to_base" }, kind: "secondary", disabled: s === "docked" || s === "returning", pending: busy })}
            ${btn({ label: "Localiser", ic: "bell", act: "robot", args: { cmd: "locate" }, kind: "ghost" })}
          </div>
        </div>
      </div>` };
  };

  BZ.sheets = {
    cover: (i) => { const id = C.volets[i], p = coverPos(id); return { ic: "blinds", tone: "battery", title: C.volets_noms[i], sub: coverText(id, p),
      body: h`${vslider({ kind: "cover", i, value: p == null ? 0 : p, min: 0, max: 100, step: 5, tone: "battery", label: "Position du volet", fmtv: (v) => `${v} %` })}
        <div class="btn-row">${btn({ label: "Fermer le volet", ic: "down", act: "cover-set", args: { i, pos: 0 }, disabled: p === 0, kind: p === 100 ? "primary" : "secondary" })}${btn({ label: "Ouvrir le volet", ic: "up", act: "cover-set", args: { i, pos: 100 }, disabled: p === 100, kind: p === 100 ? "secondary" : "primary" })}</div>` }; },
    light: (i) => { const id = C.lumieres[i], on = isOn(id); return { ic: "bulb", tone: "light", title: `Lumière ${C.lumieres_noms[i]}`, sub: on ? "Allumée" : "Éteinte",
      body: h`<button type="button" class="sh-power ${on ? "is-on" : ""}" data-tone="light" data-act="toggle" data-entity="${id}" aria-pressed="${String(on)}" ${BZ.isPending(id) ? 'aria-busy="true"' : ""}>${icon("power")}<span>${on ? "Éteindre" : "Allumer"}</span></button>
        <div class="rows"><div class="row"><div><strong>Allumée</strong><span>marche / arrêt (pas de variateur)</span></div>${toggle({ on, act: "toggle", args: { entity: id }, label: `Lumière ${C.lumieres_noms[i]}`, pending: BZ.isPending(id) })}</div></div>` }; },
    plug: () => { const id = C.prise_chambre, on = isOn(id); return { ic: "plug", tone: "good", title: "Prise chambre", sub: on ? `Allumée · ${fmt.powerText(num(C.prise_chambre_w))}` : "Éteinte",
      body: h`<div class="big-v center">${BZ.val(fmt.power(on ? num(C.prise_chambre_w) : 0))}<span class="big-s">${fmt.kwhText(num(C.prise_chambre_kwh))} consommés au total</span></div>
        <div class="rows"><div class="row"><div><strong>Alimentation</strong><span>${on ? "allumée" : "éteinte"}</span></div>${toggle({ on, act: "toggle", args: { entity: id }, label: "Prise chambre", pending: BZ.isPending(id) })}</div></div>` }; },
    poele: () => { const on = st(C.poele) !== "off", tre = num(C.tremie_kg), max = attr(C.tremie_kg, "max") || 30, stock = num(C.stock_kg), conso = num(C.conso_jour_kg);
      const due = BZ.dt(C.poele_entretien); due.setMonth(due.getMonth() + C.poele_entretien_mois);
      return { ic: "flame", tone: "heat", title: "Poêle à granulés", sub: `${st(C.poele_statut)} · ${fmt.n(attr(C.poele, "current_temperature"), 1)}° · fumées ${fmt.n(num(C.poele_fumees))}°`,
        body: h`${on ? vslider({ kind: "stove", value: attr(C.poele, "temperature"), min: attr(C.poele, "min_temp") ?? 15, max: attr(C.poele, "max_temp") ?? 25, step: attr(C.poele, "target_temp_step") ?? 0.5, tone: "heat", label: "Consigne", fmtv: (v) => `${fmt.n(v, 1)}°` }) : BZ.empty({ ic: "flame", title: "Poêle éteint", text: "Allume-le pour régler la consigne." })}
          <div class="field"><span>Puissance</span>${segmented({ name: "stovePower", label: "Puissance", value: String(num(C.poele_puissance)), options: [1, 2, 3, 4, 5].map((v) => [String(v), `P${v}`]) })}</div>
          <div class="rows">
            <div class="row ${BZ.ui.armed === "stove" ? "is-armed" : ""}"><div><strong>Allumé</strong><span>${BZ.ui.armed === "stove" ? (on ? "touche encore pour éteindre" : "touche encore pour allumer") : on ? "en chauffe" : "à l'arrêt"}</span></div>${toggle({ on, act: "stove-power", label: "Poêle allumé", pending: BZ.isPending(C.poele) })}</div>
            <div class="row"><div><strong>Trémie</strong><span>${fmt.n(tre, 1)} / ${fmt.n(max)} kg · ≈ ${fmt.n((tre / conso) * 24)} h d'autonomie</span></div>${meter({ value: (tre / max) * 100, tone: tre < 5 ? "bad" : "heat", label: "Trémie" })}</div>
            <div class="row"><div><strong>Stock</strong><span>${fmt.n(stock)} kg · ≈ ${fmt.n((tre + stock) / conso)} jours au total</span></div></div>
            <div class="row"><div><strong>Entretien</strong><span>${fmt.date(due, { day: "numeric", month: "long", year: "numeric" })}</span></div><span class="muted">${Number.isFinite(+due) ? `dans ${fmt.inDays(due)} j` : "—"}</span></div>
          </div>
          <div class="btn-row">${btn({ label: BZ.ui.armed === "fill" ? "Confirmer : sac versé" : "Sac versé dans la trémie", act: "pellet-fill", kind: BZ.ui.armed === "fill" ? "danger" : "secondary", pending: BZ.isPending(C.script_remplir) })}${btn({ label: "+1 sac au stock", ic: "plus", act: "pellet-buy", kind: "primary", pending: BZ.isPending(C.script_achat) })}</div>` }; },
    ballon: () => { const boost = num(C.ballon_boost) === 1, t = num(C.ballon_temp), c = attr(C.ballon, "temperature");
      return { ic: "drop", tone: "battery", title: "Ballon d'eau chaude", sub: isOn(C.ballon_chauffe) ? "Chauffe en cours" : "Au repos",
        body: h`<div class="sh-hero"><div class="big-v center">${BZ.val([fmt.n(t), "°C"])}<span class="big-s">consigne ${fmt.n(c)} °C</span></div>${meter({ value: (t / c) * 100, tone: "battery", label: "Température du ballon" })}</div>
          <div class="rows"><div class="row"><div><strong>Forcer la chauffe</strong><span>${boost ? "J1 · boost" : "J0 · normal"}</span></div>${toggle({ on: boost, act: "boiler-boost", label: "Forcer la chauffe", pending: BZ.isPending(C.ballon_boost) })}</div>
          <div class="row"><div><strong>Dernier entretien</strong><span>${fmt.date(BZ.dt(C.ballon_entretien), { day: "numeric", month: "long", year: "numeric" })}</span></div><span class="muted">${fmt.ago(BZ.dt(C.ballon_entretien))}</span></div></div>` }; },
    strip: () => ({ ic: "plug", tone: "good", title: "Multiprise", sub: `${C.multiprise.filter(isOn).length} sur ${C.multiprise.length} allumées`,
      body: h`<div class="rows">${C.multiprise.map((id, k) => h`<div class="row"><div><strong>${C.multiprise_noms[k]}</strong><span>${isOn(id) ? "allumée" : "éteinte"}</span></div>${toggle({ on: isOn(id), act: "toggle", args: { entity: id }, label: C.multiprise_noms[k], pending: BZ.isPending(id) })}</div>`)}</div>` }),
    robot: () => BZ.robotSheet(),
    media: () => { const M = BZ.media(), vol = Math.round((attr(C.homepod, "volume_level") || 0) * 100);
      return { ic: "speaker", tone: "accent", title: M.title || "HomePod salon", sub: [M.artist, M.album].filter(Boolean).join(" · ") || "HomePod salon",
        body: h`<div class="sh-art">${BZ.mediaArt(M, "lg")}</div>
          ${BZ.mediaProgress(M)}
          <div class="np-big">${btn({ ic: "prev", act: "media", args: { cmd: "previous" }, kind: "ghost", aria: "Morceau précédent" })}${btn({ ic: M.playing ? "pause" : "play", act: "media", args: { cmd: "play_pause" }, kind: "primary", size: "lg", aria: M.playing ? "Pause" : "Lecture" })}${btn({ ic: "next", act: "media", args: { cmd: "next" }, kind: "ghost", aria: "Morceau suivant" })}</div>
          <div class="sh-vol">${icon("speaker")}${hslider({ kind: "volume", value: vol, min: 0, max: 100, step: 1, tone: "accent", label: "Volume", fmtv: (v) => `${v} %` })}</div>` }; },
  };
})();
;
// ═══ v3/ha/diag.js
// Breezy HEMS — diagnostic du panneau Home Assistant (chargé après sheets.js, dans le panneau HA seulement).
// Vérifie config.js face aux entités que Home Assistant connaît vraiment, et le dit en clair : dans la cloche
// (« Configuration à vérifier »), dans le menu du profil (Diagnostic) et dans un panneau qu'on peut copier.
(() => {
  const BZ = window.BZ, HA = BZ.ha;
  if (!HA) return;
  const { h, esc, icon, btn, C } = BZ;
  const ENTITY = /^[a-z_]+\.[a-z0-9_]+$/;

  // Entités de config.js, chacune avec sa clé (« import_jour_kwh », « lumieres[2] ») pour savoir quoi corriger
  const entries = (() => {
    const out = [], seen = new Set();
    const walk = (v, key) => {
      if (typeof v === "string") { if (ENTITY.test(v) && !seen.has(v)) { seen.add(v); out.push({ id: v, key }); } }
      else if (Array.isArray(v)) v.forEach((x, i) => walk(x, `${key}[${i}]`));
      else if (v && typeof v === "object") Object.entries(v).forEach(([k, x]) => walk(x, `${key}.${k}`));
    };
    Object.entries(C).forEach(([k, v]) => walk(v, k));
    return out;
  })();
  // Un bouton n'a pas d'état tant qu'on ne l'a jamais pressé : « unknown » n'est pas un souci pour lui
  const down = (id, s) => s === "unavailable" || (s === "unknown" && !id.startsWith("button."));

  // Unités des compteurs et des puissances : Breezy convertit les compteurs (Wh, MWh → kWh), mais une unité qui n'est pas
  // une énergie, ou qui diffère de celle de sa statistique, mérite un coup d'œil ; les puissances sont attendues en W
  const ENERGY_U = { wh: "Wh", kwh: "kWh", mwh: "MWh" };
  function units(S) {
    const out = [], meta = (BZ.hist && BZ.hist.meta) || [];
    entries.forEach(({ id, key }) => {
      const e = S[id], u = e && e.attributes ? String(e.attributes.unit_of_measurement || "").trim() : "";
      if (!e || !u) return;
      const root = key.replace(/\[\d+\]$/, "");
      if (/_kwh$/.test(root) && !u.includes("/")) {   // pas un prix (€/kWh)
        if (!ENERGY_U[u.toLowerCase()]) out.push({ level: "warn", group: "info", id, key, text: `Unité ${u} : Breezy attend une énergie (kWh, Wh ou MWh).` });
        else if (u !== "kWh") out.push({ level: "info", group: "info", id, key, text: `Compteur en ${u} : converti en kWh par Breezy.` });
        const m = meta.find((x) => x.statistic_id === id), su = m && String(m.display_unit_of_measurement || "").trim();
        if (su && ENERGY_U[u.toLowerCase()] && su !== u) out.push({ level: "warn", group: "info", id, key, text: `Unité ${u} en direct, ${su} dans ses statistiques : vérifie ce capteur (l'historique est converti en kWh, le direct aussi).` });
      } else if (/_w$/.test(root) && /^(kw|mw)$/i.test(u)) out.push({ level: "warn", group: "info", id, key, text: `Unité ${u} : Breezy attend des W pour une puissance (les valeurs seraient 1 000 fois trop petites).` });
    });
    return out;
  }

  /* ─── Points relevés ─────────────────────────────────────────────────
     level : error (à corriger), warn (à vérifier), info (pour comprendre) */
  function issues() {
    const S = HA.states, out = [];
    entries.forEach(({ id, key }) => {
      const e = S[id];
      if (!e) out.push({ level: "error", group: "missing", id, key, text: "Entité introuvable : corrige son nom dans config.js, ou ton compte ne peut pas la voir." });
      else if (down(id, e.state)) out.push({ level: "info", group: "down", id, key, text: "Indisponible en ce moment." });
    });
    units(S).forEach((x) => out.push(x));
    (BZ.hist && BZ.hist.issues ? BZ.hist.issues() : []).forEach((x) => out.push(x));
    const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (HA.tz && browserTz && HA.tz !== browserTz) out.push({ level: "info", group: "info", text: `Home Assistant est sur ${HA.tz}, ton appareil sur ${browserTz} : les journées et les heures suivent Home Assistant.` });
    if (!(C.prevision_jours_kwh || []).length) out.push({ level: "info", group: "info", text: "Prévisions des jours suivants non configurées (clé prevision_jours_kwh) : pas de barres « prévu » au-delà d'aujourd'hui." });
    if (HA.staleBuild) out.push({ level: "warn", group: "info", text: "Mise à jour incomplète : recopie tout le contenu du dossier breezy, puis recharge la page (Ctrl+Maj+R)." });
    if (HA.staleLoader) out.push({ level: "warn", group: "info", text: `Chargeur breezy-panel.js d'une autre version (gardé en cache) : dans configuration.yaml, mets module_url: /local/breezy/breezy-panel.js?v=${HA.staleLoader.want}, puis redémarre Home Assistant.` });
    if (HA.errors.some((x) => x.code === "home_assistant_error" && /unauthori[sz]ed/i.test(x.message))) out.push({ level: "warn", group: "info", text: "Ton compte Home Assistant est en lecture seule : les commandes sont refusées." });
    else if (HA.hass && HA.hass.user && !HA.isAdmin) out.push({ level: "info", group: "info", text: "Ton compte n'est pas administrateur : c'est normal, Breezy n'en a pas besoin." });
    return out;
  }
  // À compter : ce qui demande une action (pas les infos, ni un refus passager de HA qui se réessaie tout seul)
  const serious = (list) => list.filter((x) => x.level !== "info" && !x.transient);
  BZ.diagCount = () => serious(issues()).length;

  // Cloche : un seul rappel qui mène au panneau ; config.js n'est nommé que si tout s'y corrige (entités introuvables)
  BZ.haAlerts = () => {
    const list = serious(issues()), n = list.length;
    if (!n) return [];
    const cfg = list.every((x) => x.group === "missing");
    return [{ id: "ha-diag", tone: "warn", ic: "alert", title: cfg ? "Configuration à vérifier" : "Points à vérifier", text: cfg ? `${n} entité${n > 1 ? "s" : ""} à corriger dans config.js.` : `${n} point${n > 1 ? "s" : ""} à vérifier : le diagnostic dit quoi faire.`, act: "open-sheet", args: { sheet: "diag" }, cta: "Voir le détail" }];
  };

  // Où en est l'historique (une phrase) : en chargement, en échec, ou d'où il vient
  const histLine = () => {
    const HB = BZ.hist; if (!HB) return "";
    const s = HB.status(), f = Object.keys(HB.fields || {}).length;
    return s.errors ? ` Historique : ${s.errors} échec${s.errors > 1 ? "s" : ""}, nouvel essai automatique.` : s.loading ? " Historique en cours de chargement…" : f ? ` Historique : ${f} compteurs lus dans les statistiques.` : "";
  };

  /* ─── Panneau « Diagnostic Home Assistant » ───────────────────────── */
  const GROUPS = [["missing", "Entités introuvables"], ["history", "Historique"], ["check", "Cohérence"], ["down", "Indisponibles en ce moment"], ["info", "Infos"]];
  const TONE = { error: "bad", warn: "warn", info: "neutral" };
  const row = (x) => h`<div class="row ha-diag-r" data-level="${x.level}"><div><strong>${x.id ? h`<code>${esc(x.id)}</code>` : esc(x.text)}</strong>
    ${x.id ? h`<span>${x.key ? h`clé <code>${esc(x.key)}</code> · ` : ""}${esc(x.text)}</span>` : ""}</div>${BZ.pill(x.level === "error" ? "À corriger" : x.level === "warn" ? "À vérifier" : "Info", TONE[x.level])}</div>`;
  BZ.sheets.diag = () => {
    const list = issues(), n = serious(list).length;
    if (BZ.hist) BZ.hist.sample();   // échantillon brut des statistiques demandé dès l'ouverture, prêt pour « Copier »
    const groups = GROUPS.map(([g, label]) => [label, list.filter((x) => x.group === g)]).filter(([, xs]) => xs.length);
    const copy = BZ.ui.diagCopy;
    return { ic: "alert", tone: n ? "warn" : "good", full: true, title: "Diagnostic Home Assistant",
      sub: `Breezy ${esc(HA.version)}${HA.haVersion ? ` · Home Assistant ${esc(HA.haVersion)}` : ""}`,
      // Groupes enveloppés (leur nombre change pendant que l'historique arrive) : les boutons restent les mêmes nœuds au
      // rendu suivant, et gardent le focus ; la zone de copie manuelle vient après eux
      body: h`<div class="ha-diag">
        <p class="ha-diag-sum">${icon(n ? "alert" : "check")}<span>${n ? `${n} point${n > 1 ? "s" : ""} à corriger ou vérifier.` : "Tout ce que Breezy utilise est bien trouvé dans Home Assistant."} ${entries.length} entités lues dans config.js.${histLine()}</span></p>
        <div class="ha-diag-list">${groups.map(([label, xs]) => h`<section class="ha-diag-g"><h3>${label} <em>${xs.length}</em></h3><div class="rows">${xs.map(row)}</div></section>`)}</div>
        <div class="btn-row">${btn({ label: "Copier le diagnostic", ic: "tasks", act: "diag-copy", kind: "primary" })}${btn({ label: "Recharger l'historique", ic: "refresh", act: "hist-reload" })}${btn({ label: "Recharger Breezy", ic: "refresh", act: "diag-reload", kind: "ghost" })}</div>
        ${copy ? h`<label class="ha-diag-copy"><span>La copie automatique est bloquée : sélectionne ce texte et copie-le.</span><textarea readonly rows="8">${esc(copy)}</textarea></label>` : ""}
      </div>` };
  };

  // Ce qu'on transmet pour vérifier sur les vraies données : jamais de jeton, de nom ni d'adresse
  function report() {
    const list = issues(), S = HA.states;
    return {
      breezy: HA.version, ha_version: HA.haVersion, tz: HA.tz, browser_tz: Intl.DateTimeFormat().resolvedOptions().timeZone, is_admin: HA.isAdmin,
      missing: list.filter((x) => x.group === "missing").map((x) => ({ id: x.id, key: x.key })),
      unavailable: list.filter((x) => x.group === "down").map((x) => ({ id: x.id, key: x.key })),
      issues: list.filter((x) => !x.id).map((x) => `${x.level}: ${x.text}`),
      live: Object.fromEntries(entries.map(({ id, key }) => [key, S[id] ? { state: S[id].state, unit: S[id].attributes && S[id].attributes.unit_of_measurement, state_class: S[id].attributes && S[id].attributes.state_class } : null])),
      // Historique : contrat de chaque compteur (métadonnées), champs retenus, échantillon brut (tous les types), contrôles
      history: BZ.hist ? (({ tz, start, meta, fields, problems, samples, negatives, suspects, checks, chunks }) => ({ tz, start, meta, fields, problems, samples, negatives, suspects, checks, chunks, status: BZ.hist.status() }))(BZ.hist.debug()) : null,
      errors: HA.errors,
    };
  }
  BZ.extraActions = Object.assign(BZ.extraActions || {}, {
    // Presse-papiers : navigator.clipboard n'existe qu'en HTTPS ; en HTTP (homeassistant.local:8123), la copie classique
    // (zone de texte sélectionnée + execCommand, dans le même clic) marche encore ; sinon le texte s'affiche à copier à la main
    "diag-copy": () => {
      const text = JSON.stringify(report(), null, 1);
      const ok = () => { BZ.ui.diagCopy = null; BZ.toast("Diagnostic copié", "good"); BZ.render(); };
      const fallback = () => { BZ.ui.diagCopy = text; BZ.render(); };
      const legacy = () => {
        const ta = document.createElement("textarea"), back = document.activeElement;
        // 16 px : iOS ne zoome pas en lui donnant le focus ; modifiable : sinon iOS ne la sélectionne pas
        ta.value = text; ta.style.cssText = "position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px;border:0;padding:0";
        document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
        let done = false;
        try { done = document.execCommand("copy"); } catch {}
        ta.remove();
        if (back && back.focus) back.focus({ preventScroll: true });   // le bouton du panneau garde le focus
        return done;
      };
      if (legacy()) { ok(); return; }
      try { navigator.clipboard.writeText(text).then(ok, fallback); } catch { fallback(); }
    },
    "diag-reload": () => HA.reloadAll(),
  });
  window.BZ_DIAG = Object.assign(window.BZ_DIAG || {}, { issues, report });   // pour la console du navigateur (history : voir history.js)
})();
;
// ═══ v3/index.html (script en ligne)
window.BZ.pages = {};
;
// ═══ v3/js/pages/overview.js
// Aperçu (V3) : la mise en page de la maquette, appliquée à la maison.
//  En-tête : salutation · titre · phrase d'état | sélecteur de jour + action principale
//  Téléphone tenu droit : la maison en direct (version compacte) entre la salutation et le sélecteur de jour ;
//  elle dit ce que disait la phrase d'état (masquée), et reste « en direct » quelle que soit la journée choisie
//  Ligne 1 : 4 indicateurs avec mini-courbe (journée choisie vs veille)
//  Gauche  : tableau des appareils (filtres en pastilles) puis Équipements + Raccourcis
//  Droite  : Programme du jour (tarifs et événements), Répartition (anneau), Rentabilité
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, val, card, pill, kpi, pills, donut, delta, btn, meter, C, num, st, attr, isOn } = BZ;

  function header(V) {
    const L = BZ.live(), now = new Date();
    const hello = now.getHours() < 5 ? "Bonne nuit," : now.getHours() < 12 ? "Bonjour," : now.getHours() < 18 ? "Bon après-midi," : "Bonsoir,";
    const status = V.isToday
      ? [L.grid < -15 ? `Tu revends ${fmt.powerText(-L.grid)}` : L.grid > 15 ? `Tu achètes ${fmt.powerText(L.grid)}` : "Aucun échange avec le réseau",
         L.charging ? `l'e-Niro charge à ${fmt.n(L.evSolarShare * 100)} % au soleil` : null].filter(Boolean).join(" et ") + "."
      : V.loading ? "Chargement de l'historique…"   // Home Assistant : la journée arrive des statistiques
      : `Voici le bilan du ${fmt.date(V.date, { weekday: "long", day: "numeric", month: "long" })}.`;
    const dateLabel = V.isToday ? `Aujourd'hui, ${fmt.date(V.date, { day: "numeric", month: "short" })}` : fmt.cap(fmt.date(V.date, { weekday: "short", day: "numeric", month: "short", year: "numeric" }));
    return h`<header class="ph">
      <div><p class="ph-hi">${hello}</p><h1>${BZ.esc(BZ.user)}<span class="wave" aria-hidden="true">👋</span></h1><p class="ph-sub">${status}</p></div>
      ${BZ.house({ compact: true })}
      <div class="ph-a">
        <div class="datep" role="group" aria-label="Journée affichée">${icon("calendar")}<span aria-live="polite">${dateLabel}</span>
          <button type="button" data-act="day" data-d="-1" aria-label="Jour précédent" ${V.offset <= -29 || (BZ.hist && BZ.hist.has("energie") === false) ? "disabled" : ""}>${icon("left")}</button>
          <button type="button" data-act="day" data-d="1" aria-label="Jour suivant" ${V.isToday ? "disabled" : ""}>${icon("chevron")}</button></div>
        ${btn({ label: L.charging ? "Arrêter la charge" : "Charger l'e-Niro", ic: L.charging ? "pause" : "bolt", act: "car-charge", kind: "primary", disabled: !L.plugged, pending: BZ.isPending(C.voiture_en_charge) })}
      </div></header>`;
  }

  function kpis(V) {
    // Home Assistant : aujourd'hui jusqu'à maintenant contre hier à la même heure (le dire)
    const c = V.cur, p = V.prev, vs = V.isToday ? (V.sameHour ? `vs hier à ${fmt.time(new Date())}` : "vs hier") : "vs veille", wk = (f) => V.week.map(f);
    return h`<div class="kpis">
      ${kpi({ label: "Production solaire", ic: "sun", tone: "solar", value: val(fmt.kwh(c.prod)), delta: delta(c.prod, p.prod), vs, spark: BZ.spark(wk((d) => d.prod), "solar"), to: "energy" })}
      ${kpi({ label: "Consommation", ic: "home", tone: "battery", value: val(fmt.kwh(c.cons)), delta: delta(c.cons, p.cons, { invert: true }), vs, spark: BZ.spark(wk((d) => d.cons), "battery"), to: "insights" })}
      ${kpi({ label: "Autosuffisance", ic: "leaf", tone: "good", value: val([fmt.n(V.autonomy * 100), "%"]), delta: delta(V.autonomy, V.prevAutonomy, { unit: "pts" }), vs, spark: BZ.spark(V.autWeek, "good"), to: "insights" })}
      ${kpi({ label: "Économies", ic: "euro", tone: "accent", value: val([fmt.n(c.savings, 2), "€"]), delta: delta(c.savings, p.savings), vs, spark: BZ.spark(wk((d) => d.savings), "accent"), to: "insights" })}
    </div>`;
  }

  function devicesCard() {
    const f = BZ.ui.devFilter, all = BZ.deviceRows();
    const rows = all.filter((r) => f === "all" || r.cat === f);
    const go = (r) => (r.sheet ? `data-act="open-sheet" data-sheet="${r.sheet}"` : `data-act="nav" data-to="${r.to}"`);
    return card({ cls: "o-dev", title: "Mes appareils", ic: "plug", tone: "accent", link: { label: "Voir la maison", to: "home" },
      aside: pills({ name: "devFilter", label: "Filtrer les appareils", value: f, options: [["all", "Tous"], ["energy", "Énergie"], ["heat", "Chauffage"], ["home", "Maison"]] }),
      body: h`<div class="dt-wrap"><table class="dt">
        <thead><tr><th scope="col">Appareil</th><th scope="col">Type</th><th scope="col">Mesure</th><th scope="col">Statut</th><th scope="col"><span class="sr">Ouvrir</span></th></tr></thead>
        <tbody>${rows.map((r) => h`<tr data-key="${r.k}">
          <td><div class="dt-main"><span class="dt-ic" data-tone="${r.tone}">${icon(r.ic)}</span><div><strong>${r.name}</strong><small>${r.sub}</small></div></div></td>
          <td>${pill(r.type[0], r.type[1])}</td>
          <td class="dt-v">${r.value}</td>
          <td>${pill(r.status[0], r.status[1], r.status[2])}</td>
          <td><button type="button" class="icon-btn" ${go(r)} aria-label="Ouvrir ${BZ.esc(r.name)}">${icon("more")}</button></td>
        </tr>`)}</tbody></table></div>` });
  }

  // Programme du jour : changements de tarif + événements, le prochain mis en avant
  function scheduleCard() {
    const now = new Date(), H = now.getHours() + now.getMinutes() / 60, L = BZ.live(), hrs = BZ.hours();
    // Pic : jamais une case partielle ou inconnue (Home Assistant : l'heure en cours, ou un reste du jour sans heures écrites)
    const peak = hrs.filter((b) => !b.partial && !b.unknown && Number.isFinite(b.prod)).reduce((a, b) => (b.prod > a.prod ? b : a), { h: 0, prod: -Infinity });
    const T = BZ.TARIFS, ev = [];
    let prev = BZ.tariffAt(23);
    for (let x = 0; x < 24; x++) { const k = BZ.tariffAt(x); if (k !== prev) ev.push({ t: x, tone: k, title: T[k].label, sub: `${fmt.n(T[k].price(), 4)} €/kWh · ${BZ.rangeLabel(k)}`, ic: "clock" }); prev = k; }
    // Heure de branchement illisible (aide absente dans Home Assistant) : pas d'événement plutôt qu'une heure fausse
    const plugAt = BZ.dt(C.session_debut);
    if (L.plugged && Number.isFinite(+plugAt)) { const d = plugAt; ev.push({ t: d.getHours() + d.getMinutes() / 60, tone: "ev", title: "e-Niro branchée", sub: `${fmt.n(num(C.voiture_soc) - num(C.session_soc))} % au branchement`, ic: "car" }); }
    if (peak.prod > 0.05) ev.push({ t: peak.h + 0.5, tone: "solar", title: "Pic de production", sub: `${fmt.kwhText(peak.prod)} sur l'heure`, ic: "sun" });
    if (L.charging) { const fin = new Date(Date.now() + num(C.voiture_minutes_restantes) * 6e4); ev.push({ t: fin.getHours() + fin.getMinutes() / 60, tone: "ev", title: "Fin de recharge prévue", sub: `limite ${fmt.n(num(C.voiture_limite_pct))} %`, ic: "bolt" }); }
    ev.sort((a, b) => a.t - b.t);
    const next = ev.findIndex((e) => e.t > H);
    // On montre la fenêtre utile : un événement passé, puis les suivants
    const start = Math.max(0, (next < 0 ? ev.length : next) - 1), list = ev.slice(start, start + 5);
    const hm = (t) => `${String(Math.floor(t) % 24).padStart(2, "0")}:${String(Math.round((t % 1) * 60)).padStart(2, "0")}`;
    return card({ cls: "o-sch", title: "Programme du jour", ic: "calendar", tone: "accent", link: { label: "Tarifs", to: "energy" }, body: h`
      <ol class="sched">${list.map((e) => h`<li data-tone="${e.tone}" class="${e.t <= H ? "is-past" : ""} ${ev.indexOf(e) === next ? "is-now" : ""}">
        <time>${hm(e.t)}</time><i></i><div><strong>${e.title}</strong><small>${e.sub}</small></div>${icon(e.ic)}</li>`)}</ol>` });
  }

  function mixCard(V) {
    const c = V.cur, parts = [
      { label: "Soleil direct", v: c.self, tone: "solar" }, { label: "Batterie", v: c.dch, tone: "battery" }, { label: "Réseau", v: c.imp, tone: "neutral" },
    ];
    return card({ cls: "o-mix", title: "D'où vient l'énergie", ic: "leaf", tone: "accent", link: { label: "Détails", to: "insights" }, body: h`
      <div class="mixr">${donut({ parts, size: 132, stroke: 16, center: `${fmt.n(V.autonomy * 100)} %`, sub: "autonome", label: `Autosuffisance ${Number.isFinite(V.autonomy) ? Math.round(V.autonomy * 100) : "—"} %` })}
        <ul class="keys">${parts.map((p) => h`<li data-tone="${p.tone}"><i></i><span>${p.label}</span><b>${fmt.kwhText(p.v)}</b></li>`)}
          <li class="keys-t"><span>Consommé</span><b>${fmt.kwhText(c.cons)}</b></li></ul></div>` });
  }

  function equipCard() {
    const L = BZ.live(), tre = num(C.tremie_kg), max = attr(C.tremie_kg, "max") || 30, ball = num(C.ballon_temp), cons = attr(C.ballon, "temperature") || 55;
    const items = [
      { ic: "car", tone: "ev", name: "Kia e-Niro", sub: `${fmt.n(num(C.voiture_autonomie_km))} km d'autonomie`, status: L.charging ? ["En charge", "ev"] : ["Prête", "good"], v: num(C.voiture_soc), to: "vehicle" },
      { ic: "battery", tone: "battery", name: "Batterie SolarFlow", sub: `${fmt.kwhText(num(C.batterie_dispo_kwh))} disponibles`, status: L.bat > 15 ? ["Charge", "battery"] : L.bat < -15 ? ["Décharge", "warn"] : ["Veille", "neutral"], v: num(C.batterie_soc), to: "energy" },
      { ic: "sack", tone: tre < 5 ? "bad" : "heat", name: "Trémie à granulés", sub: `${fmt.n(tre, 1)} kg sur ${fmt.n(max)} kg`, status: tre < 5 ? ["À remplir", "bad"] : ["OK", "good"], v: (tre / max) * 100, sheet: "poele" },
    ];
    return card({ cls: "o-eq", title: "Réserves", ic: "gauge", tone: "accent", body: h`
      <ul class="plist">${items.map((x) => h`<li>${x.to ? h`<a class="plist-r" href="${BZ.href(x.to)}">` : h`<button type="button" class="plist-r" data-act="open-sheet" data-sheet="${x.sheet}">`}
        <span class="dt-ic" data-tone="${x.tone}">${icon(x.ic)}</span><span><strong>${x.name}</strong><small>${x.sub}</small></span>
        ${pill(x.status[0], x.status[1])}
        <span class="plist-p"><span>${fmt.n(x.v)} %</span>${meter({ value: x.v, tone: x.tone, size: "xs" })}</span>${x.to ? h`</a>` : h`</button>`}</li>`)}</ul>` });
  }

  function linksCard() {
    const lights = C.lumieres.filter(isOn).length, open = C.volets.filter((id) => attr(id, "current_position") > 0).length, boost = num(C.ballon_boost) === 1;
    const q = [
      { label: lights ? `Éteindre ${lights} lumière${lights > 1 ? "s" : ""}` : "Lumières éteintes", ic: "bulb", tone: "light", act: "lights-off", disabled: !lights, pending: C.lumieres.some(BZ.isPending) },
      { label: open ? "Fermer les volets" : "Ouvrir les volets", ic: "blinds", tone: "battery", act: "covers-all", args: { pos: open ? 0 : 100 }, pending: C.volets.some(BZ.isPending) },
      { label: boost ? "Arrêter la chauffe" : "Chauffer le ballon", ic: "drop", tone: "heat", act: "boiler-boost", pending: BZ.isPending(C.ballon_boost) },
      { label: st(C.robot) === "cleaning" ? "Ramener l'aspirateur" : "Lancer l'aspirateur", ic: "robot", tone: "good", act: "robot", args: { cmd: st(C.robot) === "cleaning" ? "return_to_base" : "start" }, pending: BZ.isPending(C.robot) },
    ];
    return card({ cls: "o-ql", title: "Raccourcis", ic: "sparkle", tone: "accent", body: h`
      <div class="qlinks">${q.map((x) => h`<button type="button" class="qlink" data-act="${x.act}" ${BZ.dataArgs(x.args || {})} ${x.disabled ? "disabled" : ""} ${x.pending ? 'aria-busy="true"' : ""}>
        <span class="dt-ic" data-tone="${x.tone}">${icon(x.ic)}</span><span>${x.label}</span></button>`)}</div>` });
  }

  function roiCard() {
    const R = (BZ.roiFull || BZ.roi)();
    return h`<section class="card o-roi">
      <div class="o-roi-t">
        <h3>Ton installation est rentabilisée à ${fmt.n(R.progress * 100)} %</h3>
        <p>${fmt.eur(R.total, 0)} économisés sur ${fmt.eur(R.inv, 0)}. Remboursée vers ${fmt.date(R.payback, { month: "long", year: "numeric" })} au rythme actuel.</p>
        <a class="btn btn-primary btn-sm" href="${BZ.href("insights")}"><span>Voir le bilan</span>${icon("arrow")}</a>
      </div>
      <svg class="o-roi-art" viewBox="0 0 160 120" aria-hidden="true">
        <circle cx="122" cy="30" r="16" class="art-sun"/>
        <g class="art-rays"><path d="M122 6v5M122 49v5M98 30h5M141 30h5M105 13l3.5 3.5M135.5 43.5 139 47M105 47l3.5-3.5M135.5 16.5 139 13"/></g>
        <path d="M22 96 44 52h76l-22 44z" class="art-panel"/>
        <path d="M33 74h76M52 52 41 96M71 52 63 96M90 52 82 96M109 52 101 96" class="art-grid"/>
        <path d="M60 96v14M84 96v14M48 110h48" class="art-leg"/>
        <circle cx="128" cy="86" r="17" class="art-badge"/>
        <path d="m120.5 86 5 5 9.5-10" class="art-check"/>
        <rect x="128" y="74" width="0" height="0"/>
      </svg>
      <div class="o-roi-m">${meter({ value: R.progress * 100, tone: "accent", label: "Part remboursée" })}</div>
    </section>`;
  }

  BZ.pages.overview = () => {
    const V = BZ.dayView(BZ.ui.dayOffset);
    return h`${header(V)}${kpis(V)}
      <div class="layout o-grid">
        <div class="col o-l">${devicesCard()}<div class="o-pair">${equipCard()}${linksCard()}</div></div>
        <div class="col o-r">${scheduleCard()}${mixCard(V)}${roiCard()}</div>
      </div>`;
  };
})();
;
// ═══ v3/js/pages/energy.js
// Énergie (V3) : le temps réel en détail, sans répéter l'Aperçu ni le Bilan.
//  En-tête : phrase d'état en direct | ballon + surplus disponible, « Chauffer le ballon »
//  Ligne 1 : production, batterie, réseau (compteur L3), prix du kWh — courbes d'aujourd'hui
//  Gauche  : flux en direct (soleil → maison → batterie, réseau, e-Niro), puis Production solaire (onduleurs) + Réseau
//  Droite  : Batterie SolarFlow (packs, rendement, réglages), Tarifs (cadran des 24 h à venir + prix)
(() => {
  const BZ = window.BZ;
  const { h, esc, fmt, icon, val, card, pill, kpi, btn, meter, ring, stepper, C, num } = BZ;

  const PACK_KWH = 2.88;   // capacité nominale d'un pack de la batterie
  // Puissance maximale de chaque onduleur, lue dans son nom (« Izy 2 000 W »)
  const caps = () => C.onduleurs_noms.map((n, i) => parseInt(String(n).replace(/\D/g, ""), 10) || [2000, 2000, 1000][i] || 1000);
  const nowH = () => { const d = new Date(); return d.getHours() + d.getMinutes() / 60; };
  const sum = (a) => a.reduce((s, v) => s + v, 0);
  // Milliers toujours séparés (« 1 821 »), même à 4 chiffres
  const NG = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0, useGrouping: "always" });
  const big = (v) => (Number.isFinite(v) ? NG.format(v).replace(/\u202f/g, "\u00a0") : "—");   // espace insécable visible
  // Capacité utile : celle qui donne les kWh affichés dans l'anneau (sinon la capacité nominale)
  const capKwh = () => { const soc = num(C.batterie_soc), d = num(C.batterie_dispo_kwh); return soc > 5 && d > 0 ? d / (soc / 100) : C.packs_soc.length * PACK_KWH; };
  // État coloré sans flèche de tendance (état, pas évolution)
  const tag = (text, tone, ic) => h`<span class="delta en-d" data-tone="${tone}">${ic ? icon(ic) : ""}${text}</span>`;
  // Libellé long sur grand écran, court quand la place manque
  const lbl = (long, short) => h`<span class="en-lo">${long}</span><span class="en-sh">${short}</span>`;
  const IMP = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M17 7 7 17M15 17H7V9"/></svg>';
  const EXP = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';

  /* ─── Mini-courbes ────────────────────────────────────────────────── */
  const SW = 120, SH = 36;
  // Courbe lissée (Catmull-Rom → Bézier), comme les autres mini-courbes
  function smooth(p) {
    if (p.length < 2) return p.length ? `M${p[0][0]},${p[0][1]}` : "";
    let d = `M${p[0][0].toFixed(1)},${p[0][1].toFixed(1)}`;
    for (let i = 0; i < p.length - 1; i++) {
      const a = p[i - 1] || p[i], b = p[i], c = p[i + 1], e = p[i + 2] || c;
      d += ` C${(b[0] + (c[0] - a[0]) / 6).toFixed(1)},${(b[1] + (c[1] - a[1]) / 6).toFixed(1)} ${(c[0] - (e[0] - b[0]) / 6).toFixed(1)},${(c[1] - (e[1] - b[1]) / 6).toFixed(1)} ${c[0].toFixed(1)},${c[1].toFixed(1)}`;
    }
    return d;
  }
  // Aujourd'hui, de 0 h à maintenant : pts = [[x 0…1, valeur]], point en direct au bout (pastille HTML, jamais déformée)
  // zero : échelle symétrique autour de 0 (au-dessus = revente, en dessous = achat)
  function daySpark(pts, tone, { lo, hi, zero = false, live } = {}) {
    // Capteur indisponible : on ne trace que les valeurs connues (jamais « NaN » dans un tracé SVG)
    pts = pts.filter((p) => Number.isFinite(p[1]));
    if (live && !Number.isFinite(live[1])) live = null;
    const vs = pts.map((p) => p[1]).concat(live ? [live[1]] : []);
    let a = lo != null ? lo : Math.min(0, ...vs), b = hi != null ? hi : Math.max(...vs, 0.001);
    if (zero) { const m = Math.max(Math.abs(a), Math.abs(b), 0.001); a = -m; b = m; }
    const y = (v) => SH - 3 - ((v - a) / (b - a || 1)) * (SH - 6);
    const P = pts.map(([x, v]) => [x * SW, y(v)]), d = smooth(P), y0 = y(zero ? 0 : a);
    const area = P.length > 1 ? `${d} L${P[P.length - 1][0].toFixed(1)},${y0.toFixed(1)} L${P[0][0].toFixed(1)},${y0.toFixed(1)} Z` : "";
    const dot = live ? h`<i class="en-sp-dot" data-tone="${live[2] || tone}" style="left:${(live[0] * 100).toFixed(1)}%;top:${((y(live[1]) / SH) * 100).toFixed(1)}%"></i>` : "";
    const svg = zero
      ? h`<svg class="spark" viewBox="0 0 ${SW} ${SH}" preserveAspectRatio="none" aria-hidden="true">
          <defs><clipPath id="en-sp-up"><rect x="0" y="-4" width="${SW}" height="${(y0 + 4).toFixed(1)}"/></clipPath><clipPath id="en-sp-dn"><rect x="0" y="${y0.toFixed(1)}" width="${SW}" height="${(SH - y0 + 4).toFixed(1)}"/></clipPath></defs>
          <line class="en-sp-0" x1="0" x2="${SW}" y1="${y0.toFixed(1)}" y2="${y0.toFixed(1)}"/>
          <g data-tone="grid" clip-path="url(#en-sp-up)"><path class="spark-a" d="${area}"/><path class="spark-l" d="${d}"/></g>
          <g data-tone="bad" clip-path="url(#en-sp-dn)"><path class="spark-a" d="${area}"/><path class="spark-l" d="${d}"/></g></svg>`
      : h`<svg class="spark" data-tone="${tone}" viewBox="0 0 ${SW} ${SH}" preserveAspectRatio="none" aria-hidden="true"><path class="spark-a" d="${area}"/><path class="spark-l" d="${d}"/></svg>`;
    return h`<span class="en-sp">${svg}${dot}</span>`;
  }

  // Mini-courbe en escalier (prix de chaque heure du jour) avec un repère « maintenant »
  function stepSpark(vals, tone, at) {
    const n = vals.length, max = Math.max(...vals), min = Math.min(...vals);
    const y = (v) => (SH - 3 - ((v - min) / (max - min || 1)) * (SH - 12)).toFixed(1), x = (i) => ((i / n) * SW).toFixed(1);
    let d = `M0,${y(vals[0])}`;
    vals.forEach((v, i) => { if (i && v !== vals[i - 1]) d += ` L${x(i)},${y(v)}`; d += ` L${x(i + 1)},${y(v)}`; });
    return h`<svg class="spark" data-tone="${tone}" viewBox="0 0 ${SW} ${SH}" preserveAspectRatio="none" aria-hidden="true">
      <path class="spark-a" d="${d} L${SW},${SH} L0,${SH} Z"/><path class="spark-l" d="${d}"/><line class="en-spark-now" x1="${((at / 24) * SW).toFixed(1)}" x2="${((at / 24) * SW).toFixed(1)}" y1="2" y2="${SH}"/></svg>`;
  }

  /* ─── Journée heure par heure (jusqu'à maintenant) ────────────────────
     Production : profil horaire partagé (BZ.hours). Batterie et réseau : les compteurs du jour
     sont répartis sur les heures écoulées au prorata du surplus (charge, revente) ou du manque
     (décharge, achat) de chaque heure, puis le niveau de batterie est retracé à rebours depuis
     la valeur actuelle. Home Assistant : les heures écrites dans ses statistiques (production, achat et revente
     de chaque heure, niveau moyen de la batterie), sans rien répartir ni retracer. */
  function dayModel(L) {
    if (BZ.hist) return BZ.hist.dayModel(L);
    const H = nowH(), cur = Math.floor(H), T = BZ.today(), cap = capKwh(), frac = H - cur;
    const past = BZ.hours().filter((x) => x.h < cur);
    const sur = past.map((x) => Math.max(0, x.prod - (x.cons || 0))), lack = past.map((x) => Math.max(0, (x.cons || 0) - x.prod));
    const share = (arr, total) => { const s = sum(arr); return arr.map((v) => (s > 0 ? (v / s) * Math.max(0, total) : 0)); };
    const bNow = (L.bat / 1000) * frac, gNow = (-L.grid / 1000) * frac;   // heure entamée : au rythme actuel
    const chg = share(sur, T.chg - Math.max(0, bNow)), dch = share(lack, T.dch - Math.max(0, -bNow));
    const exp = share(sur, T.exp - Math.max(0, gNow)), imp = share(lack, T.imp - Math.max(0, -gNow));
    const soc = [num(C.batterie_soc) - (bNow / cap) * 100];                 // niveau au début de l'heure entamée
    for (let i = past.length - 1; i >= 0; i--) soc.unshift(soc[0] - ((chg[i] - dch[i]) / cap) * 100);
    const X = (t) => (H > 0 ? BZ.clamp(t / H, 0, 1) : 0);
    return {
      prod: past.map((x) => [X(x.h + 0.5), x.prod]),
      soc: soc.map((v, i) => [X(i), BZ.clamp(v, 0, 100)]).concat([[1, num(C.batterie_soc)]]),
      net: past.map((x, i) => [X(x.h + 0.5), exp[i] - imp[i]]),
    };
  }

  // Batterie : heure à laquelle elle sera pleine (charge) ou à sa réserve (décharge), au rythme actuel
  function batEta(L) {
    if (Math.abs(L.bat) < 15) return null;
    const soc = num(C.batterie_soc), up = L.bat > 0, pct = up ? num(C.batterie_max_pct) - soc : soc - num(C.batterie_min_pct);
    if (pct <= 0) return up ? { long: "charge maximale atteinte", short: "Au maximum" } : { long: "réserve atteinte", short: "À la réserve" };
    const hrs = ((pct / 100) * capKwh()) / (Math.abs(L.bat) / 1000);
    if (hrs > 20) return up ? { long: "pleine dans plus de 20 h", short: "Pleine > 20 h" } : { long: "réserve dans plus de 20 h", short: "Réserve > 20 h" };
    const at = new Date(Date.now() + hrs * 36e5); at.setMinutes(Math.round(at.getMinutes() / 5) * 5, 0, 0);
    const what = up ? "pleine" : "réserve", tom = at.getDate() !== new Date().getDate();
    return { long: `${what} ${tom ? "demain" : "vers"} ${fmt.time(at)}`, short: `${fmt.cap(what)} à ${fmt.time(at)}` };
  }

  /* ─── En-tête ─────────────────────────────────────────────────────── */
  function header(L) {
    const sun = L.solar > 30 ? `Les panneaux produisent ${fmt.powerText(L.solar)}` : "Les panneaux ne produisent pas";
    const bat = Math.abs(L.bat) < 15 ? "la batterie est en veille" : L.bat > 0 ? `la batterie charge à ${fmt.powerText(L.bat)}` : `la batterie rend ${fmt.powerText(-L.bat)}`;
    const grid = L.grid < -15 ? `tu revends ${fmt.powerText(-L.grid)}` : L.grid > 15 ? `tu achètes ${fmt.powerText(L.grid)}` : "rien ne passe par le réseau";
    // Pastille au service du bouton : température du ballon et surplus qui peut le chauffer
    const boost = num(C.ballon_boost) === 1, surplus = -L.grid, temp = `${fmt.n(num(C.ballon_temp))} °C`;
    // Libellés longs, et courts quand l'écran est étroit (en-bl / en-bs) : la pastille et le bouton tiennent côte à côte
    const ls = (long, short) => h`<span class="en-bl">${long}</span><span class="en-bs">${short}</span>`;
    const live = boost ? { tone: "heat", main: ls("Ballon en chauffe", "En chauffe"), sub: temp, on: true }
      : surplus > 15 ? { tone: "grid", main: `Surplus ${fmt.powerText(surplus)}`, sub: `ballon ${temp}`, on: true }
      : { tone: "neutral", main: "Pas de surplus", sub: `ballon ${temp}`, on: false };
    return h`<header class="ph">
      <div><p class="ph-hi">Temps réel</p><h1>Énergie</h1><p class="ph-sub">${sun}, ${bat} et ${grid}.</p></div>
      <div class="ph-a">
        <span class="en-live" data-tone="${live.tone}"><i class="${live.on ? "is-on" : ""}"></i><b>${live.main}</b><span>· ${live.sub}</span></span>
        ${btn({ label: boost ? ls("Arrêter la chauffe", "Arrêter") : ls("Chauffer le ballon", "Chauffer"), aria: boost ? "Arrêter la chauffe du ballon" : "Chauffer le ballon", ic: boost ? "x" : "drop", act: "boiler-boost", kind: "primary", pending: BZ.isPending(C.ballon_boost) })}
      </div></header>`;
  }

  /* ─── Indicateurs : tous sur aujourd'hui (0 h → maintenant), le prix sur la journée ─── */
  function kpis(L) {
    const T = BZ.today(), hrs = BZ.hours(), cur = Math.floor(nowH()), M = dayModel(L);
    // Production : heures écoulées + valeur en direct au bout ; écart avec la prévision de l'heure en cours
    // (Home Assistant : la case de l'heure en cours porte sa prévision à part, fc, et sa production réelle partielle)
    const expected = hrs[cur] ? (hrs[cur].fc ?? hrs[cur].prod) : 0;
    const prodD = expected > 0.1 && L.solar > 30 ? BZ.delta(L.solar / 1000, expected) : "";
    const prodS = daySpark(M.prod, "solar", { live: [1, L.solar / 1000] });
    // Batterie : niveau heure par heure ; puissance + heure pleine (ou réserve), seulement l'heure quand la place manque
    const soc = num(C.batterie_soc), up = L.bat > 0, eta = batEta(L);
    const batD = Math.abs(L.bat) < 15 ? tag("En veille", "neutral")
      : h`<span class="delta en-d" data-tone="${up ? "battery" : "warn"}"><span class="en-dw">${icon(up ? "up" : "down")}${fmt.powerText(Math.abs(L.bat))}</span><span class="en-ds">${eta ? eta.short : up ? "En charge" : "Décharge"}</span></span>`;
    // Réseau : seule valeur signée de la page, comme le compteur (− revente, + achat)
    const g = L.grid, exp = g < -15, imp = g > 15, [gv, gu] = fmt.power(Math.abs(g));
    const gridS = daySpark(M.net, "grid", { zero: true, live: [1, -g / 1000, exp ? "grid" : imp ? "bad" : "neutral"] });
    const t = BZ.tariffNow(), prices = BZ.tariffHours().map((k) => BZ.TARIFS[k].price());
    return h`<div class="kpis en-kpis">
      ${kpi({ label: "Production", ic: "sun", tone: "solar", value: val(fmt.power(L.solar)), delta: prodD, vs: prodD ? lbl(`vs prévu à ${cur} h`, "vs prévu") : `${fmt.kwhText(T.prod)} aujourd'hui`, spark: prodS, to: "insights" })}
      ${kpi({ label: "Batterie SolarFlow", ic: "battery", tone: "battery", value: val([fmt.n(soc), "%"]), delta: batD, vs: eta ? h`<span class="en-eta">${eta.long}</span>` : "", spark: daySpark(M.soc, "battery", { lo: 0, hi: 100, live: [1, soc] }) })}
      ${kpi({ label: "Réseau", ic: "grid", tone: imp ? "bad" : "grid", value: h`<span class="en-gv ${exp ? "is-good" : imp ? "is-bad" : ""}">${val([`${exp ? "−" : imp ? "+" : ""}${gv}`, gu])}</span>`,
        delta: tag(exp ? "Revente" : imp ? "Achat" : "Équilibre", exp ? "good" : imp ? "bad" : "neutral"), vs: h`<span class="en-lo">compteur L3</span>`, spark: gridS, to: "insights" })}
      ${kpi({ label: "Prix du kWh", ic: "clock", tone: t.key, value: val([fmt.n(t.price, 4), "€"]), delta: tag(t.short, t.key), vs: lbl(`jusqu'à ${fmt.time(t.changeAt)}`, `→ ${fmt.time(t.changeAt)}`), spark: stepSpark(prices, t.key, nowH()) })}
    </div>`;
  }

  /* ─── Flux en direct ──────────────────────────────────────────────────
     Deux dispositions : en ligne (carte large) et en croix autour de la maison (carte étroite).
     Les liaisons vont de centre à centre, sous les pastilles opaques : elles touchent toujours les nœuds. */
  const speed = (w) => `${BZ.clamp(2.6 - w / 1400, 0.55, 2.6).toFixed(2)}s`;
  const width = (w) => BZ.clamp(1.5 + w / 1100, 1.5, 5).toFixed(2);
  const link = (d, tone, w, reverse) => h`<path class="fl-bg" d="${d}"/>${w >= 15 ? h`<path class="fl-go ${reverse ? "is-rev" : ""}" data-tone="${tone}" d="${d}" style="--sp:${speed(w)};--sw:${width(w)}"/>` : ""}`;
  const flowNodes = (L) => BZ.flowNodes(L);   // mêmes états que le schéma partagé (flow.js) et la maison
  const fnode = (k, n, [x, y]) => h`
    <div class="fn fn-${k} ${n.w < 15 && k !== "home" ? "is-idle" : ""}" data-tone="${n.tone}" style="--x:${x}%;--y:${y}%">
      <span class="fn-i">${icon(n.ic)}${n.soc != null ? h`<svg class="fn-soc" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="18.5" pathLength="100" style="--p:${n.soc}"/></svg>` : ""}</span>
      <span class="fn-t"><span class="fn-l">${n.label}</span>${val(fmt.power(n.w), "fn-v")}<span class="fn-n">${n.note}</span></span>
    </div>`;
  function flow(L) {
    const N = flowNodes(L), batRev = L.bat < 0, gTone = L.grid > 15 ? "bad" : "grid", gRev = L.grid > 15;
    const lines = (path) => [link(path("sun", "home"), "solar", L.solar), link(path("home", "bat"), "battery", Math.abs(L.bat), batRev),
      link(path("home", "grid"), gTone, Math.abs(L.grid), gRev), link(path("home", "car"), "ev", L.car)];
    // En ligne : soleil → maison → destinations réparties sur la hauteur
    const P = { sun: [13, 50], home: [40, 50], bat: [77, 18], grid: [77, 50], car: [77, 82] };
    const curve = (a, b) => { const [x1, y1] = P[a], [x2, y2] = P[b], mx = (x1 + x2) / 2; return `M${x1 * 10},${y1 * 3.4} C${mx * 10},${y1 * 3.4} ${mx * 10},${y2 * 3.4} ${x2 * 10},${y2 * 3.4}`; };
    // En croix : la maison au centre
    const Q = { sun: [50, 14], bat: [15, 50], home: [50, 50], grid: [85, 50], car: [50, 86] };
    const seg = (a, b) => { const [x1, y1] = Q[a], [x2, y2] = Q[b]; return `M${x1},${y1} L${x2},${y2}`; };
    const summary = `Soleil ${fmt.powerText(L.solar)}, maison ${fmt.powerText(L.house)}, batterie ${Math.abs(L.bat) < 15 ? "en veille" : `${fmt.powerText(Math.abs(L.bat))} ${L.bat > 0 ? "en charge" : "en décharge"}`}, réseau ${Math.abs(L.grid) < 15 ? "à l'équilibre" : `${fmt.powerText(Math.abs(L.grid))} ${L.grid < 0 ? "revendus" : "achetés"}`}, voiture ${fmt.powerText(L.car)}.`;
    return h`<div class="flow" role="img" aria-label="${summary}">
      <div class="flow-wide"><svg viewBox="0 0 1000 340" preserveAspectRatio="none" aria-hidden="true">${lines(curve)}</svg>${Object.entries(N).map(([k, n]) => fnode(k, n, P[k]))}</div>
      <div class="flow-cross"><svg viewBox="0 0 100 100" aria-hidden="true">${lines(seg)}</svg>${Object.entries(N).map(([k, n]) => fnode(k, n, Q[k]))}</div>
    </div>`;
  }
  function flowCard(L) {
    // Autosuffisance en ce moment : part de la consommation couverte sans le réseau (même terme que l'Aperçu, pour la journée)
    const need = L.house + L.car, auto = need > 0 ? BZ.clamp(1 - Math.max(0, L.grid) / need, 0, 1) : 1;
    return card({ cls: "en-flow", title: "Flux en direct", ic: "energy", tone: "accent",
      aside: pill(h`<span><span class="en-a1">Autosuffisance </span>${fmt.n(auto * 100)} %<span class="en-a2"> en ce moment</span><span class="en-a3"> autonome</span></span>`, auto > 0.95 ? "good" : auto > 0.5 ? "warn" : "bad", true),
      link: { label: "Historique", to: "insights" }, body: flow(L) });
  }

  /* ─── Production solaire : avancement de la journée + 3 onduleurs ─── */
  function solarCard() {
    const K = caps(), ws = C.onduleurs_w.map((id) => Math.max(0, num(id) || 0)), tot = ws.reduce((a, b) => a + b, 0), T = BZ.today();
    const done = T.forecast > 0 ? BZ.clamp(T.prod / T.forecast, 0, 1) : 0, rest = Math.max(0, T.forecast - T.prod);
    return card({ cls: "en-sun", target: true, title: "Production solaire", ic: "sun", tone: "accent",
      aside: h`<span class="en-note"><b>${fmt.n(T.prod, 1)}</b> kWh<span class="en-lo"> aujourd'hui</span></span>`, body: h`
      <div class="en-fc">
        ${meter({ value: done * 100, tone: "solar", size: "xs", label: `Production du jour : ${fmt.n(done * 100)} % de la prévision` })}
        <p><span><b>${fmt.n(done * 100)} %</b> <span class="en-fl">des ${fmt.kwhText(T.forecast)} prévus</span><span class="en-fs">du prévu</span></span><span>${rest > 0.05 ? `encore ~${fmt.kwhText(rest)}` : "prévision atteinte"}</span></p>
      </div>
      <ul class="plist en-inv">${C.onduleurs_noms.map((name, i) => {
        const w = ws[i], load = BZ.clamp((w / K[i]) * 100, 0, 100);
        return h`<li><div class="plist-r">
          <span class="dt-ic" data-tone="solar">${icon("sun")}</span>
          <span><strong>${esc(name)}</strong><small>${fmt.powerText(w)}<span class="en-lo"> · ${fmt.n(tot ? (w / tot) * 100 : 0)} % du total</span></small></span>
          ${w > 30 ? pill("Produit", "good", true) : pill("En veille", "neutral")}
          <span class="plist-p"><span>${fmt.n(load)} %</span>${meter({ value: load, tone: "solar", size: "xs", label: `${name} à ${fmt.n(load)} % de sa puissance` })}</span>
        </div></li>`;
      })}</ul>` });
  }

  /* ─── Réseau : sens de l'échange en direct, compteurs du jour ─────── */
  function gridCard(L) {
    const T = BZ.today(), t = BZ.tariffNow(), g = L.grid, exp = g < -15, imp = g > 15;
    const span = Math.max(3000, Math.abs(g) * 1.1), v = exp || imp ? BZ.clamp((Math.abs(g) / span) * 50, 2, 50) : 0;
    // Autoconsommation : part de la production solaire utilisée sur place (maison, batterie, voiture)
    const self = L.solar > 30 ? BZ.clamp(1 - Math.max(0, -g) / L.solar, 0, 1) : null;
    // Argent en jeu maintenant : ce que le soleil et la batterie évitent d'acheter, ou ce que coûte l'achat
    const covered = Math.max(0, L.house + L.car - Math.max(0, g)), saving = covered > 15 || !imp;
    const money = saving
      ? { ic: "euro", tone: "good", label: lbl("Économie en cours", "Économie"), v: val([fmt.n((covered / 1000) * t.price, 2), "€/h"]), title: `${fmt.powerText(covered)} consommés sans le réseau, au tarif ${t.short} (${fmt.n(t.price, 4)} €/kWh)` }
      : { ic: "euro", tone: "bad", label: lbl("Achat en cours", "Achat"), v: val([fmt.n((g / 1000) * t.price, 2), "€/h"]), title: `${fmt.powerText(g)} achetés au tarif ${t.short} (${fmt.n(t.price, 4)} €/kWh)` };
    const tiles = [
      { raw: IMP, tone: "bad", label: "Achat du jour", v: val(fmt.kwh(T.imp)) },
      { raw: EXP, tone: "grid", label: "Revente du jour", v: val(fmt.kwh(T.exp)) },
      { ic: "sun", tone: "solar", label: lbl("Autoconsommation", "Autoconso."), v: self == null ? h`<span class="en-na">pas de soleil</span>` : val([fmt.n(self * 100), "%"]), title: "Part de la production solaire utilisée sur place en ce moment (maison, batterie, voiture)" },
      money,
    ];
    const net = T.exp - T.imp, vt = exp ? `Revente de ${fmt.powerText(-g)}` : imp ? `Achat de ${fmt.powerText(g)}` : "Aucun échange";
    return card({ cls: "en-grd", target: true, title: "Réseau", ic: "grid", tone: "accent",
      aside: h`<span title="Solde du jour : revente moins achat">${pill(`Solde ${net >= 0 ? "+" : "−"}${fmt.n(Math.abs(net), 1)} kWh`, net >= 0 ? "good" : "bad")}</span>`, body: h`
      <div class="en-dv" data-tone="${exp ? "grid" : imp ? "bad" : "neutral"}" role="meter" aria-label="Échange avec le réseau" aria-valuemin="${Math.round(-span)}" aria-valuemax="${Math.round(span)}" aria-valuenow="${Math.round(-g)}" aria-valuetext="${vt}">
        <span class="en-dv-l ${imp ? "is-on" : ""}">Achat</span>
        <span class="en-dv-t">
          <i class="${exp ? "is-r" : "is-l"}" style="--v:${v.toFixed(2)}%"></i><b></b>
          <em style="--x:${BZ.clamp(50 + (exp ? v : -v), 14, 86).toFixed(2)}%">${fmt.powerText(Math.abs(g))}</em>
        </span>
        <span class="en-dv-r ${exp ? "is-on" : ""}">Revente</span>
      </div>
      <ul class="en-gt">${tiles.map((x) => h`<li ${x.title ? `title="${esc(x.title)}"` : ""}><span class="dt-ic" data-tone="${x.tone}">${x.raw || icon(x.ic)}</span>
        <span><small>${x.label}</small><b>${x.v}</b></span></li>`)}</ul>` });
  }

  /* ─── Batterie SolarFlow ──────────────────────────────────────────── */
  function batCard(L) {
    const soc = num(C.batterie_soc), min = num(C.batterie_min_pct), max = num(C.batterie_max_pct);
    const tin = num(C.batterie_total_charge_kwh), tout = num(C.batterie_total_decharge_kwh), eff = tin ? tout / tin : 0;
    const state = Math.abs(L.bat) < 15 ? pill("En veille", "neutral") : L.bat > 0 ? pill("Charge", "battery", true) : pill("Décharge", "warn", true);
    const life = `Depuis l'installation : ${big(tin)} kWh stockés, ${big(tout)} kWh rendus`;
    return card({ cls: "en-bat", target: true, title: "Batterie SolarFlow", ic: "battery", tone: "accent", aside: state, body: h`
      <div class="en-bat-top">
        ${ring({ value: soc, tone: "battery", size: 112, stroke: 10, mark: min, label: `Batterie à ${fmt.n(soc)} %, ${fmt.kwhText(num(C.batterie_dispo_kwh))} disponibles, réserve à ${fmt.n(min)} %`,
          inner: h`<b>${fmt.n(soc)}<small>%</small></b><span>${fmt.kwhText(num(C.batterie_dispo_kwh))}</span>` })}
        <ul class="en-packs">${C.packs_soc.map((id, i) => h`<li>
          <b>Pack ${i + 1}</b>${meter({ value: num(id), tone: "battery", size: "xs", label: `Pack ${i + 1} à ${fmt.n(num(id))} %` })}<em>${fmt.n(num(id))} %</em>
          <small><span class="sr">Température </span>${fmt.n(num(C.packs_temp[i]))}°</small></li>`)}</ul>
      </div>
      <div class="en-kv">
        <div><span>${lbl("Stocké aujourd'hui", "Stocké")}</span><b>${val(fmt.kwh(num(C.batterie_charge_jour_kwh)))}</b></div>
        <div><span>${lbl("Rendu aujourd'hui", "Rendu")}</span><b>${val(fmt.kwh(num(C.batterie_decharge_jour_kwh)))}</b></div>
        <div title="${life}"><span>${lbl("Rendement global", "Rendement")}</span><b>${val([fmt.n(eff * 100, 1), "%"])}</b></div>
      </div>
      <div class="en-set">
        <div><span>Réserve minimale</span>${stepper({ value: fmt.n(min), unit: " %", act: "bat-min", label: "Réserve minimale", cur: min, min: 0, max: 50, pending: BZ.isPending(C.batterie_min_pct) })}</div>
        <div><span>Charge maximale</span>${stepper({ value: fmt.n(max), unit: " %", act: "bat-max", label: "Charge maximale", cur: max, min: 70, max: 100, pending: BZ.isPending(C.batterie_max_pct) })}</div>
      </div>
      <p class="foot en-bat-f"><span>Température ${fmt.n(num(C.batterie_temp))} °C</span><span>Depuis l'installation : <span class="en-nw">${big(tin)} kWh stockés</span> · <span class="en-nw">${big(tout)} rendus</span></span></p>` });
  }

  /* ─── Tarifs : cadran des 24 h à venir + prix ─────────────────────── */
  // Cadran : une case par heure (0 h en haut, sens horaire). Il montre les 24 prochaines heures :
  // rien n'est estompé, le repère « maintenant » marque le départ. Heures du cadran en HTML (11 px à toute taille).
  const DS = 120, DM = 16, DB = DS + 2 * DM, DR = 48, DW = 13;
  function dial(hours, H, t, aria) {
    const cx = DS / 2, c = 2 * Math.PI * DR, seg = c / 24, gap = 1.3;
    const a = (H / 24) * 2 * Math.PI, px = cx + DR * Math.sin(a), py = cx - DR * Math.cos(a);
    const out = ((DR + DW / 2) / DB) * 100;    // rayon extérieur de l'anneau, en % du cadran
    const lab = [[0, "0h", 0, -10], [6, "6h", 14, 0], [12, "12h", 0, 10], [18, "18h", -14, 0]].map(([k, l, dx, dy]) => {
      const b = (k / 24) * 2 * Math.PI, sx = Math.sin(b), sy = -Math.cos(b);
      return h`<span style="left:calc(${(50 + out * sx).toFixed(2)}% + ${dx}px);top:calc(${(50 + out * sy).toFixed(2)}% + ${dy}px)">${l}</span>`;
    });
    return h`<div class="en-dial" data-tone="${t.key}" role="img" aria-label="${aria}">
      <svg viewBox="${-DM} ${-DM} ${DB} ${DB}" aria-hidden="true">
        <g transform="rotate(-90 ${cx} ${cx})">${hours.map((k, i) => h`<circle data-tariff="${k}" cx="${cx}" cy="${cx}" r="${DR}" stroke-width="${DW}" stroke-dasharray="${(seg - gap).toFixed(2)} ${c.toFixed(2)}" stroke-dashoffset="${(-(seg * i + gap / 2)).toFixed(2)}"/>`)}</g>
        <circle class="en-dial-now" cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="5.5"/>
      </svg>
      <div class="en-dial-ax" aria-hidden="true">${lab}</div>
      <div class="en-dial-c"><b>${t.short}</b><span>→ ${fmt.time(t.changeAt)}</span></div></div>`;
  }

  function tariffCard() {
    const t = BZ.tariffNow(), hours = BZ.tariffHours(), H = nowH(), T = BZ.TARIFS, hp = T.hp.price(), cur = Math.floor(H);
    // Prochain début des super creuses
    let hscAt = null;
    for (let k = 1; k <= 24; k++) { const a = (cur + k) % 24; if (BZ.tariffAt(a) === "hsc" && BZ.tariffAt((a + 23) % 24) !== "hsc") { hscAt = a; break; } }
    // Les 24 prochaines heures, plage par plage, à partir de maintenant
    const runs = [];
    for (let k = 0; k < 24; k++) { const hh = (cur + k) % 24, key = hours[hh]; if (runs.length && runs[runs.length - 1].k === key) runs[runs.length - 1].n++; else runs.push({ k: key, s: hh, n: 1 }); }
    const aria = `Tarifs des 24 prochaines heures : ${runs.map((r, i) => `${T[r.k].label.toLowerCase()} ${i ? `de ${r.s} h` : "maintenant"} jusqu'à ${(r.s + r.n) % 24} h`).join(", ")}.`;
    const aside = t.key === "hsc" ? pill("Super creuses en cours", "hsc", true) : hscAt != null ? pill(`Super creuses à ${String(hscAt).padStart(2, "0")}:00`, "hsc") : "";
    return card({ cls: "en-tar", title: h`Tarifs<span class="en-tt"> du jour</span>`, ic: "clock", tone: "accent", aside, body: h`
      <div class="en-tar-b">
        ${dial(hours, H, t, aria)}
        <ul class="en-tk">
          <li class="en-tk-h" aria-hidden="true"><span>Plage</span><span>€/kWh</span></li>
          ${["hp", "hc", "hsc"].map((k) => {
            const p = T[k].price();
            return h`<li data-tone="${k}" class="${k === t.key ? "is-cur" : ""}"><i></i>
              <span><strong>${lbl(T[k].label, T[k].short)}</strong><small>${BZ.rangeLabel(k)}</small></span>
              <span class="en-tk-v"><b><span class="sr">Prix : </span>${fmt.n(p, 4)}<span class="sr"> € par kWh</span></b><small>${k === "hp" ? "référence" : `−${fmt.n((1 - p / hp) * 100)} % vs HP`}</small></span></li>`;
          })}</ul>
      </div>` });
  }

  BZ.pages.energy = () => {
    const L = BZ.live();
    // Mobile : la maison en direct remplace le schéma « Flux en direct » (masqué sous 768 px)
    return h`${header(L)}${BZ.house()}${kpis(L)}
      <div class="layout en-grid">
        <div class="col en-l">${flowCard(L)}<div class="en-pair">${solarCard()}${gridCard(L)}</div></div>
        <div class="col en-r">${batCard(L)}${tariffCard()}</div>
      </div>`;
  };
})();
;
// ═══ v3/js/pages/insights.js
// Bilan (V3) : l'historique et la rentabilité. Une seule période pilote toute la page.
//  En-tête : période (Jour / 7 jours / Mois / Année), ‹ › pour remonter dans le temps, export CSV
//  Ligne 1 : 4 indicateurs (vs la même durée juste avant, arrêtée à la même heure), mini-courbe sur la période
//  Gauche  : graphique principal, puis Comparaison (ce que les indicateurs ne disent pas) + Meilleurs moments
//  Droite  : D'où vient ta consommation (anneau + réseau par tarif), Rentabilité solaire
(() => {
  const BZ = window.BZ;
  const { h, esc, fmt, icon, val, card, pill, kpi, pills, donut, meter, btn, C } = BZ;

  /* ─── Historique de la page ──────────────────────────────────────────
     Construit sur BZ.day() (core.js), avec quatre corrections à remonter un jour dans core.js :
     1. rien n'est produit avant la mise en service (C.solaire_mise_en_service) ;
     2. la batterie ne stocke que ce que la soirée et la nuit consommeront, et en rend 90 % ;
     3. les économies des jours passés sont recalées pour que leur somme = compteur cumulé (BZ.roi().total) ;
     4. la période d'avant s'arrête à la même heure tant que la période en cours n'est pas finie. */
  // Début de l'historique : la mise en service (Home Assistant : historique_debut de config.js s'il est rempli)
  const [Y0, M0, D0] = String((BZ.hist && C.historique_debut) || C.solaire_mise_en_service).split("-").map(Number);
  const START = new Date(Y0, M0 - 1, D0);
  const HRS = Array.from({ length: 24 }, (_, i) => i);
  const SUN = (x) => Math.max(0, Math.exp(-((x + 0.5 - 13.2) ** 2) / (2 * 2.7 ** 2)) - 0.02);      // mêmes profils que BZ.hours()
  const USE = (x) => 0.35 + (x >= 6 && x < 8 ? 0.9 : 0) + (x >= 9 && x < 12 ? 1.6 : 0) + (x >= 18 && x < 21 ? 1.2 : 0) + (x >= 2 && x < 5 ? 0.6 : 0);
  const DARK = (x) => USE(x) * BZ.clamp(1 - 4 * SUN(x), 0, 1);                                   // conso sans soleil : batterie puis réseau
  const SUN_T = HRS.reduce((a, x) => a + SUN(x), 0), USE_T = HRS.reduce((a, x) => a + USE(x), 0);
  // Part d'un profil horaire déjà écoulée à l'heure H (décimale), éventuellement sur certaines heures seulement
  const share = (f, H, keep = () => true) => { let a = 0, t = 0; HRS.forEach((x) => { if (!keep(x)) return; t += f(x); a += f(x) * BZ.clamp(H - x, 0, 1); }); return t ? a / t : 0; };
  const sod = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const isToday = (d) => sod(d).getTime() === sod(new Date()).getTime();
  const D12 = (y, m, d) => new Date(y, m, d, 12);
  const span = (a, n) => Array.from({ length: n }, (_, i) => D12(a.getFullYear(), a.getMonth(), a.getDate() + i));
  const daysIn = (d) => new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  const nowH = () => { const n = new Date(); return n.getHours() + n.getMinutes() / 60; };
  const TAR = ["hp", "hc", "hsc"];
  const FIELDS = ["prod", "cons", "self", "chg", "dch", "imp", "exp", "hp", "hc", "hsc", "savings"];
  // Home Assistant (BZ.hist) : une valeur inconnue (NaN, en chargement) le reste, un jour sans historique n'est pas compté,
  // et les drapeaux des jours suivent (history.js)
  const sum = (days) => (BZ.hist ? BZ.hist.sum(days) : FIELDS.reduce((o, f) => ((o[f] = days.reduce((a, x) => a + (x[f] || 0), 0)), o), {}));
  const worth = (x) => (x.self + x.dch) * 0.2 + x.exp * 0.06;     // même barème que BZ.day()

  const memo = new Map();
  function pastDay(date) {                                           // journée terminée, corrigée (économies avant recalage)
    const k = sod(date).getTime();
    if (memo.has(k)) return memo.get(k);
    const x = BZ.day(date);
    let o;
    if (sod(date) < START) {
      const r = x.imp ? x.cons / x.imp : 0;
      o = { ...x, prod: 0, self: 0, chg: 0, dch: 0, exp: 0, imp: x.cons, hp: x.hp * r, hc: x.hc * r, hsc: x.hsc * r, evSun: 0, raw: 0, pre: true };
    } else {
      const need = Math.max(0, x.cons - x.self), extra = x.chg + x.exp;
      const chg = Math.min(x.chg, (need * 0.6) / 0.9), dch = chg * 0.9, imp = Math.max(0, need - dch), r = x.imp ? imp / x.imp : 0;
      o = { ...x, chg, dch, exp: extra - chg, imp, hp: x.hp * r, hc: x.hc * r, hsc: x.hsc * r };
      o.raw = worth(o);
    }
    memo.set(k, o);
    return o;
  }
  // Recalage : somme des jours passés depuis la mise en service + aujourd'hui (capteur) = compteur cumulé
  let rawSum = { day: -1, v: 0 }, F = 1;
  function rescale() {
    const t = sod(new Date()).getTime();
    if (rawSum.day !== t) {
      let v = 0;
      for (const d = D12(Y0, M0 - 1, D0); sod(d).getTime() < t; d.setDate(d.getDate() + 1)) v += pastDay(new Date(d)).raw;
      rawSum = { day: t, v };
    }
    return Math.max(0, BZ.roi().total - BZ.today().savings) / (rawSum.v || 1);
  }
  const dayDemo = (date) => (isToday(date) ? { ...BZ.day(date), today: true } : { ...pastDay(date), savings: pastDay(date).raw * F });
  // Home Assistant : les vraies journées (statistiques), sans aucune des corrections de la démo
  const dayX = (date) => (BZ.hist ? { ...BZ.day(date), today: isToday(date) || undefined } : dayDemo(date));
  // Heures d'une journée (aujourd'hui ou passée) : HA les lit dans l'historique, la démo les répartit sur ses profils
  const hoursOf = (HB, live, date, x) => (HB ? (live ? BZ.hours() : HB.hoursOf(date)).map((b) => ({ ...b, key: b.label })) : live ? todayHours() : dayHours(x));

  // Une journée arrêtée à l'heure H : production au rythme du soleil, batterie et réseau au rythme des heures sans soleil
  function cut(x, H) {
    const sP = share(SUN, H), o = { ...x };
    ["prod", "self", "chg", "exp"].forEach((f) => (o[f] = (x[f] || 0) * sP));
    o.dch = (x.dch || 0) * share(DARK, H);
    TAR.forEach((k) => (o[k] = (x[k] || 0) * share(DARK, H, (hh) => BZ.tariffAt(hh) === k)));
    o.imp = o.hp + o.hc + o.hsc;
    o.cons = o.self + o.dch + o.imp;
    o.savings = (x.savings || 0) * (worth(o) / (worth(x) || 1));
    return o;
  }

  // Aujourd'hui heure par heure. Heures à venir : le rythme de la journée, ajusté par la prévision (× 0,6 à × 1,3)
  function todayHours() {
    const H = nowH(), t = BZ.today(), done = (x) => x + 1 <= H;
    const sP = HRS.reduce((a, x) => a + (done(x) ? SUN(x) : 0), 0), uP = HRS.reduce((a, x) => a + (done(x) ? USE(x) : 0), 0);
    const kP = sP > 0 ? t.prod / sP : 0, kC = uP > 0 ? t.cons / uP : 0;
    const kF = sP >= 0.2 * SUN_T ? kP * BZ.clamp(t.forecast / (kP * SUN_T || 1), 0.6, 1.3) : Math.max(0, t.forecast - t.prod) / (SUN_T - sP || 1);
    return HRS.map((x) => ({ h: x, key: `${x}h`, tariff: BZ.tariffAt(x), future: !done(x), current: x === Math.floor(H), prod: SUN(x) * (done(x) ? kP : kF), cons: done(x) ? USE(x) * kC : null }));
  }
  const dayHours = (x) => HRS.map((hh) => ({ h: hh, key: `${hh}h`, tariff: BZ.tariffAt(hh), prod: (SUN(hh) / SUN_T) * x.prod, cons: (USE(hh) / USE_T) * x.cons }));

  // Répartit les totaux d'une journée sur ses heures (mini-courbes « Jour » : autosuffisance cumulée, économies par heure)
  function hourly(B, T) {
    const tot = (a) => a.reduce((s, v) => s + v, 0) || 1;
    const mn = B.map((b) => Math.min(b.prod, b.cons || 0)), ks = T.self / tot(mn), self = mn.map((v) => v * ks);
    const gap = B.map((b, i) => Math.max(0, (b.cons || 0) - self[i])), g = tot(gap);
    const over = B.map((b, i) => Math.max(0, b.prod - self[i])), ov = tot(over);
    const worthH = B.map((_, i) => (self[i] + (gap[i] / g) * T.dch) * 0.2 + (over[i] / ov) * T.exp * 0.06), w = tot(worthH);
    let ci = 0, cc = 0;
    return {
      aut: B.map((b, i) => { ci += (gap[i] / g) * T.imp; cc += b.cons || 0; return cc ? BZ.clamp(1 - ci / cc, 0, 1) : null; }),
      eco: worthH.map((v) => (v / w) * T.savings),
    };
  }

  /* ─── Périodes : la période affichée et celle d'avant ─────────────── */
  function minOff(kind) {
    const t = sod(new Date()), days = Math.round((t - START) / 864e5);
    if (kind === "jour") return -days;
    if (kind === "semaine") return -Math.floor(days / 7);
    if (kind === "mois") return START.getFullYear() * 12 + START.getMonth() - (t.getFullYear() * 12 + t.getMonth());
    return START.getFullYear() - t.getFullYear();
  }
  // Home Assistant : chaque période et celle d'avant viennent des statistiques ; l'écart ne compare que ce qui est connu des
  // deux côtés (panneaux posés, compteurs existants), sur la même durée, la période d'avant arrêtée à la même heure
  function buildHA(kind, off) {
    const HB = BZ.hist, K = HB.key, S = HB.shifts, now = new Date(), y = now.getFullYear(), m = now.getMonth(), d = now.getDate(), live = off === 0;
    const P = { kind, off, live, H: nowH(), min: minOff(kind) };
    const like = (a, b, pa, pb, shift, cut = live) => HB.like({ a: K(a), b: K(b), pa: K(pa), pb: K(pb), live: cut, shift });
    if (kind === "jour") {
      const date = D12(y, m, d + off), x = dayX(date), buckets = hoursOf(HB, live, date, x), total = sum([x]);
      // Les heures arrivent à part (statistiques horaires) ; tant qu'elles manquent, pas de graphique
      Object.assign(total, { loading: total.loading || buckets.some((b) => b.loading), error: total.error || buckets.some((b) => b.error), gapHours: buckets.filter((b) => b.gap && !b.dst).length });
      const pd = D12(y, m, d + off - 1);
      return { ...P, date, buckets, total, cmp: like(date, date, pd, pd, S.days(1)) };
    }
    if (kind === "semaine") {
      const dates = span(D12(y, m, d - 6 + 7 * off), 7), pd = span(D12(y, m, d - 13 + 7 * off), 7);
      const buckets = dates.map((x) => ({ key: fmt.cap(x.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", "")), ...dayX(x), date: x, current: live && isToday(x) }));
      return { ...P, from: dates[0], to: dates[6], pFrom: pd[0], pTo: pd[6], buckets, total: sum(buckets), cmp: like(dates[0], dates[6], pd[0], pd[6], S.days(7)) };
    }
    if (kind === "mois") {
      const first = D12(y, m + off, 1), n = daysIn(first), fc = live ? BZ.period("mois").buckets : [];
      const buckets = span(first, n).map((x, i) => (live && x.getDate() > d ? { ...fc[i], key: String(x.getDate()), date: x }
        : { key: String(x.getDate()), ...dayX(x), date: x, current: live && x.getDate() === d }));
      const pFirst = D12(first.getFullYear(), first.getMonth() - 1, 1), pn = daysIn(pFirst), whole = !live || d > pn;
      const last = live ? D12(y, m, d) : D12(first.getFullYear(), first.getMonth(), n);
      return { ...P, first, pFirst, whole, upTo: d, buckets, total: sum(buckets.filter((b) => !b.forecast)),
        cmp: like(first, last, pFirst, D12(pFirst.getFullYear(), pFirst.getMonth(), whole ? pn : d), S.month(K(first).slice(0, 7)), live && !whole) };
    }
    const Y = y + off, fc = live ? BZ.period("annee").buckets : [];
    const buckets = BZ.MONTHS.map((lab, i) => {
      if (live && i > m) return { ...fc[i], key: lab, i };
      const n = live && i === m ? d : daysIn(D12(Y, i, 1));
      // Un mois = la somme de ses journées (le mois en cours : jusqu'à aujourd'hui)
      return { key: lab, i, ...HB.monthSum(Y, i, live && i === m ? d : null), days: live && i === m ? d - 1 + share(USE, P.H) : n, current: live && i === m, pre: D12(Y, i, n) < START };
    });
    const pb = live ? D12(Y - 1, m, Math.min(d, daysIn(D12(Y - 1, m, 1)))) : D12(Y - 1, 11, 31);
    return { ...P, year: Y, buckets, total: sum(buckets.filter((b) => !b.forecast)), cmp: like(D12(Y, 0, 1), live ? D12(y, m, d) : D12(Y, 11, 31), D12(Y - 1, 0, 1), pb, S.year(Y)) };
  }
  function build(kind, off) {
    if (BZ.hist) { const P = buildHA(kind, off); P.prevTotal = P.cmp.prevTotal; P.cmpTotal = P.cmp.cmpTotal || P.total; return P; }
    const now = new Date(), H = nowH(), y = now.getFullYear(), m = now.getMonth(), d = now.getDate(), live = off === 0;
    // Dernier jour de la période d'avant arrêté à la même heure, découpé sur les profils de la démo
    const before = (dates) => dates.map((x, i) => (live && i === dates.length - 1 ? cut(dayX(x), H) : dayX(x)));
    const P = { kind, off, live, H, min: minOff(kind) };
    if (kind === "jour") {
      const date = D12(y, m, d + off), x = dayX(date), buckets = hoursOf(null, live, date, x), total = sum([x]);
      return { ...P, date, buckets, total, prevTotal: sum(before([D12(y, m, d + off - 1)])) };
    }
    if (kind === "semaine") {
      const dates = span(D12(y, m, d - 6 + 7 * off), 7), pd = span(D12(y, m, d - 13 + 7 * off), 7);
      const buckets = dates.map((x) => ({ key: fmt.cap(x.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", "")), ...dayX(x), date: x, current: live && isToday(x) }));
      return { ...P, from: dates[0], to: dates[6], pFrom: pd[0], pTo: pd[6], buckets, total: sum(buckets), prevTotal: sum(before(pd)) };
    }
    if (kind === "mois") {
      const first = D12(y, m + off, 1), n = daysIn(first), fc = live ? BZ.period("mois").buckets : [];
      const buckets = span(first, n).map((x, i) => (live && x.getDate() > d ? { ...fc[i], key: String(x.getDate()), date: x }
        : { key: String(x.getDate()), ...dayX(x), date: x, current: live && x.getDate() === d }));
      const pFirst = D12(first.getFullYear(), first.getMonth() - 1, 1), pn = daysIn(pFirst), whole = !live || d > pn;
      const pd = span(pFirst, whole ? pn : d);
      return { ...P, first, pFirst, whole, upTo: d, buckets, total: sum(buckets.filter((b) => !b.forecast)), prevTotal: sum(whole ? pd.map(dayX) : before(pd)) };
    }
    const Y = y + off, fc = live ? BZ.period("annee").buckets : [];
    const buckets = BZ.MONTHS.map((lab, i) => {
      if (live && i > m) return { ...fc[i], key: lab, i };
      const n = live && i === m ? d : daysIn(D12(Y, i, 1));
      return { key: lab, i, ...sum(span(D12(Y, i, 1), n).map(dayX)), days: live && i === m ? d - 1 + share(USE, H) : n, current: live && i === m, pre: D12(Y, i, n) < START };
    });
    const pd = [];
    for (let i = 0; i <= (live ? m : 11); i++) pd.push(...span(D12(Y - 1, i, 1), live && i === m ? d : daysIn(D12(Y - 1, i, 1))));
    return { ...P, year: Y, buckets, total: sum(buckets.filter((b) => !b.forecast)), prevTotal: sum(before(pd)) };
  }

  /* ─── Libellés ────────────────────────────────────────────────────── */
  const dn = (d) => (d.getDate() === 1 ? "1er" : String(d.getDate()));
  const sh = (d) => `${dn(d)} ${BZ.MONTHS[d.getMonth()]}`;                                           // « 8 oct. », « 1er sept. »
  const range = (a, b) => (a.getMonth() !== b.getMonth() ? `${sh(a)} – ${sh(b)}` : a.getDate() === b.getDate() ? sh(b) : `${dn(a)}–${sh(b)}`);
  const monthOf = (d) => BZ.MONTHS_LONG[d.getMonth()];
  function labels(P) {
    const t = fmt.time(new Date());
    let none = !P.cmp && P.prevTotal.prod <= 0.01 && P.total.prod > 0.01;
    const L = { jour: { unit: "heure", per: "par heure" }, semaine: { unit: "jour", per: "par jour" }, mois: { unit: "jour", per: "par jour" }, annee: { unit: "mois", per: "par mois" } }[P.kind];
    if (P.kind === "jour") {
      const pd = new Date(P.date); pd.setDate(pd.getDate() - 1);
      Object.assign(L, P.live
        ? { title: `Aujourd'hui à ${t}`, compare: "vs hier à la même heure", cur: "Aujourd'hui", prev: `Hier à ${t}`, vs: `vs hier à ${t}` }
        : { title: P.off === -1 ? `Hier, ${fmt.date(P.date, { weekday: "long", day: "numeric", month: "long" })}` : fmt.cap(fmt.date(P.date, { weekday: "long", day: "numeric", month: "long" })), compare: "vs la veille", cur: sh(P.date), prev: sh(pd), vs: "vs la veille" });
    } else if (P.kind === "semaine") {
      Object.assign(L, P.live
        ? { title: "7 derniers jours", compare: "vs les 7 jours d'avant", cur: "7 jours", prev: "7 j avant", vs: "vs 7 j avant" }
        : { title: `Du ${P.from.getMonth() === P.to.getMonth() ? dn(P.from) : sh(P.from)} au ${sh(P.to)}`, compare: "vs les 7 jours d'avant", cur: range(P.from, P.to), prev: range(P.pFrom, P.pTo), vs: `vs ${range(P.pFrom, P.pTo)}` });
    } else if (P.kind === "mois") {
      const prev = P.whole ? fmt.cap(monthOf(P.pFirst)) : range(P.pFirst, D12(P.pFirst.getFullYear(), P.pFirst.getMonth(), P.upTo));
      Object.assign(L, P.live
        ? { title: fmt.cap(monthOf(P.first)), compare: P.whole ? `vs ${monthOf(P.pFirst)} entier` : `vs ${prev}, à la même heure`, cur: range(P.first, D12(P.first.getFullYear(), P.first.getMonth(), P.upTo)), prev, vs: `vs ${P.whole ? monthOf(P.pFirst) : prev}` }
        : { title: `${fmt.cap(monthOf(P.first))} ${P.first.getFullYear()}`, compare: `vs ${monthOf(P.pFirst)}`, cur: fmt.cap(monthOf(P.first)), prev, vs: `vs ${monthOf(P.pFirst)}` });
    } else {
      const Y = P.year;
      Object.assign(L, P.live
        ? { title: String(Y), compare: `vs ${Y - 1} à la même date`, cur: String(Y), prev: `${Y - 1} à date`, vs: `vs ${Y - 1} à date` }
        : { title: String(Y), compare: `vs ${Y - 1}`, cur: String(Y), prev: String(Y - 1), vs: `vs ${Y - 1}` });
    }
    if (P.cmp) {
      // Home Assistant : rien de comparable (panneaux pas encore posés, ou compteurs pas encore là) ; ou comparaison
      // réduite aux jours connus des deux côtés
      const c = P.cmp, from = c.from ? new Date(`${c.from}T12:00:00`) : null;
      none = !!c.none;
      const pn = { jour: "de la veille", semaine: "des 7 jours d'avant", mois: P.pFirst ? `de ${monthOf(P.pFirst)}` : "d'avant", annee: String(P.year - 1) }[P.kind];
      if (c.none) { L.compare = c.before ? `panneaux posés en ${monthOf(START)} ${START.getFullYear()}` : `pas de comparaison : historique ${pn} incomplet`; L.vs = c.before ? "rien à comparer" : "historique incomplet"; }
      else if (c.partial) { L.compare += `, dès le ${sh(from)}`; L.vs += `, dès le ${sh(from)}`; L.cur = `${L.cur} dès le ${sh(from)}`; L.prev = `${L.prev} dès le ${sh(new Date(`${c.pfrom}T12:00:00`))}`; }
    } else if (none) L.compare = `panneaux posés en ${monthOf(START)} ${START.getFullYear()}`;
    L.none = none;
    // Home Assistant : heures ou jours sans aucune statistique (HA arrêté) — ils comptent pour 0 dans les totaux
    const gaps = P.kind === "jour" ? P.total.gapHours : P.total.gaps;
    if (BZ.hist && gaps > 0) L.gaps = P.kind === "jour" ? ` · ${gaps} heure${gaps > 1 ? "s" : ""} sans données` : P.kind === "annee" ? " · données incomplètes" : ` · ${gaps} jour${gaps > 1 ? "s" : ""} sans données`;
    // Jours d'avant le premier relevé d'un compteur : comptés à part (« — »), dit dans le sous-titre
    const cs = BZ.hist && P.total.nocov ? BZ.hist.coverStart() : null;
    if (cs && cs > "0000-01-01" && cs < "9999") L.gaps = `${L.gaps || ""} · historique dès le ${fmt.date(new Date(`${cs}T12:00:00`), { day: "numeric", month: "long", year: "numeric" })}`;
    return L;
  }

  /* ─── Petits calculs et utilitaires ───────────────────────────────── */
  const aut = (x) => (x && x.cons ? BZ.clamp(1 - x.imp / x.cons, 0, 1) : 0);          // part de la conso sans réseau
  const selfUse = (x) => (x && x.prod ? BZ.clamp(1 - x.exp / x.prod, 0, 1) : 0);      // part de la production gardée
  const bill = (x) => TAR.reduce((a, k) => a + (BZ.hist ? x[k] : x[k] || 0) * BZ.TARIFS[k].price(), 0);   // HA : inconnue tant que la répartition manque
  // Variation : « 1 pt » au singulier
  const dl = (cur, prev, o = {}) => { const s = BZ.delta(cur, prev, o); return o.unit === "pts" && Math.round(Math.abs(cur - prev) * 100) === 1 ? s.replace(" pts</span>", " pt</span>") : s; };
  const monthName = (P, i) => fmt.cap(BZ.MONTHS_LONG[i]);
  const nameOf = (P, b, i) => P.kind === "jour" ? `${b.h}h – ${b.h + 1}h` : P.kind === "annee" ? monthName(P, i)
    : fmt.cap(fmt.date(b.date, { weekday: "long", day: "numeric", month: "short" }));
  const shortOf = (P, b, i) => (P.kind === "jour" ? `${b.h}h` : P.kind === "annee" ? BZ.MONTHS[i] : fmt.date(b.date, { weekday: "short", day: "numeric" }));   // carte très étroite
  const tipName = (c, b, i) => (c.kind === "annee" ? `${monthName(c, i)} ${c.year}` : c.kind === "jour" ? `${b.h}h – ${b.h + 1}h`
    : fmt.cap(fmt.date(b.date, { weekday: "long", day: "numeric", month: "long" })));
  const pc = (v, of) => `${((v / of) * 100).toFixed(3)}%`;
  // Haut d'échelle « rond » mais serré (évite 1 000 pour un maximum de 760)
  const niceTop = (v) => { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)), n = v / p; return ([1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].find((s) => n <= s) || 10) * p; };
  const UP = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';
  const CMP = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h15M15 4l4 4-4 4M20 16H5M9 12l-4 4 4 4"/></svg>';
  const DL = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5v11.5M7 10.5l5 5 5-5M4.5 20h15"/></svg>';
  const pad2 = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

  // Courbe monotone : passe par chaque mesure sans « boucler » au-dessus ou en dessous (Fritsch–Carlson)
  function mono(pts) {
    const n = pts.length;
    if (n < 2) return "";
    const dx = [], m = [];
    for (let i = 0; i < n - 1; i++) { dx[i] = pts[i + 1][0] - pts[i][0]; m[i] = (pts[i + 1][1] - pts[i][1]) / (dx[i] || 1); }
    const t = [m[0]];
    for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (3 * (dx[i - 1] + dx[i])) / ((2 * dx[i] + dx[i - 1]) / m[i - 1] + (dx[i] + 2 * dx[i - 1]) / m[i]);
    t[n - 1] = m[n - 2];
    let d = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < n - 1; i++) { const k = dx[i] / 3; d += ` C${pts[i][0] + k},${pts[i][1] + t[i] * k} ${pts[i + 1][0] - k},${pts[i + 1][1] - t[i + 1] * k} ${pts[i + 1][0]},${pts[i + 1][1]}`; }
    return d;
  }

  /* ─── Graphiques de la page (une infobulle partagée : #tip) ──────────
     « bars »  : production empilée (maison / batterie / revendu), prévision hachurée, courbe de consommation
                 (la case en cours est projetée à sa fin, en pointillé ; la valeur partielle reste dans l'infobulle).
     « lines » : une journée heure par heure, production (+ prévision aujourd'hui) et consommation, bande des tarifs. */
  const SER = [["self", "Utilisé à la maison", "solar"], ["chg", "Stocké en batterie", "battery"], ["exp", "Revendu au réseau", "grid"]];
  const REG = new Map();
  const W = 600, H = 300;
  let seq = 0;
  const gridLines = (max, y) => [0.25, 0.5, 0.75, 1].map((k) => h`<line class="gl" x1="0" x2="${W}" y1="${y(max * k)}" y2="${y(max * k)}"/>`);
  const yTicks = (max, y) => [0.5, 1].map((k) => h`<span class="bi-yl" style="--y:${pc(y(max * k), H)}">${fmt.n(max * k, Number.isInteger(max * k) ? 0 : 1)}${k === 1 ? " kWh" : ""}</span>`);
  const shell = (id, label, svg, over, axis, band = "") => h`<figure class="bi-chart" data-bi="${id}" tabindex="0" aria-label="${esc(label)}. Flèches gauche et droite pour parcourir.">
      <div class="bi-plot"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true">${svg}</svg>${over}
        <span class="bi-dot bi-cur is-p"></span><span class="bi-dot bi-cur is-c"></span></div>
      ${band}<div class="bi-ax" aria-hidden="true">${axis}</div></figure>`;

  function combo({ P, buckets, label, every = 1 }) {
    const id = `bi${++seq}`, n = buckets.length, slot = W / n;
    const bw = Math.max(4, Math.min(28, slot * (n > 20 ? 0.62 : 0.46)));
    const tot = buckets.map((b) => (b.forecast ? b.prod || 0 : SER.reduce((a, [k]) => a + (b[k] || 0), 0)));
    const rest = buckets.map((b) => (b.current && b.fcRest > 0.05 ? b.fcRest : 0));   // case en cours : ce qui reste prévu
    const cons = buckets.map((b) => (b.forecast || b.cons == null || !Number.isFinite(b.cons) ? null : b.cons));
    const end = buckets.map((b, i) => (b.current && cons[i] != null && b.consEnd > cons[i] ? b.consEnd : null));   // projection de la case en cours
    const shown = cons.map((v, i) => (end[i] != null ? end[i] : v));
    const max = niceTop(Math.max(...tot.map((v, i) => v + rest[i]), ...shown.filter((v) => v != null), 0.1) * 1.06);
    const y = (v) => 4 + (1 - v / max) * (H - 4), cx = (i) => slot * i + slot / 2;
    const cols = buckets.map((b, i) => {
      const x = cx(i) - bw / 2, r = Math.min(4, bw / 3);
      if (b.forecast) return h`<g class="bar is-fc"><rect x="${x}" y="${y(tot[i])}" width="${bw}" height="${Math.max(0, H - y(tot[i]))}" rx="${r}"/></g>`;
      let base = 0;
      const segs = SER.map(([k, , tone]) => {
        const v = b[k] || 0; if (v <= 0) return "";
        const y1 = y(base + v), y0 = y(base); base += v;
        return h`<rect data-tone="${tone}" x="${x}" y="${y1}" width="${bw}" height="${Math.max(0, y0 - y1 - (base < tot[i] - 1e-6 ? 1.5 : 0))}" rx="${r}"/>`;
      });
      const cap = rest[i] ? h`<rect class="bi-rest" x="${x}" y="${y(tot[i] + rest[i])}" width="${bw}" height="${Math.max(0, y(tot[i]) - y(tot[i] + rest[i]) - 1.5)}" rx="${r}"/>` : "";
      return h`<g class="bar ${b.current ? "is-cur" : ""}">${cap}${segs}</g>`;
    });
    // Consommation : trait plein sur les cases terminées, pointillé vers la fin projetée de la case en cours
    const pts = shown.map((v, i) => (v == null ? null : [cx(i), y(v), i])).filter(Boolean);
    const lastIsProj = pts.length > 1 && end[pts[pts.length - 1][2]] != null;
    const xy = (p) => `${p[0]},${p[1]}`;
    const line = pts.length < 2 ? "" : lastIsProj
      ? h`${pts.length > 2 ? h`<path class="bi-cl" d="${mono(pts.slice(0, -1))}"/>` : ""}<path class="bi-cl is-part" d="M${xy(pts[pts.length - 2])} L${xy(pts[pts.length - 1])}"/>`
      : h`<path class="bi-cl" d="${mono(pts)}"/>`;
    const dots = pts.map(([px, py, i]) => (n <= 12 || end[i] != null ? h`<span class="bi-dot ${end[i] != null ? "is-proj" : ""}" style="--x:${pc(px, W)};--y:${pc(py, H)}"></span>` : ""));
    const curIdx = buckets.findIndex((b) => b.current);   // libellé du jour en cours en gras ; son voisin trop proche s'efface
    const axis = buckets.map((b, i) => ((i % every === 0 && (every === 1 || curIdx < 0 || Math.abs(i - curIdx) >= 3)) || b.current
      ? h`<span class="ax ${b.current ? "is-cur" : ""}" style="--x:${pc(cx(i), W)}">${esc(b.key)}</span>` : ""));
    REG.set(id, { type: "bars", kind: P.kind, year: P.year, n, slot, buckets, tot, rest, cons, end, y, cx, top: (i) => Math.max(tot[i] + rest[i], shown[i] || 0), marks: (i) => [null, shown[i]] });
    return shell(id, label,
      h`${gridLines(max, y)}<line class="bi-base" x1="0" x2="${W}" y1="${H - 0.5}" y2="${H - 0.5}"/><rect class="bi-hl" x="0" y="0" width="${slot}" height="${H}"/>${cols}${line}`,
      h`${yTicks(max, y)}${dots}`, axis);
  }

  function dayLines({ P, buckets: B, label }) {
    const id = `bi${++seq}`, n = B.length, slot = W / n, cx = (i) => slot * i + slot / 2;
    const idx = B.map((_, i) => i), past = idx.filter((i) => !B[i].future), fut = idx.filter((i) => B[i].future), last = past[past.length - 1];
    const prod = B.map((b) => b.prod || 0), cons = B.map((b) => (Number.isFinite(b.cons) ? b.cons : null));
    const max = niceTop(Math.max(...prod, ...cons.filter((v) => v != null), 0.1) * 1.1);
    const y = (v) => 4 + (1 - v / max) * (H - 4), pt = (i, v) => [cx(i), y(v)];
    const pP = past.map((i) => pt(i, prod[i])), fP = (last != null ? [last, ...fut] : fut).map((i) => pt(i, prod[i]));
    const cP = past.filter((i) => cons[i] != null).map((i) => pt(i, cons[i]));
    const area = pP.length > 1 ? h`<path class="bi-pa" d="${mono(pP)} L${pP[pP.length - 1][0]},${H} L${pP[0][0]},${H} Z"/><path class="bi-pl" d="${mono(pP)}"/>` : "";
    const segs = [];
    B.forEach((b) => { const s = segs[segs.length - 1]; if (s && s.k === b.tariff) s.n++; else segs.push({ k: b.tariff, n: 1 }); });
    const band = h`<div class="bi-band" aria-hidden="true">${segs.map((s) => h`<i data-tariff="${s.k}" style="--w:${pc(s.n, n)}"></i>`)}</div>`;
    const axis = B.map((b, i) => (i % 3 === 0 ? h`<span class="ax ${i === 0 ? "is-start" : ""}" style="--x:${pc(slot * i, W)}">${b.h}h</span>` : "")).concat(h`<span class="ax is-end" style="--x:100%">24h</span>`);
    const now = new Date(), t = now.getHours() + now.getMinutes() / 60;
    REG.set(id, { type: "lines", kind: "jour", n, slot, buckets: B, tot: prod, cons, y, cx, top: (i) => Math.max(prod[i], cons[i] || 0), marks: (i) => [prod[i], cons[i]] });
    return shell(id, label,
      h`${gridLines(max, y)}<line class="bi-base" x1="0" x2="${W}" y1="${H - 0.5}" y2="${H - 0.5}"/><rect class="bi-hl" x="0" y="0" width="${slot}" height="${H}"/>
        ${area}${fP.length > 1 && fut.length ? h`<path class="bi-fl" d="${mono(fP)}"/>` : ""}${cP.length > 1 ? h`<path class="bi-cl" d="${mono(cP)}"/>` : ""}
        ${P.live ? h`<line class="bi-now" x1="${slot * t}" x2="${slot * t}" y1="0" y2="${H}"/>` : ""}`,
      h`${yTicks(max, y)}${P.live ? h`<span class="bi-now-l" style="--x:${pc(slot * t, W)}">${fmt.time(now)}</span>` : ""}`, axis, band);
  }

  // Infobulle (souris, toucher, clavier) — écoutée une seule fois pour toute la vie de la page
  const tipEl = () => document.getElementById("tip");
  const row = (l, v, tone, cls = "", unit = " kWh", d = 1) => h`<div class="tip-r ${cls}">${tone ? h`<i data-tone="${tone}"></i>` : ""}<span>${l}</span><b>${fmt.n(v, d)}${unit}</b></div>`;
  let hover = null;
  function showTip(fig, i) {
    const c = REG.get(fig.dataset.bi); if (!c) return;
    i = BZ.clamp(i, 0, c.n - 1); fig.dataset.i = i; fig.classList.add("is-hover");
    fig.querySelectorAll(".bar").forEach((g, j) => g.classList.toggle("is-on", j === i));
    const hl = fig.querySelector(".bi-hl"); hl.setAttribute("x", c.slot * i); hl.classList.add("is-on");
    const b = c.buckets[i];
    c.marks(i).forEach((v, k) => {
      const dot = fig.querySelector(k ? ".bi-cur.is-c" : ".bi-cur.is-p");
      if (v == null) { dot.classList.remove("is-on"); return; }
      dot.style.setProperty("--x", pc(c.cx(i), W)); dot.style.setProperty("--y", pc(c.y(v), H)); dot.classList.add("is-on");
      dot.classList.toggle("is-fc", !!b.future);
    });
    let rows;
    if (c.type === "lines") {
      const T = BZ.TARIFS[b.tariff];
      rows = h`${row(b.future ? (b.fcEst ? "Prévision (selon tes 7 derniers jours)" : "Prévision") : "Production", c.tot[i], "solar", b.future ? "bi-tip-f" : "", " kWh", 2)}${c.cons[i] != null ? row("Consommation", c.cons[i], "neutral", "bi-tip-c", " kWh", 2) : ""}
        <div class="tip-r bi-tip-tar"><i data-tone="${b.tariff}"></i><span>${T.label}</span><b>${fmt.n(T.price(), 4)} €/kWh</b></div>`;
    } else if (b.forecast) rows = c.tot[i] > 0 ? row("Production prévue", c.tot[i], "solar", "bi-tip-f") : h`<div class="tip-r bi-tip-n"><span>Pas de prévision</span></div>`;   // HA : rien d'inventé
    else if (b.pre) rows = h`<div class="tip-r bi-tip-n"><span>Panneaux pas encore posés</span></div>${row("Consommation", BZ.hist ? c.cons[i] ?? NaN : c.cons[i] || 0, "neutral", "bi-tip-c")}`;
    else rows = h`${SER.map(([k, l, tone]) => row(l, b[k] || 0, tone))}${row("Production", c.tot[i], null, "bi-tip-t")}${c.rest[i] ? row("Encore prévu", c.rest[i], "solar", "bi-tip-f") : ""}
      ${c.cons[i] != null ? row(b.current ? b.consLbl : "Consommation", c.cons[i], "neutral", "bi-tip-c") : ""}${c.end[i] != null ? row(b.projLbl, c.end[i], null, "bi-tip-p") : ""}`;
    const t = tipEl();
    t.innerHTML = h`<strong>${esc(tipName(c, b, i))}${b.current ? " · en cours" : ""}</strong>${rows}`;
    t.classList.add("is-on");
    const r = fig.querySelector(".bi-plot").getBoundingClientRect(), tw = t.offsetWidth, th = t.offsetHeight;
    const xPx = r.left + (c.cx(i) / W) * r.width, yPx = r.top + (c.y(c.top(i)) / H) * r.height;
    const left = BZ.clamp(xPx - tw / 2, 8, innerWidth - tw - 8);
    let top = yPx - th - 14; if (top < 8) top = Math.min(innerHeight - th - 8, yPx + 18);
    t.style.transform = `translate(${left}px, ${top}px)`;
  }
  function hideTip(fig, keepTip) {
    if (!keepTip) tipEl().classList.remove("is-on");
    if (!fig) return;
    fig.classList.remove("is-hover");
    fig.querySelectorAll(".bar.is-on, .bi-hl.is-on, .bi-cur.is-on").forEach((e) => e.classList.remove("is-on"));
  }
  document.addEventListener("pointermove", (e) => {
    const fig = e.target.closest && e.target.closest(".bi-chart");
    if (hover && hover !== fig) { hideTip(hover, !!(e.target.closest && e.target.closest(".chart"))); hover = null; }
    if (!fig) return;
    const c = REG.get(fig.dataset.bi); if (!c) return;
    const r = fig.querySelector(".bi-plot").getBoundingClientRect();
    hover = fig; showTip(fig, Math.floor(((e.clientX - r.left) / r.width) * c.n));
  }, { passive: true });
  document.addEventListener("pointerleave", () => { if (hover) { hideTip(hover); hover = null; } });
  document.addEventListener("scroll", () => { if (hover) { hideTip(hover); hover = null; } }, { passive: true, capture: true });
  document.addEventListener("keydown", (e) => {
    const fig = document.activeElement && document.activeElement.closest && document.activeElement.closest(".bi-chart");
    if (!fig || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
    const c = REG.get(fig.dataset.bi); if (!c) return;
    e.preventDefault();
    const cur = fig.dataset.i != null ? +fig.dataset.i : c.n - 1;
    showTip(fig, e.key === "Home" ? 0 : e.key === "End" ? c.n - 1 : cur + (e.key === "ArrowLeft" ? -1 : 1));
  });
  document.addEventListener("focusout", (e) => { if (e.target.classList && e.target.classList.contains("bi-chart")) hideTip(e.target); });

  // Légende : pastille (barre), aire, trait (courbe), tirets (prévision), hachures
  const legendRow = (items) => h`<ul class="bi-lg">${items.map(([label, tone, kind, v]) => h`<li data-tone="${tone}"><i class="bi-sw is-${kind}"></i><span>${label}</span>${v ? h`<b>${v}</b>` : ""}</li>`)}</ul>`;

  /* ─── Export CSV de la période (séparateur « ; » et virgule décimale, comme Excel en français) ─── */
  const SAVE_AS = ["down", "load"].join("");   // attribut du lien d'export (absent de la version hébergée)
  function csvHref(P) {
    const n = (v) => (v == null || !Number.isFinite(v) ? "" : v.toFixed(2).replace(".", ","));
    let rows;
    if (P.kind === "jour") rows = [["Heure", "Production (kWh)", "Consommation (kWh)", "Tarif"], ...P.buckets.filter((b) => !b.future).map((b) => [`${b.h}h`, n(b.prod), n(b.cons), BZ.TARIFS[b.tariff].short])];
    else rows = [[P.kind === "annee" ? "Mois" : "Jour", "Production (kWh)", "Utilisé à la maison", "Stocké en batterie", "Revendu", "Consommation (kWh)", "Achat réseau", "dont HP", "dont HC", "dont HSC", "Économies (€)"],
      ...P.buckets.filter((b) => !b.forecast).map((b, i) => [P.kind === "annee" ? `${BZ.MONTHS_LONG[i]} ${P.year}` : b.date.toLocaleDateString("fr-FR"), n(b.prod), n(b.self), n(b.chg), n(b.exp), n(b.cons), n(b.imp), n(b.hp), n(b.hc), n(b.hsc), n(b.savings)])];
    return `data:text/csv;charset=utf-8,${encodeURIComponent("﻿" + rows.map((r) => r.join(";")).join("\r\n"))}`;
  }

  // Même gabarit que BZ.card, pour une icône qui n'est pas dans le jeu commun
  const cardSvg = ({ cls, title, svg, tone = "accent", aside, body }) => h`<section class="card ${cls}">
      <header class="card-h"><span class="card-i" data-tone="${tone}">${svg}</span><div class="card-t"><h3>${title}</h3></div>${aside ? h`<div class="card-a">${aside}</div>` : ""}</header>
      ${body}</section>`;

  /* ─── Blocs de la page ────────────────────────────────────────────── */
  function header(P, L, wait = false) {
    const id = P.kind === "annee" ? String(P.year) : P.kind === "mois" ? iso(P.first).slice(0, 7) : iso(P.kind === "jour" ? P.date : P.to);
    const nav = (dir) => {
      const to = P.off + dir, ok = dir < 0 ? to >= P.min : to <= 0;
      return h`<button type="button" class="bi-nav" data-act="set" data-k="biOff" data-value="${P.kind}:${to}" aria-label="${dir < 0 ? "Période précédente" : "Période suivante"}" ${ok ? "" : "disabled"}>${icon(dir < 0 ? "left" : "chevron")}</button>`;
    };
    return h`<header class="ph">
      <div><p class="ph-hi">Historique</p><h1>Bilan</h1><p class="ph-sub" aria-live="polite">${L.title} · ${L.compare}${L.gaps || ""}</p></div>
      <div class="ph-a">
        <div class="bi-per" role="group" aria-label="Période du bilan">${icon("calendar")}${pills({ name: "period", label: "Durée", value: P.kind, options: [["jour", "Jour"], ["semaine", "7 jours"], ["mois", "Mois"], ["annee", "Année"]] })}
          <span class="bi-sep" aria-hidden="true"></span>${nav(-1)}${nav(1)}</div>
        ${wait || document.documentElement.dataset.hosted ? "" : h`<a class="btn btn-primary bi-exp" href="${csvHref(P)}" ${SAVE_AS}="breezy-bilan-${P.kind}-${id}.csv" aria-label="Exporter le bilan de la période en CSV">${DL}<span>Exporter</span></a>`}
      </div></header>`;
  }

  // Mini-courbes : les cases de la période. Jour : heures écoulées (autosuffisance cumulée depuis 0 h, économies par heure).
  // Année : moyenne par jour de chaque mois, pour que le mois en cours ne « s'effondre » pas.
  // Home Assistant : autosuffisance cumulée et économies de chaque heure, lues dans l'historique (rien de réparti)
  const realHourly = (B) => {
    let si = 0, sc = 0;
    return {
      aut: B.map((b) => { if (Number.isFinite(b.imp) && Number.isFinite(b.cons)) { si += b.imp; sc += b.cons; } return sc > 0 ? BZ.clamp(1 - si / sc, 0, 1) : null; }),
      eco: B.map((b) => (Number.isFinite(b.savings) ? b.savings : null)),
    };
  };
  function sparks(P, T) {
    if (P.kind === "jour") {
      const B = P.buckets.filter((b) => !b.future), A = BZ.hist ? realHourly(B) : hourly(B, T);
      return { prod: B.map((b) => b.prod), cons: B.map((b) => b.cons), aut: A.aut, eco: A.eco };
    }
    const real = P.buckets.filter((b) => !b.forecast && !b.pre), per = (b) => (P.kind === "annee" ? b.days || 1 : 1);
    return { prod: real.map((b) => b.prod / per(b)), cons: real.map((b) => b.cons / per(b)), aut: real.map(aut), eco: real.map((b) => b.savings / per(b)) };
  }

  function kpis(P, T, Q, L) {
    const S = sparks(P, T), sp = (vals, tone) => (vals.filter((v) => v != null).length > 1 ? BZ.spark(vals, tone) : null);
    const Tc = P.cmpTotal || T;   // Home Assistant : la part de la période comparable (démo : la période entière)
    const vs = (d) => (d || !L.none ? L.vs : "rien à comparer");
    const k = [
      { label: "Produit", ic: "sun", tone: "solar", value: val(fmt.kwh(T.prod)), delta: dl(Tc.prod, Q.prod), spark: sp(S.prod, "solar") },
      { label: "Consommé", ic: "home", tone: "battery", value: val(fmt.kwh(T.cons)), delta: dl(Tc.cons, Q.cons, { invert: true }), spark: sp(S.cons, "battery") },
      { label: "Autosuffisance", ic: "leaf", tone: "good", value: val([fmt.n(aut(T) * 100), "%"]), delta: L.none ? "" : dl(aut(Tc), aut(Q), { unit: "pts" }), spark: sp(S.aut, "good") },
      { label: "Économisé", ic: "euro", tone: "accent", value: val([fmt.n(T.savings, T.savings >= 100 ? 0 : 2), "€"]), delta: dl(Tc.savings, Q.savings), spark: sp(S.eco, "accent"), est: T.est, estHp: T.estHp },
    ];
    // Home Assistant sans statistique d'économies : calculées avec les tarifs, et dit comme tel
    return h`<div class="kpis bi-kpis">${k.map((x) => kpi({ ...x, vs: x.est ? (x.estHp ? "estimé au prix des heures pleines" : "estimé avec tes tarifs") : vs(x.delta) }))}</div>`;
  }

  function chartCard(P, T) {
    if (P.kind === "jour") {
      const fc = P.buckets.reduce((a, b) => a + (b.future ? b.prod : 0), 0);
      const key = h`<div class="tariff-key bi-tk">${TAR.map((k) => h`<span data-tariff="${k}"><i></i>${BZ.TARIFS[k].short} <em>${BZ.rangeLabel(k)}</em> <b>${fmt.n(BZ.TARIFS[k].price(), 4)} €</b></span>`)}</div>`;
      return card({ cls: "bi-main is-day", title: P.live ? "Ta journée heure par heure" : "La journée heure par heure", ic: "chart", tone: "accent",
        aside: legendRow([["Production", "solar", "area", fmt.kwhText(T.prod)], ...(fc > 0.05 ? [["Prévision", "solar", "dash", `+${fmt.kwhText(fc)}`]] : []), ["Consommation", "neutral", "line", fmt.kwhText(T.cons)]]),
        body: h`<div class="bi-chart-w">${dayLines({ P, buckets: P.buckets, label: "Production, prévision et consommation par heure, tarifs sous l'axe" })}</div>${key}` });
    }
    const every = P.buckets.length > 14 ? 5 : 1;
    // Case en cours : la production encore attendue (et, en vue Année, les jours restants du mois) ;
    // la consommation est projetée à la fin de la case, au rythme habituel des heures et des jours qui restent
    let restToday = 0, restMonth = 0;
    if (P.live) {
      restToday = (BZ.hist ? BZ.hours() : todayHours()).reduce((a, b) => a + (b.future ? b.prod || 0 : 0), 0);
      if (P.kind === "annee") restMonth = BZ.period("mois").buckets.reduce((a, b) => a + (b.forecast ? b.prod : 0), 0);
    }
    const uShare = Math.max(0.05, share(USE, P.H)), t = fmt.time(new Date());
    const buckets = P.buckets.map((b) => {
      if (!b.current) return b;
      const yr = P.kind === "annee";
      return { ...b, fcRest: restToday + restMonth, consEnd: yr ? (b.cons / (b.days || 1)) * daysIn(D12(P.year, b.i, 1)) : b.cons / uShare,
        consLbl: yr ? `Consommé au ${sh(new Date())}` : `Consommé à ${t}`, projLbl: yr ? "Projection fin de mois" : "Projection fin de journée" };
    });
    const hasFc = buckets.some((b) => (b.forecast && b.prod > 0) || b.fcRest > 0.05);
    return card({ cls: "bi-main", title: P.kind === "annee" ? "Production et consommation" : "Où va ta production", ic: "chart", tone: "accent",
      aside: legendRow([
        ["Utilisé", "solar", "bar", fmt.kwhText(T.self)], ["Stocké", "battery", "bar", fmt.kwhText(T.chg)], ["Revendu", "grid", "bar", fmt.kwhText(T.exp)],
        ["Consommation", "neutral", "line", ""], ...(hasFc ? [["Prévision", "solar", "hatch", ""]] : []),
      ]),
      body: h`<div class="bi-chart-w">${combo({ P, buckets, every, label: `Destination de la production par ${labels(P).unit} et consommation` })}</div>` });
  }

  // Comparaison : uniquement ce que les 4 indicateurs du haut ne montrent pas déjà
  function compareCard(T, Q, L) {
    const rows = [
      { ic: "grid", tone: "neutral", name: "Achat réseau", cur: fmt.kwhText(T.imp), prev: fmt.kwhText(Q.imp), d: dl(T.imp, Q.imp, { invert: true }) },
      { ic: "euro", tone: "hp", name: "Facture réseau", cur: fmt.eur(bill(T)), prev: fmt.eur(bill(Q)), d: dl(bill(T), bill(Q), { invert: true }) },
      { raw: UP, tone: "grid", name: "Revendu", cur: fmt.kwhText(T.exp), prev: fmt.kwhText(Q.exp), d: dl(T.exp, Q.exp) },
      { ic: "battery", tone: "battery", name: "Batterie restituée", cur: fmt.kwhText(T.dch), prev: fmt.kwhText(Q.dch), d: dl(T.dch, Q.dch) },
      { ic: "sun", tone: "solar", name: "Autoconsommation", cur: fmt.pct(selfUse(T)), prev: L.none ? "—" : fmt.pct(selfUse(Q)), d: L.none ? "" : dl(selfUse(T), selfUse(Q), { unit: "pts" }) },
    ];
    return cardSvg({ cls: "bi-cmp", title: "Comparaison", svg: CMP, aside: h`<span class="bi-note">${L.vs}</span>`, body: h`
      <div class="dt-wrap"><table class="dt">
        <thead><tr><th scope="col">Indicateur</th><th scope="col">${L.cur}</th><th scope="col">${L.prev}</th><th scope="col">Écart</th></tr></thead>
        <tbody>${rows.map((r) => h`<tr>
          <td><div class="dt-main"><span class="dt-ic" data-tone="${r.tone}">${r.raw || icon(r.ic)}</span><strong>${r.name}</strong></div></td>
          <td class="dt-v">${r.cur}</td><td class="bi-prev">${r.prev}</td><td>${r.d || h`<span class="delta">—</span>`}</td></tr>`)}</tbody></table></div>` });
  }

  function bestCard(P, L) {
    const isDay = P.kind === "jour";
    const real = P.buckets.map((b, i) => ({ b, i })).filter(({ b }) => !b.forecast && !b.future && b.prod > 0.05);
    const avg = real.reduce((a, x) => a + x.b.prod, 0) / (real.length || 1);
    const best = [...real].sort((a, z) => z.b.prod - a.b.prod).slice(0, 5);
    const body = best.length ? h`<ol class="plist bi-best">${best.map(({ b, i }, r) => {
      const vs = (b.prod / avg - 1) * 100, a = fmt.n(aut(b) * 100);
      const sub = isDay ? h`<span class="bi-ln">${BZ.TARIFS[b.tariff].label}</span><span class="bi-sn">${BZ.TARIFS[b.tariff].short}</span>${b.cons != null ? h`<span class="bi-sx"> · ${fmt.kwhText(b.cons)} conso.</span>` : ""}`
        : h`<span class="bi-al">${a} % autonome</span><span class="bi-as">${a} % auto.</span><span class="bi-sx"> · ${fmt.kwhText(b.exp)} revendus</span>`;
      return h`<li><div class="plist-r">
        <span class="bi-rk ${r === 0 ? "is-1" : ""}"><span class="sr">Rang </span>${r + 1}</span>
        <span><strong><span class="bi-ln">${nameOf(P, b, i)}</span><span class="bi-sn" aria-hidden="true">${shortOf(P, b, i)}</span>${b.current ? h` <em class="bi-now">en cours</em>` : ""}</strong><small>${sub}</small></span>
        ${pill(vs >= 0.5 ? `+${fmt.n(vs)} %` : "moyenne", vs >= 0.5 ? "good" : "neutral")}
        <span class="plist-p"><span>${fmt.kwhText(b.prod)}</span>${meter({ value: (b.prod / best[0].b.prod) * 100, tone: "solar", size: "xs" })}</span></div></li>`;
    })}</ol>`
      : BZ.empty({ ic: "sun", title: P.kind === "jour" && P.live ? "Pas encore de production" : "Pas de production", text: P.live ? "Le classement se remplit dès le lever du soleil." : "Les panneaux n'étaient pas encore posés." });
    return card({ cls: "bi-top", title: "Meilleurs moments", ic: "star", tone: "accent", aside: h`<span class="bi-note">${L.per}${best.length ? h`<span class="bi-nx"> · moy. ${fmt.kwhText(avg)}</span>` : ""}</span>`, body });
  }

  function originCard(T) {
    // Réseau en gris : le vert reste réservé à ce qui est revendu
    const parts = [{ label: "Soleil direct", v: T.self, tone: "solar" }, { label: "Batterie", v: T.dch, tone: "battery" }, { label: "Réseau", v: T.imp, tone: "neutral" }];
    const cons = parts.reduce((a, p) => a + p.v, 0) || 1;
    const tar = TAR.map((k) => ({ k, label: BZ.TARIFS[k].label, v: T[k] || 0, eur: (T[k] || 0) * BZ.TARIFS[k].price() }));
    const wait = BZ.hist && !Number.isFinite(T.hp);   // Home Assistant : achat par tarif pas encore lu (heures du mois)
    return card({ cls: "bi-org", title: "D'où vient ta consommation", ic: "leaf", tone: "accent", link: { label: "Tarifs", to: "energy" }, body: h`
      <div class="bi-mixr">${donut({ parts, size: 128, stroke: 15, center: fmt.n(T.cons, T.cons < 100 ? 1 : 0), sub: "kWh", label: `${fmt.kwhText(T.cons)} consommés : ${parts.map((p) => `${p.label} ${Number.isFinite(p.v) ? Math.round((p.v / cons) * 100) : "—"} %`).join(", ")}` })}
        <ul class="bi-keys">${parts.map((p) => h`<li data-tone="${p.tone}"><i></i><span>${p.label}</span><em>${fmt.n((p.v / cons) * 100)} %</em><b>${fmt.kwhText(p.v)}</b></li>`)}</ul></div>
      <div class="bi-tar">
        <div class="bi-tar-h"><strong>Réseau par tarif</strong><span><b>${fmt.eur(bill(T))}</b> payés</span></div>
        ${wait ? h`<p class="ha-hint">${T.splitLoading ? "Répartition par tarif en cours de chargement…" : "Répartition par tarif indisponible pour le moment."}</p>` : BZ.split(tar.map((t) => ({ label: t.label, v: t.v, tone: t.k })), { label: `Achat réseau par tarif : ${tar.map((t) => `${t.label} ${fmt.kwhText(t.v)}`).join(", ")}` })}
        ${wait ? "" : h`<ul class="bi-tl">${tar.map((t) => h`<li data-tone="${t.k}"><i></i><span>${t.label}<em>${BZ.rangeLabel(t.k)}</em></span><span class="bi-tl-k">${fmt.kwhText(t.v)}</span><b>${fmt.eur(t.eur, 2)}</b></li>`)}</ul>`}
      </div>` });
  }

  // Rentabilité : compteur cumulé (BZ.roi), rythme des 12 derniers mois, date d'amortissement à ce rythme
  function roiData() {
    const R = BZ.roi(), now = new Date(), y = now.getFullYear(), HB = BZ.hist;
    if (HB) {
      // Home Assistant : économies des 365 derniers jours et depuis le 1er janvier (statistiques) ;
      // tant qu'elles manquent, le rythme moyen depuis la mise en service (compteur cumulé)
      // Économies des 365 derniers jours, sur les seuls jours connus (pics écartés) ; moins d'un an connu : ramenées à l'année ;
      // presque rien de connu : le rythme moyen depuis la mise en service (compteur cumulé)
      const W = HB.savingsWindow("365d"), Y = HB.savingsWindow("ytd"), ok = Number.isFinite(W.v) && W.days >= 28;
      const perYear = !ok ? R.perYear : W.days >= 365 ? W.v : (W.v * 365) / W.days;
      const payback = new Date(now.getTime() + (R.remaining / (perYear || 1)) * 365.25 * 864e5);
      const mo = ok && W.days < 365 ? Math.max(1, Math.round(W.days / 30.44)) : 0;
      return { ...R, perYear, ytd: Y.v, ytdFrom: Y.full === false && Y.from ? new Date(`${Y.from}T12:00:00`) : null, payback, totalYears: (payback - R.start) / (365.25 * 864e5),
        avg: !ok, perLabel: !ok ? "Par an (moy.)" : mo ? `Par an (sur ${mo} mois)` : "Sur 12 mois" };
    }
    const year = sum(span(D12(y - 1, now.getMonth(), now.getDate() + 1), 365).map(dayX)).savings;
    const months = (now - START) / (30.44 * 864e5);
    const perYear = months < 12 ? (year * 12) / Math.max(1, months) : year;     // moins d'un an de recul : ramené à l'année
    const ytd = sum(span(D12(y, 0, 1), Math.round((sod(now) - new Date(y, 0, 1)) / 864e5) + 1).map(dayX)).savings;
    const payback = new Date(now.getTime() + (R.remaining / (perYear || 1)) * 365.25 * 864e5);
    return { ...R, perYear, ytd, payback, totalYears: (payback - START) / (365.25 * 864e5) };
  }
  BZ.roiFull = roiData;   // partagé avec l'Aperçu : même date d'amortissement partout
  function roiCard(P) {
    const R = roiData(), y = new Date().getFullYear();
    // En vue « Année » en cours, l'économie de l'année est déjà dans les indicateurs : on montre la durée d'amortissement
    const first = P.kind === "annee" && P.live ? ["Amortie en", `${fmt.n(R.totalYears, 1)} ans`] : [R.ytdFrom ? `Dès le ${sh(R.ytdFrom)}` : `En ${y}`, fmt.eur(R.ytd, 0)];
    return card({ cls: "bi-roi", title: "Rentabilité solaire", ic: "sun", tone: "accent", aside: pill(h`${fmt.n(R.progress * 100)} %<span class="bi-rx"> remboursé</span>`, "accent"), body: h`
      <div class="bi-roi-v">${val([fmt.n(R.total), "€"], "bi-roi-big")}<span>économisés sur ${fmt.eur(R.inv, 0)} investis</span></div>
      <div class="bi-roi-m">${meter({ value: R.progress * 100, tone: "accent", size: "lg", label: "Part de l'installation remboursée" })}
        <div class="bi-roi-ax"><span class="bi-roi-from">Depuis ${fmt.date(R.start, { month: "short", year: "numeric" })}</span><span>Amortie vers <b>${fmt.date(R.payback, { month: "long", year: "numeric" })}</b></span></div></div>
      <div class="bi-roi-kv">
        <div><span>${first[0]}</span><b>${first[1]}</b></div>
        <div><span>${R.perLabel || (R.avg ? "Par an (moy.)" : "Sur 12 mois")}</span><b>${fmt.eur(R.perYear, 0)}</b></div>
        <div><span>Reste</span><b>${fmt.eur(R.remaining, 0)}</b></div>
      </div>` });
  }

  // Home Assistant : historique absent, en échec ou en chargement → on le dit à la place des graphiques (jamais de NaN dessiné)
  function waitState(T, Q) {
    const HB = BZ.hist; if (!HB) return null;
    if (HB.has("energie") === false) return { title: "Historique indisponible", text: "Un compteur d'énergie n'a pas de statistiques dans Home Assistant. Ouvre le diagnostic pour savoir lequel.",
      action: btn({ label: "Diagnostic", ic: "alert", act: "open-sheet", args: { sheet: "diag" }, size: "sm" }) };
    if (T.error || Q.error) return { title: "Home Assistant n'a pas répondu", text: "Réessaie dans un instant.", action: btn({ label: "Réessayer", ic: "refresh", act: "hist-retry", size: "sm" }) };
    if (T.loading || Q.loading) return { title: "Chargement de l'historique", text: "Les statistiques de Home Assistant arrivent…" };
    return null;
  }
  function waitCards(P, w) {
    return h`<div class="layout bi-grid bi-wait">
      <div class="col bi-l">${card({ cls: "bi-main", title: "Où va ta production", ic: "chart", tone: "accent", body: BZ.empty({ ic: "chart", ...w }) })}</div>
      <div class="col bi-r">${card({ cls: "bi-org", title: "D'où vient ta consommation", ic: "leaf", tone: "accent", body: BZ.empty({ ic: "leaf", title: w.title, text: "La répartition s'affichera avec l'historique." }) })}${roiCard(P)}</div>
    </div>`;
  }

  BZ.pages.insights = () => {
    REG.clear();
    F = BZ.hist ? 1 : rescale();   // recalage des économies : démo seulement
    const kind = ["jour", "semaine", "mois", "annee"].includes(BZ.ui.period) ? BZ.ui.period : "semaine";
    const [k, n] = String(BZ.ui.biOff || "").split(":");
    const off = k === kind ? BZ.clamp(Math.round(+n) || 0, minOff(kind), 0) : 0;
    const P = build(kind, off), T = P.total, Q = P.prevTotal, L = labels(P);
    const w = waitState(T, Q);
    if (w) return h`${header(P, L, true)}${waitCards(P, w)}`;
    return h`${header(P, L)}${kpis(P, T, Q, L)}
      <div class="layout bi-grid">
        <div class="col bi-l">${chartCard(P, T)}<div class="bi-pair">${compareCard(P.cmpTotal || T, Q, L)}${bestCard(P, L)}</div></div>
        <div class="col bi-r">${originCard(T)}${roiCard(P)}</div>
      </div>`;
  };
})();
;
// ═══ v3/js/pages/vehicle.js
// Voiture (V3) : Kia e-Niro.
// Hero inspiré des applis constructeurs (Tesla, Rivian, Volvo, evcc) : la voiture « posée » sur une seule
// barre de batterie (violet foncé = au branchement, violet = ajouté), repère du niveau actuel et drapeau de
// limite, déroulé de la charge, pupitre de quatre commandes à distance. Puis les recharges de la période et les réglages.
// Chaque information n'apparaît qu'une fois sur la page.
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, val, card, kpi, pills, delta, btn, toggle, stepper, meter, C, num, st, isOn, esc, clamp } = BZ;

  /* ─── Voiture en vue de profil : Kia Niro EV (SG2) Snow White Pearl, montant C « aero » Aurora Black ──
     Illustration vectorielle en ligne (aucune image externe, identifiants préfixés en-), tournée vers la
     droite et lisible sur fond clair comme sombre. La prise de la Niro est au centre du nez : le câble part
     donc du nez vers la borne murale. .ve-plug (borne, câble, trappe ouverte, fiche) n'existe que branchée,
     .ve-flow (le flux animé, de la borne vers la voiture) seulement en charge. */
  const CAR_ART = `
    <defs>
    <linearGradient id="en-paint" gradientUnits="userSpaceOnUse" x1="0" y1="15" x2="0" y2="178">
    <stop offset="0" stop-color="#ffffff"/><stop offset=".37" stop-color="#f1f4f7"/><stop offset=".42" stop-color="#ffffff"/>
    <stop offset=".48" stop-color="#fbfcfd"/><stop offset=".5" stop-color="#e4e8ed"/><stop offset=".62" stop-color="#f7f9fa"/>
    <stop offset=".64" stop-color="#d8dde4"/><stop offset=".76" stop-color="#eef1f4"/><stop offset=".9" stop-color="#d3d8df"/>
    <stop offset="1" stop-color="#b3bac5"/></linearGradient>
    <linearGradient id="en-chan" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3e7ec"/><stop offset="1" stop-color="#9aa3ae"/></linearGradient>
    <linearGradient id="en-wrap" gradientUnits="userSpaceOnUse" x1="22" y1="0" x2="543" y2="0">
    <stop offset="0" stop-color="#1f2a3a" stop-opacity=".24"/><stop offset=".05" stop-color="#1f2a3a" stop-opacity="0"/>
    <stop offset=".925" stop-color="#1f2a3a" stop-opacity="0"/><stop offset="1" stop-color="#1f2a3a" stop-opacity=".22"/></linearGradient>
    <linearGradient id="en-glass" gradientUnits="userSpaceOnUse" x1="0" y1="26" x2="0" y2="80">
    <stop offset="0" stop-color="#5b6f87"/><stop offset=".3" stop-color="#2d3a4a"/><stop offset="1" stop-color="#10161d"/></linearGradient>
    <radialGradient id="en-sheen" gradientUnits="userSpaceOnUse" cx="128" cy="24" r="96"><stop offset="0" stop-color="#ffffff" stop-opacity=".2"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>
    <linearGradient id="en-refl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset=".5" stop-color="#ffffff"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>
    <linearGradient id="en-blade" gradientUnits="userSpaceOnUse" x1="150" y1="20" x2="36" y2="100">
    <stop offset="0" stop-color="#3f4650"/><stop offset=".42" stop-color="#1b1e23"/><stop offset="1" stop-color="#0a0b0d"/></linearGradient>
    <linearGradient id="en-mir" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a636e"/><stop offset=".32" stop-color="#1e2126"/><stop offset="1" stop-color="#08090b"/></linearGradient>
    <linearGradient id="en-clad" gradientUnits="userSpaceOnUse" x1="0" y1="105" x2="0" y2="177">
    <stop offset="0" stop-color="#363a41"/><stop offset=".6" stop-color="#212429"/><stop offset="1" stop-color="#121417"/></linearGradient>
    <radialGradient id="en-arch" cx=".5" cy=".12" r=".95"><stop offset="0" stop-color="#020203"/><stop offset="1" stop-color="#1d2025"/></radialGradient>
    <radialGradient id="en-tyre"><stop offset=".64" stop-color="#1e2024"/><stop offset=".97" stop-color="#191b1e"/><stop offset="1" stop-color="#0c0d0f"/></radialGradient>
    <linearGradient id="en-side" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a3e45"/><stop offset=".5" stop-color="#25282d"/><stop offset="1" stop-color="#2c3036"/></linearGradient>
    <linearGradient id="en-tyrerim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#737a85"/><stop offset=".42" stop-color="#3a3e45" stop-opacity="0"/></linearGradient>
    <linearGradient id="en-lip" x1=".2" y1="0" x2=".8" y2="1"><stop offset="0" stop-color="#f3f5f8"/><stop offset=".5" stop-color="#b6bcc5"/><stop offset="1" stop-color="#6a717b"/></linearGradient>
    <radialGradient id="en-disc"><stop offset=".56" stop-color="#555b63"/><stop offset=".8" stop-color="#8a919a"/><stop offset=".93" stop-color="#9aa1a9"/><stop offset="1" stop-color="#4a4f57"/></radialGradient>
    <linearGradient id="en-ins" gradientUnits="userSpaceOnUse" x1="-20" y1="-20" x2="20" y2="20"><stop offset="0" stop-color="#4a5058"/><stop offset="1" stop-color="#2e3238"/></linearGradient>
    <linearGradient id="en-spoke" x1=".1" y1="0" x2=".9" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".5" stop-color="#d3d8de"/><stop offset="1" stop-color="#8d949e"/></linearGradient>
    <linearGradient id="en-lamp" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34404d"/><stop offset="1" stop-color="#0d1115"/></linearGradient>
    <radialGradient id="en-lens" cx=".4" cy=".35" r=".6"><stop offset="0" stop-color="#ffffff"/><stop offset=".45" stop-color="#bcd9f2"/><stop offset="1" stop-color="#2d3f52"/></radialGradient>
    <linearGradient id="en-wshade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity=".55"/><stop offset=".28" stop-color="#000" stop-opacity="0"/></linearGradient>
    <linearGradient id="en-box" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#cdd2d9"/></linearGradient>
    <linearGradient id="en-boxglass" x1="0" y1="0" x2=".6" y2="1"><stop offset="0" stop-color="#3a424d"/><stop offset=".5" stop-color="#1b2027"/><stop offset="1" stop-color="#101318"/></linearGradient>
    <linearGradient id="en-plug" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a616b"/><stop offset=".45" stop-color="#30343b"/><stop offset="1" stop-color="#16181c"/></linearGradient>
    <linearGradient id="en-conduit" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b8bfc8" stop-opacity="0"/><stop offset="1" stop-color="#b8bfc8" stop-opacity=".9"/></linearGradient>
    <linearGradient id="en-ground" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="640" y2="0"><stop offset="0" stop-color="#8a93a0" stop-opacity="0"/><stop offset=".3" stop-color="#8a93a0" stop-opacity=".3"/><stop offset=".8" stop-color="#8a93a0" stop-opacity=".3"/><stop offset="1" stop-color="#8a93a0" stop-opacity="0"/></linearGradient>
    <clipPath id="en-bodyclip"><path d="M57.6,26.2 C86,22.6 165,18.8 250,16.6 C290,16.3 318,17.4 336,21.2 C362,37.5 392,60.5 409,73.2 C413,74.8 418,75.5 424,76.1 C460,79.8 498,85.4 520,89 C529,90.4 535,92.8 538,96.2 C540.4,99.6 541.2,105 541.6,112 C542.2,124 542.6,132 542.2,141 C541.8,151 539.4,160 534.4,166.6 C531.4,170.4 527.4,172 520,172.6 L486,176.4 C486,141 465,112 437,112 C409,112 388,141 388,176.4 L168,176.4 C168,141 147,112 119,112 C91,112 70,141 70,176.4 L46,172.4 C36,171 30.8,168 28,163.5 C24.6,158 22.8,148 22.6,134 C22.5,124 23.6,112 26.2,100.6 C31.6,81.4 39.4,58.6 46.4,39.4 C46.3,37.2 45.4,35.4 44,34 L43.9,33.2 C46.6,29.6 51,27 57.6,26.2Z"/></clipPath>
    <filter id="en-soft" x="-10%" y="-200%" width="120%" height="500%"><feGaussianBlur stdDeviation="3.2"/></filter>
    <filter id="en-blur1" x="-20%" y="-200%" width="140%" height="500%"><feGaussianBlur stdDeviation="1.1"/></filter>
    <filter id="en-glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.3"/></filter>
    <filter id="en-blur2" x="-20%" y="-100%" width="140%" height="300%"><feGaussianBlur stdDeviation="2.2"/></filter>
    <filter id="en-boxsh" x="-30%" y="-20%" width="160%" height="150%"><feDropShadow dx="0" dy="1.5" stdDeviation="1.6" flood-color="#0b1220" flood-opacity=".28"/></filter>
    <clipPath id="en-bladeclip"><path d="M151,20 C108.4,21.9 74.3,24.1 57.6,26.2 C51,27 46.6,29.6 43.9,33.2 L44,34 C45.4,35.4 46.3,37.2 46.4,39.4 C39.4,58.6 31.6,81.4 26.2,100.6 C60,96.2 100,88 132.6,81 C137,62 143,42 151,20Z"/></clipPath>
    <g id="en-tyreg">
    <circle r="39" fill="url(#en-tyre)"/>
    <circle r="34.6" fill="none" stroke="url(#en-side)" stroke-width="6"/>
    <circle r="33.4" fill="none" stroke="#4a4f57" stroke-width=".6" stroke-dasharray="9 3 2.5 3 14 4 3 3" opacity=".45"/>
    <circle r="38.5" fill="none" stroke="#3a3f47" stroke-width=".9"/>
    <circle r="38.3" fill="none" stroke="url(#en-tyrerim)" stroke-width="1.3"/>
    <circle r="27.5" fill="#060708"/>
    <circle r="26.5" fill="url(#en-lip)"/>
    <circle r="25.9" fill="none" stroke="#e6e9ee" stroke-width=".6"/>
    <circle r="25.1" fill="#0b0c0f"/>
    <circle r="19.6" fill="url(#en-disc)"/>
    <circle r="17" fill="none" stroke="#2c3036" stroke-width=".5" stroke-dasharray="1 2.2" opacity=".9"/>
    <circle r="11" fill="#2a2e34"/>
    <path d="M-20.8,-6A21.6,21.6 0 0 1 -9.5,-19.4L-6,-12.2A13.6,13.6 0 0 0 -13.1,-3.7Z" fill="#24282e" stroke="#59606a" stroke-width=".4"/>
    </g>
    <g id="en-face">
    <path d="M5.7,-23.7A24.4,24.4 0 0 1 20.8,-12.8L12.9,-8A15.2,15.2 0 0 0 3.6,-14.8ZM24.3,-1.9A24.4,24.4 0 0 1 18.6,15.8L11.6,9.9A15.2,15.2 0 0 0 15.2,-1.2ZM9.3,22.6A24.4,24.4 0 0 1 -9.3,22.6L-5.8,14.1A15.2,15.2 0 0 0 5.8,14.1ZM-18.6,15.8A24.4,24.4 0 0 1 -24.3,-1.9L-15.2,-1.2A15.2,15.2 0 0 0 -11.6,9.9ZM-20.8,-12.8A24.4,24.4 0 0 1 -5.7,-23.7L-3.6,-14.8A15.2,15.2 0 0 0 -12.9,-8Z" fill="url(#en-ins)"/>
    <path d="M5.7,-23.7A24.4,24.4 0 0 1 20.8,-12.8L12.9,-8A15.2,15.2 0 0 0 3.6,-14.8ZM24.3,-1.9A24.4,24.4 0 0 1 18.6,15.8L11.6,9.9A15.2,15.2 0 0 0 15.2,-1.2ZM9.3,22.6A24.4,24.4 0 0 1 -9.3,22.6L-5.8,14.1A15.2,15.2 0 0 0 5.8,14.1ZM-18.6,15.8A24.4,24.4 0 0 1 -24.3,-1.9L-15.2,-1.2A15.2,15.2 0 0 0 -11.6,9.9ZM-20.8,-12.8A24.4,24.4 0 0 1 -5.7,-23.7L-3.6,-14.8A15.2,15.2 0 0 0 -12.9,-8Z" fill="none" stroke="#5f6670" stroke-width=".35"/>
    <path d="M-1.9,-7.4L-5.1,-24.7L-1.7,-25.1L0.7,-7.6ZM-0.7,-7.6L1.7,-25.1L5.1,-24.7L1.9,-7.4ZM6.4,-4L21.9,-12.5L23.4,-9.4L7.4,-1.7ZM7,-3L24.4,-6.1L25,-2.8L7.6,-0.5ZM5.8,4.9L18.6,17L16.2,19.3L3.9,6.5ZM5,5.7L13.4,21.4L10.4,23L2.8,7.1ZM-2.8,7.1L-10.4,23L-13.4,21.4L-5,5.7ZM-3.9,6.5L-16.2,19.3L-18.6,17L-5.8,4.9ZM-7.6,-0.5L-25,-2.8L-24.4,-6.1L-7,-3ZM-7.4,-1.7L-23.4,-9.4L-21.9,-12.5L-6.4,-4Z" fill="#000" opacity=".55" transform="translate(.5 .7)"/>
    <path d="M-1.9,-7.4L-5.1,-24.7L-1.7,-25.1L0.7,-7.6ZM-0.7,-7.6L1.7,-25.1L5.1,-24.7L1.9,-7.4ZM6.4,-4L21.9,-12.5L23.4,-9.4L7.4,-1.7ZM7,-3L24.4,-6.1L25,-2.8L7.6,-0.5ZM5.8,4.9L18.6,17L16.2,19.3L3.9,6.5ZM5,5.7L13.4,21.4L10.4,23L2.8,7.1ZM-2.8,7.1L-10.4,23L-13.4,21.4L-5,5.7ZM-3.9,6.5L-16.2,19.3L-18.6,17L-5.8,4.9ZM-7.6,-0.5L-25,-2.8L-24.4,-6.1L-7,-3ZM-7.4,-1.7L-23.4,-9.4L-21.9,-12.5L-6.4,-4Z" fill="url(#en-spoke)"/>
    <path d="M-1.9,-7.4L-5.1,-24.7L-3.8,-24.9L-0.8,-7.6ZM0.8,-7.6L3.8,-24.9L5.1,-24.7L1.9,-7.4ZM6.4,-4L21.9,-12.5L22.5,-11.3L6.9,-3.1ZM7.4,-1.5L24.9,-4.1L25,-2.8L7.6,-0.5ZM5.8,4.9L18.6,17L17.7,18L5.1,5.6ZM3.8,6.6L11.6,22.4L10.4,23L2.8,7.1ZM-2.8,7.1L-10.4,23L-11.6,22.4L-3.8,6.6ZM-5.1,5.6L-17.7,18L-18.6,17L-5.8,4.9ZM-7.6,-0.5L-25,-2.8L-24.9,-4.1L-7.4,-1.5ZM-6.9,-3.1L-22.5,-11.3L-21.9,-12.5L-6.4,-4Z" fill="#6f7680" opacity=".55"/>
    <circle r="8.8" fill="#2a2e35" stroke="#b4bbc4" stroke-width=".6"/>
    <circle cx="3.5" cy="-4.9" r=".9" fill="#c9cfd6"/>
    <circle cx="5.7" cy="1.9" r=".9" fill="#c9cfd6"/>
    <circle cx="0" cy="6" r=".9" fill="#c9cfd6"/>
    <circle cx="-5.7" cy="1.9" r=".9" fill="#c9cfd6"/>
    <circle cx="-3.5" cy="-4.9" r=".9" fill="#c9cfd6"/>
    <circle r="3.9" fill="#16181c" stroke="#8b929c" stroke-width=".4"/>
    <path d="M-2.3,-.3h4.6" stroke="#d3d8de" stroke-width=".6" stroke-linecap="round"/>
    </g>
    </defs>
    <path d="M8,196.4H632" stroke="url(#en-ground)" stroke-width=".7"/>
    <ellipse cx="282" cy="195.4" rx="268" ry="6.5" fill="#0d1526" opacity=".2" filter="url(#en-soft)"/>
    <ellipse cx="282" cy="194.8" rx="210" ry="2.4" fill="#0d1526" opacity=".25" filter="url(#en-blur1)"/>
    <ellipse cx="119" cy="195.4" rx="31" ry="2.6" fill="#05080f" opacity=".5" filter="url(#en-blur1)"/>
    <ellipse cx="119" cy="195.7" rx="16" ry="1.1" fill="#000" opacity=".6"/>
    <ellipse cx="437" cy="195.4" rx="31" ry="2.6" fill="#05080f" opacity=".5" filter="url(#en-blur1)"/>
    <ellipse cx="437" cy="195.7" rx="16" ry="1.1" fill="#000" opacity=".6"/>
    <path d="M168,176.6 C168,141 147,112 119,112 C91,112 70,141 70,176.6 Z" fill="url(#en-arch)"/>
    <path d="M486,176.6 C486,141 465,112 437,112 C409,112 388,141 388,176.6 Z" fill="url(#en-arch)"/>
    <use href="#en-tyreg" x="119" y="157"/>
    <use href="#en-face" transform="translate(119 157) rotate(8)"/>
    <circle cx="119" cy="157" r="39" fill="url(#en-wshade)"/>
    <use href="#en-tyreg" x="437" y="157"/>
    <use href="#en-face" transform="translate(437 157) rotate(31)"/>
    <circle cx="437" cy="157" r="39" fill="url(#en-wshade)"/>
    <path d="M57.6,26.2 C86,22.6 165,18.8 250,16.6 C290,16.3 318,17.4 336,21.2 C362,37.5 392,60.5 409,73.2 C413,74.8 418,75.5 424,76.1 C460,79.8 498,85.4 520,89 C529,90.4 535,92.8 538,96.2 C540.4,99.6 541.2,105 541.6,112 C542.2,124 542.6,132 542.2,141 C541.8,151 539.4,160 534.4,166.6 C531.4,170.4 527.4,172 520,172.6 L486,176.4 C486,141 465,112 437,112 C409,112 388,141 388,176.4 L168,176.4 C168,141 147,112 119,112 C91,112 70,141 70,176.4 L46,172.4 C36,171 30.8,168 28,163.5 C24.6,158 22.8,148 22.6,134 C22.5,124 23.6,112 26.2,100.6 C31.6,81.4 39.4,58.6 46.4,39.4 C46.3,37.2 45.4,35.4 44,34 L43.9,33.2 C46.6,29.6 51,27 57.6,26.2Z" fill="url(#en-paint)"/>
    <g clip-path="url(#en-bodyclip)">
    <rect x="20" y="10" width="525" height="170" fill="url(#en-wrap)"/>
    <path d="M506,118.8 C420,118.7 300,118.6 30,118.6" fill="none" stroke="#ffffff" stroke-width=".9"/>
    <path d="M383.6,141 C330,139 250,135 172.6,129.4" fill="none" stroke="#5d6b7d" stroke-width="8" opacity=".22" transform="translate(0 5)" filter="url(#en-blur2)"/>
    <path d="M383.6,141 C330,139 250,135 172.6,129.4" fill="none" stroke="#ffffff" stroke-width="5" opacity=".9" transform="translate(0 -2.4)" filter="url(#en-glow)"/>
    </g>
    <path d="M383.6,141 C330,139 250,135 172.6,129.4" fill="none" stroke="#bcc4ce" stroke-width=".5"/>
    <path d="M506,96.6 C420,95.4 300,94 140,92.6" fill="none" stroke="#a9b2be" stroke-width="2.2" opacity=".55" filter="url(#en-glow)"/>
    <path d="M507,94.6 C420,93.4 300,92 140,90.6" fill="none" stroke="#ffffff" stroke-width="1"/>
    <path d="M507,95.4 C420,94.2 300,92.8 140,91.4" fill="none" stroke="#c3cad3" stroke-width=".45"/>
    <path d="M395.6,82 C393.4,96 390.6,108 388,120 C386.4,127 384.6,137 383.6,146 M262,80.6 C261.4,108 260.6,135 259.8,161.6 M134.4,81.2 C135.6,92 141,100 150.6,105.6 C158,110 164,114.4 168.6,121.6 C171.4,127 172.8,133 173.6,140 L175.6,161.2 M514,90.4 C512,101 503,113.4 486.6,126 M25.6,108 C40,108.4 53,110.8 60.6,116 C64.6,119 67.4,122.6 70,126.6" fill="none" stroke="#ffffff" stroke-width=".6" stroke-linecap="round" transform="translate(.7 .2)"/>
    <path d="M395.6,82 C393.4,96 390.6,108 388,120 C386.4,127 384.6,137 383.6,146 M262,80.6 C261.4,108 260.6,135 259.8,161.6 M134.4,81.2 C135.6,92 141,100 150.6,105.6 C158,110 164,114.4 168.6,121.6 C171.4,127 172.8,133 173.6,140 L175.6,161.2 M514,90.4 C512,101 503,113.4 486.6,126 M25.6,108 C40,108.4 53,110.8 60.6,116 C64.6,119 67.4,122.6 70,126.6" fill="none" stroke="#949ca8" stroke-width=".7" stroke-linecap="round"/>
    <ellipse cx="317" cy="102.4" rx="10.5" ry="2.6" fill="#bfc6cf" opacity=".7"/>
    <rect x="307.5" y="98.8" width="17" height="3.6" rx="1.8" fill="#fbfcfd" stroke="#8f97a2" stroke-width=".6"/>
    <path d="M309.5,99.7 L322.5,99.7" stroke="#ffffff" stroke-width=".7" stroke-linecap="round"/>
    <ellipse cx="197" cy="102.4" rx="10.5" ry="2.6" fill="#bfc6cf" opacity=".7"/>
    <rect x="187.5" y="98.8" width="17" height="3.6" rx="1.8" fill="#fbfcfd" stroke="#8f97a2" stroke-width=".6"/>
    <path d="M189.5,99.7 L202.5,99.7" stroke="#ffffff" stroke-width=".7" stroke-linecap="round"/>
    <path d="M396.5,80.6 C380,64 352,37 329.5,28.2 C327,27 324,26.4 320,26.4 L153.6,27.2 C152,27.2 151,27.9 150.6,29.2 C146,45.6 140,62 135.6,79.4 C230,79.7 320,80.1 396.5,80.6 Z" fill="#111316"/>
    <path d="M391.2,78.6 C376,63.5 352,40.5 331,30.6 C328.6,29.6 326.4,29.2 323.4,29.2 L268.6,29.5 L266.2,78.4 C310,78.6 352,78.6 391.2,78.6 Z" fill="url(#en-glass)"/>
    <path d="M258.4,29.7 L155.6,30.3 C154.4,30.3 153.6,30.9 153.2,31.9 C149,47 143.6,62 139.4,77.4 C186,77.6 224,77.9 256.2,78.1 Z" fill="url(#en-glass)"/>
    <path d="M296,49 C296,43.5 299.5,41 304,41 C308.5,41 311,43.5 311,48 L310.6,55 C307,56.2 300,56.2 296.6,55 Z" fill="#3c4755" opacity=".55"/>
    <path d="M194,50 C194,44.5 197.5,42 202,42 C206.5,42 209,44.5 209,49 L208.6,56 C205,57.2 198,57.2 194.6,56 Z" fill="#3c4755" opacity=".5"/>
    <path d="M352,69 C350,60 354,53 362,51" fill="none" stroke="#3c4755" stroke-width="2" opacity=".5" stroke-linecap="round"/>
    <path d="M226,29.8 L250,29.8 L232,78 L206,78 Z M258,29.8 L262,29.8 L244,78 L238,78 Z" fill="#ffffff" opacity=".07"/>
    <path d="M322,29.2 L346,29.2 L370,52 L360,78 L330,78 Z" fill="#ffffff" opacity=".055"/>
    <path d="M156,31.2 L258,30.6 L258,36.6 C220,35.8 190,36.4 154.2,38.8 Z" fill="#a3b6cc" opacity=".14"/>
    <path d="M268.8,30.2 L324,30 C334,32 346,38 356,46 C330,38.5 300,36 268.6,36.8 Z" fill="#a3b6cc" opacity=".13"/>
    <path d="M258.4,28.8 L268.8,28.7 L266.4,79 L256.2,79 Z" fill="#0c0d0f"/>
    <path d="M268.4,29.6 L266.2,78.6" stroke="#4a515b" stroke-width=".5"/>
    <path d="M133.6,80.2 C230,80.5 320,81 396.4,81.6" fill="none" stroke="#e8ecf0" stroke-width="1.15" stroke-linecap="round"/>
    <path d="M133.8,81.4 C230,81.7 320,82.2 396,82.8" fill="none" stroke="#8a929d" stroke-width=".5"/>
    <path d="M339.6,22.6 C363,39 392,61.4 408,73.2" fill="none" stroke="#28303a" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M341,23 C364,39.2 392.6,61 408.4,72.6" fill="none" stroke="#8fa0b4" stroke-width=".5" opacity=".8"/>
    <path d="M151,20 L154.2,19.9 C153.6,22.9 153,26.3 152.4,29.1 C147,45.6 141,62 136.4,80.8 L132.6,81 C137,62 143,42 151,20Z" fill="url(#en-chan)"/>
    <path d="M151,20 C108.4,21.9 74.3,24.1 57.6,26.2 C51,27 46.6,29.6 43.9,33.2 L44,34 C45.4,35.4 46.3,37.2 46.4,39.4 C39.4,58.6 31.6,81.4 26.2,100.6 C60,96.2 100,88 132.6,81 C137,62 143,42 151,20Z" fill="url(#en-blade)"/>
    <g clip-path="url(#en-bladeclip)">
    <path d="M151,20 C108.4,21.9 74.3,24.1 57.6,26.2 C51,27 46.6,29.6 43.9,33.2 L44,34 C45.4,35.4 46.3,37.2 46.4,39.4 C39.4,58.6 31.6,81.4 26.2,100.6 C60,96.2 100,88 132.6,81 C137,62 143,42 151,20Z" fill="url(#en-sheen)"/>
    <path d="M104,14 L124,14 L100,104 L80,104 Z" fill="url(#en-refl)" opacity=".18"/>
    <path d="M129,14 L134.5,14 L110.5,104 L105,104 Z" fill="#ffffff" opacity=".1"/>
    <path d="M44,35.4 C50,30.6 60,28 74,26.2" fill="none" stroke="#000" stroke-width="2.4" opacity=".55" filter="url(#en-blur1)"/>
    </g>
    <path d="M43.9,33.2 C46.6,29.6 51,27 57.6,26.2 C61.9,25.7 67.5,25.1 74,24.5 L74.2,26.2 C63,27.6 52,29.9 45.4,34.6 C44.8,34.6 44.2,34.4 44,34 Z" fill="#23272d"/>
    <path d="M26.2,100.6 C60,96.2 100,88 132.6,81" fill="none" stroke="#6b7480" stroke-width=".55"/>
    <path d="M57.6,26.2 C74.3,24.1 108.4,21.9 151,20 C143,42 137,62 132.6,81" fill="none" stroke="#aab3be" stroke-width=".6" opacity=".9"/>
    <path d="M43.9,33.2 C46.6,29.6 51,27 57.6,26.2" fill="none" stroke="#aab3be" stroke-width=".6" opacity=".9"/>
    <path d="M46.4,39.6 C46.6,41 46.3,42.4 45.8,44 C40.6,61.4 35,80 31.8,97.6 L46.4,95.6 C48.4,95.4 48.8,98.6 46.8,99.2 L29.4,103.4 C27,103.9 25.6,102.2 26,99.6 C30.4,80 37,59 43.8,41.4 C44.4,40.4 45.4,39.6 46.4,39.6 Z" fill="#3c0a11"/>
    <path d="M45,42.4 C38.6,61 33.2,81 29.4,100.4 L45.8,97.6" fill="none" stroke="#ff4a63" stroke-width="3" opacity=".55" stroke-linejoin="round" filter="url(#en-glow)"/>
    <path class="ve-tail" d="M45,42.4 C38.6,61 33.2,81 29.4,100.4 L45.8,97.6" fill="none" stroke="#ff2d4a" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M82.6,24.1 L86,19.7 L96,19.1 L106,18.4 L116,17.8 L126,17.3 L136,16.8 L146,16.3 L156,15.9 L166,15.5 L176,15.1 L186,14.7 L196,14.3 L206,14 L216,13.7 L226,13.4 L236,13.1 L246,12.8 L256,12.7 L266,12.7 L276,12.7 L286,12.9 L296,13.2 L296,13.2 L299.6,17.5 L296,16.2 L296,16.2 L286,15.9 L276,15.7 L266,15.7 L256,15.7 L246,15.8 L236,16.1 L226,16.4 L216,16.7 L206,17 L196,17.3 L186,17.7 L176,18.1 L166,18.5 L156,18.9 L146,19.3 L136,19.8 L126,20.3 L116,20.8 L106,21.4 L96,22.1 L86,22.7 Z" fill="#1c1f24"/>
    <path d="M86,19.6 L96,19 L106,18.3 L116,17.7 L126,17.2 L136,16.7 L146,16.2 L156,15.8 L166,15.4 L176,15 L186,14.6 L196,14.2 L206,13.9 L216,13.6 L226,13.3 L236,13 L246,12.7 L256,12.6 L266,12.6 L276,12.6 L286,12.8 L296,13.1 L296,13.1" fill="none" stroke="#8d95a0" stroke-width=".6" stroke-linecap="round"/>
    <path d="M156,19.6 L156.8,18.2 L286,15.2 L286.8,16.6 Z" fill="#ffffff" opacity=".85"/>
    <path d="M62,26.1 C65.6,20.1 70.4,17.3 76.4,17.3 L78,24.5 Z" fill="#16181c"/>
    <path d="M64,24.9 C67,19.9 71,18 75.8,17.9" fill="none" stroke="#7c8591" stroke-width=".5"/>
    <path d="M509,88.2 C520,89.2 530,90.8 535.6,93.6 C538.8,95.4 540.6,99.2 541,103.4 C541.2,105.6 540.2,106.6 538.2,106.8 L533.6,107.4" fill="none" stroke="#14171b" stroke-width="3.8" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M532.4,106.6 C536.6,105.6 540,106.4 541.9,108.4 L542.5,134.2 C539.2,135.8 535.2,136 532,134.8 C530.8,125 531,115.4 532.4,106.6 Z" fill="url(#en-lamp)" stroke="#07080a" stroke-width=".5"/>
    <path d="M533.4,108 C536.8,107.2 539.4,107.8 541,109.2 L541.4,133.2 C538.8,134.4 535.6,134.6 533,133.8" fill="none" stroke="#a7b3c1" stroke-width=".45" opacity=".8"/>
    <path d="M509,88.2 C520,89.2 530,90.8 535.6,93.6 C538.8,95.4 540.6,99.2 541,103.4 C541.2,105.6 540.2,106.6 538.2,106.8 L533.6,107.4" fill="none" stroke="#bfe6ff" stroke-width="3" stroke-linecap="round" opacity=".6" filter="url(#en-glow)"/>
    <path class="ve-drl" d="M509,88.2 C520,89.2 530,90.8 535.6,93.6 C538.8,95.4 540.6,99.2 541,103.4 C541.2,105.6 540.2,106.6 538.2,106.8 L533.6,107.4" fill="none" stroke="#f2fbff" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
    <g id="en-cube"><rect x="533.9" y="110.3" width="6" height="5.2" rx="1.3" fill="#040506"/><rect x="534.4" y="110.8" width="5" height="4.2" rx=".9" fill="#141a21" stroke="#56626f" stroke-width=".3"/><circle cx="536.9" cy="112.9" r="1.45" fill="url(#en-lens)"/></g>
    <use href="#en-cube" y="5.8"/>
    <use href="#en-cube" y="11.6"/>
    <use href="#en-cube" y="17.4"/>
    <path d="M533,108.4 L537,107.4 L533.6,124 Z" fill="#ffffff" opacity=".1"/>
    <path d="M541.2,104.6 C541.8,108 542,111 542.1,114" fill="none" stroke="#9aa2ad" stroke-width=".5"/>
    <path d="M391.6,83.6 C392.8,85.6 393.2,87.6 393.2,89.8 L400.8,89.6 C399.6,87.6 399,85.6 399,83.4 Z" fill="#101215"/>
    <path d="M378.6,74.6 C379.4,71.6 384,70.2 390,69.2 C395.6,68.3 401.2,68.4 404.2,70.4 C407,72.4 407.6,76.6 406.4,80 C405.4,82.8 402.6,84.4 398.6,84.6 L385,84.8 C381,84.8 378.6,83 378.2,80.2 C378,78.2 378.1,76.4 378.6,74.6 Z" fill="url(#en-mir)" stroke="#060708" stroke-width=".3"/>
    <path d="M380.4,73.4 C383,71.4 388,70.4 393,69.8 C397.6,69.3 401.6,69.5 403.8,70.9" fill="none" stroke="#c3cad3" stroke-width=".7" stroke-linecap="round" opacity=".75"/>
    <path d="M383,72.2 C388,70.8 396,70 401.8,70.6 C396,71.4 389,72.4 383.6,73.6 Z" fill="#ffffff" opacity=".22"/>
    <path d="M404.6,71.4 C406.6,73.6 407,77 406,80" fill="none" stroke="#8d96a1" stroke-width=".55" stroke-linecap="round" opacity=".8"/>
    <path d="M384.6,83.8 L401,83.4" stroke="#ffb35c" stroke-width=".8" stroke-linecap="round" opacity=".9"/>
    <path d="M63.5,150 L70.5,127 C79,113.6 95,106.6 119,106.2 C143,106.6 159,113.6 167.5,127 L174.5,150" fill="none" stroke="#8592a3" stroke-width="3" opacity=".35" filter="url(#en-glow)"/>
    <path d="M381.5,150 L388.5,127 C397,113.6 413,106.6 437,106.2 C461,106.6 477,113.6 485.5,127 L492.5,150" fill="none" stroke="#8592a3" stroke-width="3" opacity=".35" filter="url(#en-glow)"/>
    <g clip-path="url(#en-bodyclip)">
    <path d="M18,159.6 C30,160 48,161 62.8,161.8 L63.5,150 L70.5,127 C79,113.6 95,106.6 119,106.2 C143,106.6 159,113.6 167.5,127 L174.5,150 L175.2,161.2 L380.8,161.4 L381.5,150 L388.5,127 C397,113.6 413,106.6 437,106.2 C461,106.6 477,113.6 485.5,127 L492.5,150 L493.3,163.6 C512,163.2 528,161.4 546,157.4 L546,182 L16,182 Z" fill="url(#en-clad)"/>
    <path d="M18,159.6 C30,160 48,161 62.8,161.8 L63.5,150 L70.5,127 C79,113.6 95,106.6 119,106.2 C143,106.6 159,113.6 167.5,127 L174.5,150 L175.2,161.2 L380.8,161.4 L381.5,150 L388.5,127 C397,113.6 413,106.6 437,106.2 C461,106.6 477,113.6 485.5,127 L492.5,150 L493.3,163.6 C512,163.2 528,161.4 546,157.4" fill="none" stroke="#69717c" stroke-width=".6"/>
    <path d="M167.6,150 C165,128 147,112.4 119,112.4 C91,112.4 73,128 70.4,150" fill="none" stroke="#4a5059" stroke-width=".7"/>
    <path d="M485.6,150 C483,128 465,112.4 437,112.4 C409,112.4 391,128 388.4,150" fill="none" stroke="#4a5059" stroke-width=".7"/>
    <path d="M177,168 L379.6,168.2" stroke="#4d535c" stroke-width=".7"/>
    <path d="M177,168.8 L379.6,169" stroke="#08090b" stroke-width=".5"/>
    <path d="M510,170 L535,166.4" stroke="#a3abb5" stroke-width="1.1" stroke-linecap="round"/>
    <path d="M534.6,140.6 C537.4,140.2 540.2,140.4 542.6,141.2 L542.4,152.8 C539.8,153.8 537,154 534.4,153.6 C533.8,149.4 533.9,144.8 534.6,140.6 Z" fill="#14171b"/>
    <path d="M535.4,144 L541.6,144 M535.2,147.2 L541.6,147.2 M535.2,150.4 L541.6,150.4" stroke="#3e444d" stroke-width=".6"/>
    <path d="M28,167.4 L52,168.6" stroke="#a3abb5" stroke-width="1.1" stroke-linecap="round"/>
    <path d="M24.6,148.4 L36,149" stroke="#7a1420" stroke-width="2" stroke-linecap="round"/>
    </g>
    <path d="M57.6,26.2 C86,22.6 165,18.8 250,16.6 C290,16.3 318,17.4 336,21.2 C362,37.5 392,60.5 409,73.2 C413,74.8 418,75.5 424,76.1 C460,79.8 498,85.4 520,89 C529,90.4 535,92.8 538,96.2 C540.4,99.6 541.2,105 541.6,112 C542.2,124 542.6,132 542.2,141 C541.8,151 539.4,160 534.4,166.6 C531.4,170.4 527.4,172 520,172.6 L486,176.4 C486,141 465,112 437,112 C409,112 388,141 388,176.4 L168,176.4 C168,141 147,112 119,112 C91,112 70,141 70,176.4 L46,172.4 C36,171 30.8,168 28,163.5 C24.6,158 22.8,148 22.6,134 C22.5,124 23.6,112 26.2,100.6 C31.6,81.4 39.4,58.6 46.4,39.4 C46.3,37.2 45.4,35.4 44,34 L43.9,33.2 C46.6,29.6 51,27 57.6,26.2Z" fill="none" stroke="#7d8692" stroke-width=".75" stroke-linejoin="round"/>`;
  const CAR_PLUG = [`
    <ellipse cx="575" cy="195.4" rx="11" ry="1.3" fill="#0d1526" opacity=".16" filter="url(#en-blur1)"/>
    <rect x="591.8" y="34" width="3.4" height="40" rx="1.2" fill="url(#en-conduit)"/>
    <rect x="572.5" y="72" width="42" height="64" rx="9.5" fill="url(#en-box)" stroke="#8d95a0" stroke-width=".8" filter="url(#en-boxsh)"/>
    <rect x="576" y="75.5" width="35" height="57" rx="7" fill="url(#en-boxglass)"/>
    <path d="M577.6,82 C580,77.5 584,77 590,77 L603,77 L583,130 C579.6,130 577.6,128 577.6,125 Z" fill="#ffffff" opacity=".07"/>
    <circle cx="593.5" cy="98" r="8.2" fill="none" stroke="#56606d" stroke-width="1.1"/>
    <circle cx="593.5" cy="98" r="8.2" fill="none" stroke="#c9d1db" stroke-width="1.1" stroke-dasharray="9 43" stroke-linecap="round" transform="rotate(-140 593.5 98)"/>
    <path d="M594.6,92.5 L590.8,98.6 L593.6,98.6 L592.4,103.5 L596.2,97.3 L593.4,97.3 Z" fill="#8e98a6"/>
    <rect class="ve-box-led" x="585" y="119" width="17" height="2.6" rx="1.3" fill="#a855c7"/>
    <rect x="589" y="136" width="9" height="4.5" rx="1.5" fill="#2a2e34"/>
    <rect x="617.5" y="90" width="7.5" height="18" rx="2.6" fill="url(#en-box)" stroke="#8d95a0" stroke-width=".7"/>
    <rect x="619.6" y="93.5" width="3.3" height="9" rx="1.4" fill="#1d2127"/>
    <path class="ve-cable" d="M593.5,138 C593.5,162 590,186.5 575,187.6 C561,188.6 562,140 554,127.4" fill="none" stroke="#24282e" stroke-width="3.4" stroke-linecap="round"/>
    <path d="M593.5,138 C593.5,162 590,186.5 575,187.6 C561,188.6 562,140 554,127.4" fill="none" stroke="#8a919c" stroke-width=".7" stroke-linecap="round" opacity=".8" transform="translate(-.6 -.8)"/>`, `
    <path d="M538.6,106.4 L545.2,99.2 L547.8,101.2 L541.6,108.6 Z" fill="#c3cad3"/>
    <path d="M538.6,106.4 L545.2,99.2 L546.4,100.1 L539.6,107.2 Z" fill="#fbfcfd" stroke="#8f97a2" stroke-width=".5" stroke-linejoin="round"/>
    <path d="M538.2,107.8 L541.4,107.8 L541.8,121.6 L538.6,121.6 Z" fill="#0d0f12"/>
    <path d="M540.2,109.4 L546.4,109 C549.4,108.8 551.6,110.2 552.8,112.6 L557.4,122.4 C558.4,124.8 557.2,127.6 554.4,127.8 L549.6,128 C547.4,128.1 546,127 545.2,125 L543.8,121.8 L540.6,121.8 Z" fill="url(#en-plug)" stroke="#0c0d10" stroke-width=".5" stroke-linejoin="round"/>
    <path d="M542,110.4 L546.4,110.1 C548.6,110 550.2,111 551.2,112.8 L555.2,121.4" fill="none" stroke="#9aa2ad" stroke-width=".6" stroke-linecap="round"/>
    <path d="M544.6,113.6 L548.2,113.4" stroke="#a855c7" stroke-width="1.2" stroke-linecap="round"/>`];
  const CAR_FLOW = `<path class="ve-flow" d="M593.5,138 C593.5,162 590,186.5 575,187.6 C561,188.6 562,140 554,127.4" fill="none" stroke="#a855c7" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="2 9"/>`;

  /* ─── Voiture en vue de profil : roadster sport électrique (illustration originale) ──
     Rouge corail métallisé, carbone, étriers violets (couleur VE de l'app). Même principe que la Niro :
     .ve-plug (borne, câble, trappe ouverte, fiche) seulement branchée, .ve-flow seulement en charge. */
  const RD_ART = `
<defs>
<path id="rd-body" d="M49,165.6 C43.4,160.2 39.6,152.4 37.4,143.4 C35.2,134.4 34,122.4 33.8,112.4 C33.7,106.4 33.9,101 34.4,97.8 L31.4,95.6 L30.8,92 C34,92.2 38.2,95 43,97.6 C45.6,98.9 48.4,99.4 52,99.4 C56.6,99.4 59.6,98.6 64,97.8 C74,96.4 86,95.6 98,95.2 C108,94.6 122,92.4 136,89.6 C148,87.2 160,82.6 170,77.8 C179,74.1 187,71.2 193.2,72 C197.4,72.8 199.6,76.4 199.9,81.6 L200.6,97.6 L338.6,98.9 C372,99.3 410,100.3 441,101.4 C474,102.6 504,107.4 524,113.8 C534,117.4 541.4,123.4 545.2,131.4 C548,137.6 549.8,143 550,148.6 C550.2,154.6 548.6,161.4 547,167 C546,170.8 544.8,173.8 543,175.6 L541,179.5 L478.1,179.5 A44.4,44.4 0 1 0 404,179.5 L176,179.5 A44.4,44.4 0 1 0 101.9,179.5 L86,179.5 C70,179.1 56,172.4 49,165.6 Z"/><clipPath id="rd-clip"><use href="#rd-body"/></clipPath>
<linearGradient id="rd-paint" gradientUnits="userSpaceOnUse" x1="0" y1="92" x2="0" y2="182"><stop offset="0" stop-color="#f6687c"/><stop offset=".08" stop-color="#e03652"/><stop offset=".25" stop-color="#cb2541"/><stop offset=".48" stop-color="#ab1c36"/><stop offset=".6" stop-color="#bd2741"/><stop offset=".636" stop-color="#e65b71"/><stop offset=".652" stop-color="#6e0d21"/><stop offset=".8" stop-color="#560a1a"/><stop offset="1" stop-color="#36050f"/></linearGradient>
<linearGradient id="rd-upper" gradientUnits="userSpaceOnUse" x1="0" y1="98" x2="0" y2="136"><stop offset="0" stop-color="#ffb3be" stop-opacity=".35"/><stop offset=".25" stop-color="#ff8193" stop-opacity=".06"/><stop offset=".75" stop-color="#ff8496" stop-opacity=".05"/><stop offset="1" stop-color="#ffc2cb" stop-opacity=".38"/></linearGradient>
<linearGradient id="rd-under" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a0410" stop-opacity=".6"/><stop offset=".5" stop-color="#3a0410" stop-opacity=".15"/><stop offset="1" stop-color="#3a0410" stop-opacity="0"/></linearGradient>
<linearGradient id="rd-hump" gradientUnits="userSpaceOnUse" x1="0" y1="71" x2="0" y2="98"><stop offset="0" stop-color="#ffc0ca" stop-opacity=".7"/><stop offset=".35" stop-color="#ff7a8e" stop-opacity=".25"/><stop offset="1" stop-color="#7a0e22" stop-opacity=".25"/></linearGradient>
<radialGradient id="rd-haunch" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffc4cd" stop-opacity=".55"/><stop offset=".5" stop-color="#ff8a9c" stop-opacity=".18"/><stop offset="1" stop-color="#ff8a9c" stop-opacity="0"/></radialGradient>
<linearGradient id="rd-endR" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2a030a" stop-opacity=".6"/><stop offset="1" stop-color="#2a030a" stop-opacity="0"/></linearGradient>
<linearGradient id="rd-endF" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2a030a" stop-opacity="0"/><stop offset="1" stop-color="#2a030a" stop-opacity=".55"/></linearGradient>
<linearGradient id="rd-spec" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="rd-soft" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".13"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="rd-sbox" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".45" stop-color="#ffe3e8" stop-opacity=".2"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="rd-tsh" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient>
<radialGradient id="rd-dk" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#2a030a" stop-opacity=".3"/><stop offset="1" stop-color="#2a030a" stop-opacity="0"/></radialGradient>
<linearGradient id="rd-carbon" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a5059"/><stop offset=".3" stop-color="#1c1f24"/><stop offset="1" stop-color="#08090b"/></linearGradient>
<pattern id="rd-cf" width="2.4" height="2.4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="1.2" height="1.2" fill="#3a3e45"/><rect x="1.2" y="1.2" width="1.2" height="1.2" fill="#3a3e45"/></pattern>
<linearGradient id="rd-glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e3edf6" stop-opacity=".5"/><stop offset=".4" stop-color="#9fb2c4" stop-opacity=".32"/><stop offset="1" stop-color="#2a3644" stop-opacity=".42"/></linearGradient>
<linearGradient id="rd-seat" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6a707a"/><stop offset=".3" stop-color="#33373e"/><stop offset="1" stop-color="#16181b"/></linearGradient>
<linearGradient id="rd-seat2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9aa0a9"/><stop offset=".35" stop-color="#5a5f68"/><stop offset="1" stop-color="#2c2f35"/></linearGradient>
<linearGradient id="rd-intake" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#020203"/><stop offset=".75" stop-color="#121418"/><stop offset="1" stop-color="#30353c"/></linearGradient>
<linearGradient id="rd-scoop" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#3a0410" stop-opacity="0"/><stop offset=".6" stop-color="#3a0410" stop-opacity=".55"/><stop offset="1" stop-color="#1a0207" stop-opacity=".9"/></linearGradient>
<linearGradient id="rd-blade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e2465f"/><stop offset=".5" stop-color="#b41f3a"/><stop offset="1" stop-color="#6e0d21"/></linearGradient>
<radialGradient id="rd-tyre" cx=".5" cy=".5" r=".5"><stop offset=".72" stop-color="#2c2f35"/><stop offset=".86" stop-color="#1c1e22"/><stop offset=".97" stop-color="#121316"/><stop offset="1" stop-color="#0b0c0e"/></radialGradient>
<linearGradient id="rd-lip" x1=".15" y1="0" x2=".85" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".45" stop-color="#b9c0c9"/><stop offset="1" stop-color="#5d646d"/></linearGradient>
<radialGradient id="rd-barrel" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#2a2e34"/><stop offset=".75" stop-color="#15171a"/><stop offset="1" stop-color="#050506"/></radialGradient>
<radialGradient id="rd-disc" cx=".4" cy=".35" r=".65"><stop offset="0" stop-color="#aab0b8"/><stop offset=".6" stop-color="#6f757d"/><stop offset="1" stop-color="#3f444a"/></radialGradient>
<linearGradient id="rd-cal" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c27ad8"/><stop offset="1" stop-color="#7b3596"/></linearGradient>
<linearGradient id="rd-spk1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f3f5f8"/><stop offset=".55" stop-color="#b6bdc6"/><stop offset="1" stop-color="#7d858f"/></linearGradient>
<linearGradient id="rd-spk2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a8b0ba"/><stop offset=".55" stop-color="#6c747e"/><stop offset="1" stop-color="#454b53"/></linearGradient>
<linearGradient id="rd-hub" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#eef1f4"/><stop offset="1" stop-color="#4d545d"/></linearGradient>
<linearGradient id="rd-flap" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ea5068"/><stop offset=".5" stop-color="#b41f3a"/><stop offset="1" stop-color="#6e0d21"/></linearGradient>
<linearGradient id="rd-box" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#cdd2d9"/></linearGradient>
<linearGradient id="rd-boxglass" x1="0" y1="0" x2=".6" y2="1"><stop offset="0" stop-color="#3a424d"/><stop offset=".5" stop-color="#1b2027"/><stop offset="1" stop-color="#101318"/></linearGradient>
<linearGradient id="rd-conduit" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b8bfc8" stop-opacity="0"/><stop offset="1" stop-color="#b8bfc8" stop-opacity=".9"/></linearGradient>
<linearGradient id="rd-plug" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f6f8"/><stop offset="1" stop-color="#9aa2ad"/></linearGradient>
<filter id="rd-boxsh" x="-30%" y="-20%" width="160%" height="150%"><feDropShadow dx="0" dy="1.5" stdDeviation="1.6" flood-color="#0b1220" flood-opacity=".28"/></filter>
<filter id="rd-b1" x="-20%" y="-200%" width="140%" height="500%"><feGaussianBlur stdDeviation="1.2"/></filter>
<filter id="rd-b3" x="-20%" y="-300%" width="140%" height="700%"><feGaussianBlur stdDeviation="3"/></filter>
<filter id="rd-glow" x="-30%" y="-300%" width="160%" height="700%"><feGaussianBlur stdDeviation=".9"/></filter>
<g id="rd-wb"><circle r="41" fill="url(#rd-tyre)"/><circle r="40.6" stroke="#5f6670" stroke-width=".5" opacity=".55"/><path d="M0,-40A40,40 0 1 0 0,40A40,40 0 1 0 0,-40ZM0,-31.4A31.4,31.4 0 1 1 0,31.4A31.4,31.4 0 1 1 0,-31.4Z" fill="url(#rd-tsh)"/><circle r="32.4" stroke="#34383e" stroke-width=".5"/><circle r="30.9" fill="url(#rd-lip)"/><circle r="29.4" fill="url(#rd-barrel)"/><circle r="22.6" fill="url(#rd-disc)"/><circle r="19.8" stroke="#2a2e33" stroke-width="1" stroke-dasharray=".01 2.6" stroke-linecap="round"/><circle r="16.8" stroke="#2a2e33" stroke-width="1" stroke-dasharray=".01 2.6" stroke-dashoffset="1.3" stroke-linecap="round"/><circle r="22.2" stroke="#9ba1a9" stroke-width=".4"/><circle r="12" fill="#2f3339" stroke="#1d2024" stroke-width=".8"/></g>
<g id="rd-ws"><path d="M-.9,-5.9 -1.3,-14.9 -7.5,-26.8 -3.2,-27.8 1.1,-19.2 5.4,-27.8 9.7,-26.8 3.5,-14.9 3.1,-5.9ZM7.5,-2.7 15.9,-5.9 25.3,-15.5 27.5,-11.7 20.7,-5 30.2,-3.5 30.6,.9 17.4,-1.4 8.7,1ZM7,6.2 12.6,13.2 24.7,19.2 21.7,22.5 13.2,18.1 14.8,27.5 10.7,29.3 8.8,16 3.8,8.5ZM-1.6,8.5 -6.6,16 -8.5,29.3 -12.6,27.5 -11,18.1 -19.5,22.5 -22.5,19.2 -10.4,13.2 -4.8,6.2ZM-6.5,1 -15.2,-1.4 -28.4,.9 -28,-3.5 -18.5,-5 -25.3,-11.7 -23.1,-15.5 -13.7,-5.9 -5.3,-2.7Z" fill="#0b0c0e"/><path d="M0,-7.6 0,-18.4 -6.5,-28.8 -4.3,-29.2 0,-20.6ZM0,-18.4 6.5,-28.8 8.6,-28.2 2.4,-16.3 2,-7.3 0,-7.6ZM7.2,-2.3 17.5,-5.7 25.4,-15.1 26.4,-13.1 19.6,-6.4ZM17.5,-5.7 29.4,-2.7 29.5,-.5 16.3,-2.8 7.6,-.4 7.2,-2.3ZM4.5,6.1 10.8,14.9 22.2,19.5 20.6,21.1 12.1,16.7ZM10.8,14.9 11.7,27.1 9.6,27.9 7.7,14.6 2.7,7.1 4.5,6.1ZM-4.5,6.1 -10.8,14.9 -11.7,27.1 -13.7,26.1 -12.1,16.7ZM-10.8,14.9 -22.2,19.5 -23.6,17.8 -11.5,11.8 -5.9,4.8 -4.5,6.1ZM-7.2,-2.3 -17.5,-5.7 -29.4,-2.7 -29.1,-4.9 -19.6,-6.4ZM-17.5,-5.7 -25.4,-15.1 -24.2,-16.9 -14.8,-7.3 -6.4,-4.1 -7.2,-2.3Z" fill="url(#rd-spk2)"/><path d="M-2,-7.3 -2.4,-16.3 -8.6,-28.2 -6.5,-28.8 0,-18.4 0,-7.6ZM0,-18.4 0,-20.6 4.3,-29.2 6.5,-28.8ZM6.4,-4.1 14.8,-7.3 24.2,-16.9 25.4,-15.1 17.5,-5.7 7.2,-2.3ZM17.5,-5.7 19.6,-6.4 29.1,-4.9 29.4,-2.7ZM5.9,4.8 11.5,11.8 23.6,17.8 22.2,19.5 10.8,14.9 4.5,6.1ZM10.8,14.9 12.1,16.7 13.7,26.1 11.7,27.1ZM-2.7,7.1 -7.7,14.6 -9.6,27.9 -11.7,27.1 -10.8,14.9 -4.5,6.1ZM-10.8,14.9 -12.1,16.7 -20.6,21.1 -22.2,19.5ZM-7.6,-.4 -16.3,-2.8 -29.5,-.5 -29.4,-2.7 -17.5,-5.7 -7.2,-2.3ZM-17.5,-5.7 -19.6,-6.4 -26.4,-13.1 -25.4,-15.1Z" fill="url(#rd-spk1)"/><path d="M0,-7.6 0,-18.4 -6.5,-28.8M0,-18.4 6.5,-28.8M7.2,-2.3 17.5,-5.7 25.4,-15.1M17.5,-5.7 29.4,-2.7M4.5,6.1 10.8,14.9 22.2,19.5M10.8,14.9 11.7,27.1M-4.5,6.1 -10.8,14.9 -11.7,27.1M-10.8,14.9 -22.2,19.5M-7.2,-2.3 -17.5,-5.7 -29.4,-2.7M-17.5,-5.7 -25.4,-15.1" stroke="#fff" stroke-width=".35" opacity=".7"/><path d="M-2,-7.3 -2.4,-16.3 -8.6,-28.2M6.4,-4.1 14.8,-7.3 24.2,-16.9M5.9,4.8 11.5,11.8 23.6,17.8M-2.7,7.1 -7.7,14.6 -9.6,27.9M-7.6,-.4 -16.3,-2.8 -29.5,-.5" stroke="#fff" stroke-width=".45" opacity=".85"/><path d="M8.6,-28.2 2.4,-16.3 2,-7.3M29.5,-.5 16.3,-2.8 7.6,-.4M9.6,27.9 7.7,14.6 2.7,7.1M-23.6,17.8 -11.5,11.8 -5.9,4.8M-24.2,-16.9 -14.8,-7.3 -6.4,-4.1" stroke="#0b0c0e" stroke-width=".6" opacity=".7"/><circle r="29.7" stroke="#060708" stroke-width=".7"/><circle r="30.2" stroke="#f4f6f8" stroke-width=".45" opacity=".85"/><circle r="8" fill="url(#rd-spk2)" stroke="#1a1c20" stroke-width=".5"/><circle r="6.2" stroke="#15171a" stroke-width="2" stroke-dasharray=".01 7.79" stroke-linecap="round"/><circle r="6.2" stroke="#e6e9ed" stroke-width="1.3" stroke-dasharray=".01 7.79" stroke-linecap="round"/><path d="M3.6,2.1 0,4.2 -3.6,2.1 -3.6,-2.1 -0,-4.2 3.6,-2.1Z" fill="url(#rd-hub)" stroke="#23272c" stroke-width=".4"/><circle r="2" fill="#141619" stroke="#e23a56" stroke-width=".7"/><path d="M-28.6,-9.3 A30.1,30.1 0 0 1 -6.3,-29.4" stroke="#fff" stroke-width="1" stroke-linecap="round"/></g>
<path id="rd-inl" d="M186.6,73.4 C191.6,72.2 196.8,73.6 198.8,77.4 C199.6,79 199.8,80.8 199.9,82.4 L200.5,97.6 L196.6,97.6 L196,82.6 C195.8,79.4 193.6,77 190.2,76.4 C176,74.6 150,88 112,94.6 C146,86.6 172,76 186.6,73.4 Z"/>
</defs>
<ellipse cx="290" cy="194.4" rx="262" ry="3.8" fill="#0b0f1a" opacity=".2" filter="url(#rd-b3)"/>
<path d="M70,182 L530,182 L536,194.8 L64,194.8 Z" fill="#0b0f1a" opacity=".3" filter="url(#rd-b3)"/>
<path d="M150,187.6 L410,187.6" stroke="#aab4c0" stroke-width="1.8" opacity=".22" filter="url(#rd-glow)"/>
<ellipse cx="138.9" cy="195.5" rx="30" ry="2.2" fill="#05070c" opacity=".6" filter="url(#rd-b1)"/>
<ellipse cx="138.9" cy="195.9" rx="21" ry="1.2" fill="#000" opacity=".6" filter="url(#rd-glow)"/>
<ellipse cx="441" cy="195.5" rx="30" ry="2.2" fill="#05070c" opacity=".6" filter="url(#rd-b1)"/>
<ellipse cx="441" cy="195.9" rx="21" ry="1.2" fill="#000" opacity=".6" filter="url(#rd-glow)"/>
<path d="M204.8,99 C202.6,92 200.9,85.4 201,79.6 C201.1,76.2 203.4,74.4 206.8,74.5 C210.6,74.7 212.8,76.6 213,79.8 C213.2,82.6 212.6,85.4 213.5,88.2 C215.2,91.6 217.2,95 218.4,99 ZM204.2,80.4 C204.2,79.8 204.6,79.4 205.2,79.4 L209,79.4 C209.6,79.4 210,79.8 210,80.4 L210,81.4 C210,82 209.6,82.4 209,82.4 L205.2,82.4 C204.6,82.4 204.2,82 204.2,81.4 Z" fill="url(#rd-seat2)" fill-rule="evenodd" stroke="#c4cad2" stroke-width=".4" transform="translate(8.2 1.8)"/>
<path d="M204.8,99 C202.6,92 200.9,85.4 201,79.6 C201.1,76.2 203.4,74.4 206.8,74.5 C210.6,74.7 212.8,76.6 213,79.8 C213.2,82.6 212.6,85.4 213.5,88.2 C215.2,91.6 217.2,95 218.4,99 ZM204.2,80.4 C204.2,79.8 204.6,79.4 205.2,79.4 L209,79.4 C209.6,79.4 210,79.8 210,80.4 L210,81.4 C210,82 209.6,82.4 209,82.4 L205.2,82.4 C204.6,82.4 204.2,82 204.2,81.4 Z" fill="#0e1013" fill-rule="evenodd" stroke="#4a5059" stroke-width=".4" transform="translate(3.4 .8)"/>
<path d="M204.8,99 C202.6,92 200.9,85.4 201,79.6 C201.1,76.2 203.4,74.4 206.8,74.5 C210.6,74.7 212.8,76.6 213,79.8 C213.2,82.6 212.6,85.4 213.5,88.2 C215.2,91.6 217.2,95 218.4,99 ZM204.2,80.4 C204.2,79.8 204.6,79.4 205.2,79.4 L209,79.4 C209.6,79.4 210,79.8 210,80.4 L210,81.4 C210,82 209.6,82.4 209,82.4 L205.2,82.4 C204.6,82.4 204.2,82 204.2,81.4 Z" fill="url(#rd-seat)" fill-rule="evenodd" stroke="#a3aab4" stroke-width=".5"/>
<path d="M203.2,93 C202.2,88 201.9,83.4 202.1,79.8 C202.3,77.2 204.2,75.7 206.8,75.7 M207.6,89.6 C208.8,92.6 210,95.6 211,98.6" stroke="#f0436b" stroke-width=".5" stroke-dasharray="1 .7"/>
<path d="M206.2,87.8 C208.6,87.3 211,87.3 213.2,87.9" stroke="#0b0c0e" stroke-width=".8"/>
<path d="M214,99 C236,97.2 266,96.8 304,97.8 L304,99.6 L214,99.6 Z" fill="#1c1f24"/><path d="M214.6,98.8 C236,97 266,96.6 303,97.6" stroke="#6b727c" stroke-width=".4"/>
<path d="M304,99.6 C305.4,96 310,94.6 317,95 C324,95.4 330,97.2 335,99.6 Z" fill="#141619" stroke="#4a5059" stroke-width=".4"/>
<path d="M299.2,96.6 L306.6,99.2" stroke="#25282d" stroke-width="1.5" stroke-linecap="round"/>
<g transform="rotate(-18 298.4 95.6)"><ellipse cx="298.4" cy="95.6" rx="2.8" ry="4.2" stroke="#1b1d22" stroke-width="1.3"/><path d="M296.4,92.6 A2.8,4.2 0 0 1 300.4,92.6" stroke="#8a929c" stroke-width=".45"/><path d="M297.7,91.5 A2.8,4.2 0 0 1 299.1,91.5" stroke="#f0436b" stroke-width="1.3"/></g>
<path d="M176,179.5 A44.4,44.4 0 1 0 101.9,179.5 Z" fill="#0a0b0d"/>
<path d="M478.1,179.5 A44.4,44.4 0 1 0 404,179.5 Z" fill="#0a0b0d"/>
<use href="#rd-wb" x="138.9" y="155"/>
<path d="M149.6,131 A26.2,26.2 0 0 1 164.5,149.5 L151.5,150.9 A13.2,13.2 0 0 0 145.5,143.5 Z" fill="url(#rd-cal)" stroke="#3d1550" stroke-width=".5" stroke-linejoin="round"/><path d="M150.7,132.8 A25.1,25.1 0 0 1 163,148" stroke="#e3b8f0" stroke-width=".5"/>
<use href="#rd-ws" transform="translate(138.9 155) rotate(9)"/>
<use href="#rd-wb" x="441" y="155"/>
<path d="M415.4,149.5 A26.2,26.2 0 0 1 430.4,131 L434.4,143.5 A13.2,13.2 0 0 0 428.5,150.9 Z" fill="url(#rd-cal)" stroke="#3d1550" stroke-width=".5" stroke-linejoin="round"/><path d="M416.9,148 A25.1,25.1 0 0 1 429.2,132.8" stroke="#e3b8f0" stroke-width=".5"/>
<use href="#rd-ws" transform="translate(441 155) rotate(-21)"/>
<use href="#rd-body" fill="url(#rd-paint)"/>
<g clip-path="url(#rd-clip)">
<path d="M393.4,134.8 C360,133.4 310,130.6 262,127.4 C246,126.3 232,124.8 220,122.2 C204,118.8 192,114 182,107.8 L176,60 L560,60 L560,136 Z" fill="url(#rd-upper)"/>
<path d="M393.4,135 C360,133.6 310,130.8 262,127.6 C246,126.5 232,125 220,122.4 C204,119 192,114.2 182,108 L176,128 C210,138 250,141 300,143 C340,144.4 370,144.4 396,144 Z" fill="url(#rd-under)"/>
<path d="M10,100.6 C60,101.4 140,104 260,108.4 L352,109.4 C410,110 470,111.6 530,118 L530,123 C470,116.6 410,115.2 352,114.6 C260,113.6 140,109.6 60,107 C40,106.4 20,106.2 10,106 Z" fill="url(#rd-sbox)" opacity=".9"/>
<ellipse cx="42" cy="132" rx="40" ry="34" fill="url(#rd-dk)"/>
<path d="M100.9,183 L100.9,176.4 C84,173.8 54,164 28,143 L28,183 Z" fill="url(#rd-carbon)"/>
<path d="M100.9,176.4 C84,173.8 54,164 28,143" stroke="#a3aab4" stroke-width=".5"/>
<path d="M98,95.2 C108,94.6 122,92.4 136,89.6 C148,87.2 160,82.6 170,77.8 C179,74.1 187,71.2 193.2,72 C197.4,72.8 199.6,76.4 199.9,81.6 L200.6,97.6 L200.6,98.4 C184,96.6 160,94.6 138,94.4 C122,94.3 108,94.8 98,95.2 Z" fill="url(#rd-hump)"/>
<ellipse cx="134.9" cy="100" rx="70" ry="9" fill="url(#rd-haunch)"/>
<path d="M196,104.6 C170,101.8 140,100.6 110,101.4 C84,102 60,104.4 38,108" stroke="#5a0816" stroke-width="3" opacity=".16" filter="url(#rd-glow)"/>
<path d="M88.7,136.7 A53.4,53.4 0 0 1 185.2,128.2" stroke="#ffb6c1" stroke-width="5" opacity=".16" filter="url(#rd-glow)"/>
<path d="M236,111.6 C200,105.6 170,101.6 138,101 C100,100.4 60,102.6 26,108" stroke="#ffd2d9" stroke-width="4" opacity=".22" filter="url(#rd-glow)"/>
<path d="M226,109.4 C196,104.4 168,101.2 138,100.8 C104,100.4 70,102 40,105.6" stroke="url(#rd-spec)" stroke-width=".8" opacity=".75"/>
<ellipse cx="447" cy="107" rx="64" ry="8" fill="url(#rd-haunch)" opacity=".8"/>
<rect x="29" y="88" width="26" height="96" fill="url(#rd-endR)"/>
<rect x="522" y="100" width="30" height="84" fill="url(#rd-endF)"/>
<circle cx="138.9" cy="155" r="47.4" stroke="#2a030a" stroke-width="6" opacity=".38" filter="url(#rd-glow)"/>
<circle cx="441" cy="155" r="47.4" stroke="#2a030a" stroke-width="6" opacity=".38" filter="url(#rd-glow)"/>
<path d="M288,98 L304,98 L292,150 L276,150 Z" fill="url(#rd-soft)" opacity=".7"/>
<ellipse cx="300" cy="119" rx="96" ry="20" fill="url(#rd-haunch)" opacity=".32"/>
</g>
<use href="#rd-body" stroke="#3e0510" stroke-width=".5" stroke-linejoin="round" opacity=".55"/>
<path d="M176,179.5 A44.4,44.4 0 1 0 101.9,179.5" stroke="#2e030b" stroke-width="1.2"/>
<path d="M97.5,136.5 A45.3,45.3 0 0 1 172.6,124.6" stroke="#ffa3b1" stroke-width=".7" opacity=".75" stroke-linecap="round"/>
<path d="M478.1,179.5 A44.4,44.4 0 1 0 404,179.5" stroke="#2e030b" stroke-width="1.2"/>
<path d="M399.6,136.5 A45.3,45.3 0 0 1 474.7,124.6" stroke="#ffa3b1" stroke-width=".7" opacity=".75" stroke-linecap="round"/>
<path d="M541,124.6 C534,117.6 527,115.2 524,113.8 C504,107.4 474,102.6 441,101.4 C410,100.3 372,99.3 338.6,98.9" stroke="#ffe0e5" stroke-width=".9" stroke-linecap="round" transform="translate(0 .7)"/>
<path d="M193.2,72 C187,71.2 179,74.1 170,77.8 C160,82.6 148,87.2 136,89.6 C122,92.4 108,94.6 98,95.2 C86,95.6 74,96.4 64,97.8 C59.6,98.6 56.6,99.4 52,99.4" stroke="#ffe0e5" stroke-width=".9" stroke-linecap="round" transform="translate(0 .7)"/>
<path d="M360,100.4 C400,101 440,102 476,103.8" stroke="url(#rd-spec)" stroke-width="1.5" stroke-linecap="round"/>
<path d="M120,93.4 C140,90.6 156,85 170,79" stroke="url(#rd-spec)" stroke-width="1.3" stroke-linecap="round"/>
<path d="M200.6,98.4 C184,96.6 160,94.6 138,94.4 C122,94.3 108,94.8 98,95.2" stroke="#ffd0d7" stroke-width=".6" opacity=".9"/>
<path d="M200.6,98.4 C184,96.6 160,94.6 138,94.4 C122,94.3 108,94.8 98,95.2" stroke="#5a0816" stroke-width=".6" opacity=".6" transform="translate(0 .9)"/>
<path d="M190,99.4 C170,97.4 150,96.2 132,96.2 C112,96.2 92,97.2 74,99 C66,99.8 60,100.6 54,101.6" stroke="url(#rd-spec)" stroke-width=".7"/>
<use href="#rd-inl" fill="url(#rd-carbon)"/><use href="#rd-inl" fill="url(#rd-cf)" opacity=".5"/>
<path d="M186.8,73.2 C191.6,72 196.6,73.5 198.7,77.2" stroke="#b6bdc6" stroke-width=".5" stroke-linecap="round"/>
<path d="M393.4,134.8 C360,133.4 310,130.6 262,127.4 C246,126.3 232,124.8 220,122.2 C204,118.8 192,114 182,107.8" stroke="#ffd6dc" stroke-width=".8" stroke-linecap="round"/>
<path d="M393.4,134.8 C360,133.4 310,130.6 262,127.4 C246,126.3 232,124.8 220,122.2 C204,118.8 192,114 182,107.8" stroke="#3a0410" stroke-width=".7" stroke-linecap="round" opacity=".7" transform="translate(0 1)"/>
<path d="M200.6,98 L338.6,99.2" stroke="#0e1013" stroke-width="1"/>
<path d="M201,98.8 L338,100" stroke="#ffa3b2" stroke-width=".5" opacity=".9"/>
<path d="M262,127.8 C240,126 220,122.6 206,118.4 C198,116 192,112.6 187.4,109 L186,150.6 C206,151 230,150.6 250,148.8 C258,142 262,135 262,127.8 Z" fill="url(#rd-scoop)"/>
<path d="M240.6,126.6 C222,124.6 204,120.4 191.4,115 C188,122.6 187.4,133.4 189,146.4 C202,148.2 218,148.2 230.6,146.2 C236.6,140.4 240,133.6 240.6,126.6 Z" fill="url(#rd-intake)" stroke="#1a0207" stroke-width=".6"/>
<path d="M190.4,127.6 C206,129.6 222,130.4 239.4,130 M189,142.4 C204,144 218,144.2 233.4,143" stroke="#2a2e34" stroke-width=".9"/>
<path d="M190.4,127.6 C206,129.6 222,130.4 239.4,130 M189,142.4 C204,144 218,144.2 233.4,143" stroke="#c3cad3" stroke-width=".4" opacity=".35" transform="translate(0 -.6)"/>
<path d="M189.6,134.6 C206,136.6 222,137 237.6,135.8 L236.8,138.6 C222,139.8 206,139.6 189.4,137.8 Z" fill="url(#rd-blade)"/>
<path d="M189.6,134.6 C206,136.6 222,137 237.6,135.8" stroke="#ffa5b4" stroke-width=".5"/>
<path d="M189.4,138.6 C206,140.4 222,140.6 236.4,139.4" stroke="#000" stroke-width=".7" opacity=".5"/>
<path d="M188.8,147.2 C202,149.2 218,149.2 231.4,147.2" stroke="#ff9aaa" stroke-width=".7" opacity=".8"/>
<path d="M389.6,142.1 A53,53 0 0 1 404.2,116.8 L406,118.7 A50.4,50.4 0 0 0 392.1,142.8Z" fill="#08090b" stroke="#08090b" stroke-width=".8" stroke-linejoin="round"/>
<path d="M391.6,140.8 A51.4,51.4 0 0 1 404,119.2" stroke="#3a3f47" stroke-width=".6"/>
<path d="M388.6,141.9 A54,54 0 0 1 403.5,116.1" stroke="#ffaab7" stroke-width=".5" opacity=".8"/>
<path d="M86,151.3 A53,53 0 0 1 94.9,125.3 L97.1,126.8 A50.4,50.4 0 0 0 88.6,151.4Z" fill="#08090b" stroke="#08090b" stroke-width=".8" stroke-linejoin="round"/>
<path d="M87.8,149.6 A51.4,51.4 0 0 1 95.3,127.7" stroke="#3a3f47" stroke-width=".6"/>
<path d="M85,151.2 A54,54 0 0 1 94.1,124.7" stroke="#ffaab7" stroke-width=".5" opacity=".8"/>
<path d="M352.4,99.4 C352.6,120 351.4,150 349.6,178.8" stroke="#3a0410" stroke-width=".7"/>
<path d="M353.2,99.6 C353.4,120 352.2,150 350.4,178.8" stroke="#ff9fae" stroke-width=".35" opacity=".55"/>
<path d="M217,98.4 C219,106 221,114 223.2,123.4 M226.4,147.4 C228,158 229.4,168 230.6,178.8" stroke="#3a0410" stroke-width=".7"/>
<path d="M238,109.2 L256,109.6" stroke="#2a030a" stroke-width="1.5" stroke-linecap="round"/>
<path d="M238.4,110.4 L255.6,110.8" stroke="#ffb7c2" stroke-width=".45" stroke-linecap="round"/>
<path d="M405,176.4 L190,176.4 C186.2,176.4 184,178.2 184.2,180.8 L184.6,184.3 L400,184.7 C405,184.7 404.4,182 405,178.4 Z" fill="url(#rd-carbon)"/>
<path d="M404,176.6 L190,176.6" stroke="#9aa1ab" stroke-width=".5"/>
<path d="M186,184.7 L400,185.1" stroke="#9aa3ad" stroke-width=".5" opacity=".35"/>
<path d="M49,165.6 C56,172.4 70,179.1 86,179.5 L101.5,179.5 L100.7,183 L58,182.8 C51,182.4 46.4,180.6 44,177.6 C42.4,175.6 42,172.6 42.6,169.4 C45,168.6 47.2,167.4 49,165.6 Z" fill="url(#rd-carbon)"/>
<path d="M43.4,172 C50,177.8 66,180.4 99.9,180.6" stroke="#8a919b" stroke-width=".45"/>
<path d="M56,182 L58.6,184.6 L95.9,184.8 L97.9,182.6 Z" fill="#101215" stroke="#5f6670" stroke-width=".4"/>
<path d="M44.4,178.4 C47,181 52,182.8 58,183.2 M58.6,185 L95.9,185.2" stroke="#9aa3ad" stroke-width=".5" opacity=".35"/>
<path d="M50.6,162.8 L57.6,166" stroke="#8a0d22" stroke-width="1.5" stroke-linecap="round"/>
<path d="M50.8,162.3 L57.8,165.5" stroke="#ff6b80" stroke-width=".4" stroke-linecap="round"/>
<path d="M479.6,179.6 L541.2,179.5 C545,179.5 548.6,180 551.2,180.6 L551,182.6 L484.1,183.8 Z" fill="url(#rd-carbon)"/>
<path d="M482.1,179.8 L550.6,180.6" stroke="#a3aab4" stroke-width=".45"/>
<path d="M484.1,184.2 L551,183" stroke="#9aa3ad" stroke-width=".5" opacity=".35"/>
<path d="M524.6,159.6 C532,158.2 540,158 547.1,158.6 C547.3,162.4 546.9,166 545.8,169.4 C538,170 530,170 525,168.8 C523.2,166 523.2,162.4 524.6,159.6 Z" fill="url(#rd-intake)"/>
<path d="M524,164.2 C532,163.8 540,163.8 547.2,164.2" stroke="#2a2e34" stroke-width="1.2"/>
<path d="M524,163.6 C532,163.2 540,163.2 547.2,163.6" stroke="#8a919b" stroke-width=".35"/>
<path d="M524.4,159.2 C532,157.8 540,157.6 547,158.2" stroke="#ffb0bc" stroke-width=".5" opacity=".8"/>
<path d="M512.4,117.8 C523,120.6 535,125.2 545.2,131.6 L546,135 C535.4,129.6 523,125.2 512,121.4 Z" fill="#101215"/>
<path d="M512.4,117.8 C523,120.6 535,125.2 545.2,131.6" stroke="#ffd0d7" stroke-width=".4" opacity=".8"/>
<path d="M514,119.8 C524,122.8 535.4,127 545,132.6" stroke="#cfe6ff" stroke-width="2.6" stroke-linecap="round" opacity=".5" filter="url(#rd-glow)"/>
<path class="ve-drl" d="M514,119.8 C524,122.8 535.4,127 545,132.6" stroke="#ffffff" stroke-width="1.1" stroke-linecap="round"/>
<path d="M30.9,92.4 L31.4,95.6 L34.2,97.6" stroke="#2a030a" stroke-width=".8" opacity=".7"/>
<path d="M34.2,98.6 C40,100.6 48,101.8 60,102.4" stroke="#2a030a" stroke-width="1.2" opacity=".45" filter="url(#rd-glow)"/>
<path d="M34.4,98 C41,100 49,101.2 62,101.8 C49,102.8 41,103 34.2,102.4 Z" fill="#170306" stroke="#ff8a9c" stroke-width=".3" stroke-opacity=".6"/>
<path d="M35,99.8 C41,101 47,101.6 56,101.9" stroke="#ff3550" stroke-width="3" stroke-linecap="round" opacity=".45" filter="url(#rd-glow)"/>
<path class="ve-tail" d="M35,99.8 C41,101 47,101.6 56,101.9" stroke="#ff2a45" stroke-width="1.3" stroke-linecap="round"/>
<path d="M30.8,92 C34,92.2 38.2,95 43,97.6 C38.6,96.8 34.4,94.8 31,93.6 Z" fill="#ffb0bd" opacity=".45"/>
<path d="M53,99.6 C48.4,99.5 45.6,98.9 43,97.6 C38.2,95 34,92.2 30.8,92" stroke="#fff4f6" stroke-width=".8" stroke-linecap="round"/>
<path d="M281.6,65.2 L290.6,65.4 L355.4,99.3 L318.6,99.2 C309,90 296,76.6 283.4,66.6 Z" fill="url(#rd-glass)"/>
<path d="M291,68.6 L318,94.4 M298.6,70.4 L331.6,96.6" stroke="#fff" stroke-width=".9" opacity=".4" stroke-linecap="round"/>
<path d="M283.4,66.6 C296,76.6 309,90 318.6,99.2" stroke="#0d0f12" stroke-width=".6" opacity=".6"/>
<path d="M354.6,99.2 L289.6,65.4" stroke="#0d0f12" stroke-width="1.4" stroke-linecap="round"/>
<path d="M279.6,64.6 L290.2,64.9 L291,66.4 L281.4,67.2 Z" fill="#0d0f12"/>
<path d="M353.2,97.6 L289.6,64.2 L280.6,64.2" stroke="#b9c1ca" stroke-width=".45" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M330.4,99 L328.4,93.6 L331,93.4 L333.4,99 Z" fill="#111316"/>
<path d="M315.4,90 C315.6,88.2 317.2,87.2 319.6,87.1 L328.4,87.3 C332.2,87.5 334.6,89.4 334.6,91.6 C334.6,93.8 332.2,95.3 328.4,95.3 L319.2,95.1 C316.8,95 315.4,93.8 315.3,92.4 Z" fill="url(#rd-carbon)" stroke="#69707a" stroke-width=".4"/>
<path d="M318,88.4 C322,88 328,88.1 331.6,88.8" stroke="#d2d8df" stroke-width=".55" stroke-linecap="round"/>
__PLUG__
`;
  const RD_PLUG = `
<ellipse cx="594" cy="195.4" rx="14" ry="1.4" fill="#0d1526" opacity=".16" filter="url(#rd-b1)"/>
<rect x="591.8" y="34" width="3.4" height="40" rx="1.2" fill="url(#rd-conduit)"/>
<rect x="572.5" y="72" width="42" height="64" rx="9.5" fill="url(#rd-box)" stroke="#8d95a0" stroke-width=".8" filter="url(#rd-boxsh)"/>
<rect x="576" y="75.5" width="35" height="57" rx="7" fill="url(#rd-boxglass)"/>
<path d="M577.6,82 C580,77.5 584,77 590,77 L603,77 L583,130 C579.6,130 577.6,128 577.6,125 Z" fill="#fff" opacity=".07"/>
<circle cx="593.5" cy="98" r="8.2" stroke="#56606d" stroke-width="1.1"/>
<circle cx="593.5" cy="98" r="8.2" stroke="#c9d1db" stroke-width="1.1" stroke-dasharray="9 43" stroke-linecap="round" transform="rotate(-140 593.5 98)"/>
<path d="M594.6,92.5 L590.8,98.6 L593.6,98.6 L592.4,103.5 L596.2,97.3 L593.4,97.3 Z" fill="#8e98a6"/>
<rect class="ve-box-led" x="585" y="119" width="17" height="2.6" rx="1.3" fill="#a855c7"/>
<rect x="589" y="136" width="9" height="4.5" rx="1.5" fill="#2a2e34"/>
<rect x="617.5" y="90" width="7.5" height="18" rx="2.6" fill="url(#rd-box)" stroke="#8d95a0" stroke-width=".7"/>
<rect x="619.6" y="93.5" width="3.3" height="9" rx="1.4" fill="#1d2127"/>
<path class="ve-cable" d="M593.5,138 C593.5,162 591,187 577,188 C563,189 563,160 557,151.4" stroke="#24282e" stroke-width="3.4" stroke-linecap="round"/>
<path d="M593.5,138 C593.5,162 591,187 577,188 C563,189 563,160 557,151.4" stroke="#8a919c" stroke-width=".7" stroke-linecap="round" opacity=".8" transform="translate(-.6 -.8)"/>
__FLOW__
<rect x="528.4" y="137.4" width="12.4" height="10" rx="2.4" fill="#08090b" stroke="#3a0410" stroke-width=".5"/>
<rect x="529.4" y="138.4" width="10.4" height="8" rx="1.8" stroke="#a855c7" stroke-width=".5" opacity=".9"/>
<path d="M541,137.6 L547.4,133.6 C548.2,133.2 548.8,133.6 548.8,134.4 L549.2,143.2 C549.2,144 548.8,144.6 548.2,144.8 L541,147.2 Z" fill="url(#rd-flap)" stroke="#4e0613" stroke-width=".5" stroke-linejoin="round"/>
<path d="M548.3,134.4 L548.7,143.4 M541.6,137.2 L547.4,133.6" stroke="#ffc2cb" stroke-width=".5" stroke-linecap="round"/>
<path d="M540.9,137.8 L540.9,147" stroke="#1a0207" stroke-width="1.1"/>
<path d="M530.6,139.2 L536.8,139 C540.2,139 542.8,140.2 545,142.4 L557,149.2 C558.8,150.4 558.8,152.8 557.4,154.2 L555.8,155.6 C554.4,156.6 552.8,156.6 551.4,155.6 L542,149 C540,147.6 538,146.4 535.8,146.2 L530.6,146 Z" fill="url(#rd-plug)" stroke="#2a2e34" stroke-width=".5" stroke-linejoin="round"/>
<path d="M532,140.4 L536.8,140.2 C539.6,140.2 541.8,141.2 543.8,143 L555.4,149.6" stroke="#fff" stroke-width=".6" stroke-linecap="round"/>
<path d="M545,144.8 L549.4,147.6" stroke="#a855c7" stroke-width="1.3" stroke-linecap="round"/>
`;
  const RD_FLOW = `<path class="ve-flow" d="M593.5,138 C593.5,162 591,187 577,188 C563,189 563,160 557,151.4" stroke="#a855c7" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="2 9"/>`;
  const RD_CLOSED = `<rect x="528.4" y="137.4" width="12.4" height="10" rx="2.4" stroke="#3a0410" stroke-width=".6" opacity=".8"/>
<path d="M529.6,147.8 L539.6,147.8 C540.6,147.8 541.2,147.2 541.2,146.4" stroke="#ff9fae" stroke-width=".35" opacity=".6"/>`;

  // Illustration au choix (Réglages) : roadster sport (par défaut) ou la Kia e-Niro
  const car = (charging, plugged) => (BZ.ui.carArt === "eniro"
    ? h`<svg class="ve-car ${charging ? "is-charging" : ""}" viewBox="0 0 640 220" role="img" aria-label="Kia e-Niro${plugged ? ", branchée à la borne" : ""}">
      ${CAR_ART}
      ${plugged ? h`<g class="ve-plug">${CAR_PLUG[0]}${charging ? CAR_FLOW : ""}${CAR_PLUG[1]}</g>` : ""}
    </svg>`
    : h`<svg class="ve-car is-roadster ${charging ? "is-charging" : ""}" viewBox="0 0 640 220" fill="none" role="img" aria-label="Roadster électrique${plugged ? ", branché à la borne" : ""}">
      ${RD_ART.replace("__PLUG__", plugged ? `<g class="ve-plug">${RD_PLUG.replace("__FLOW__", charging ? RD_FLOW : "")}</g>` : RD_CLOSED)}
    </svg>`);

  /* ─── État de la recharge (une seule source de vérité pour le hero) ── */
  function chargeState() {
    const L = BZ.live(), soc = num(C.voiture_soc), lim = num(C.voiture_limite_pct), km = num(C.voiture_autonomie_km);
    const added = L.plugged ? clamp(num(C.session_soc), 0, soc) : 0, start = clamp(soc - added, 0, soc);
    const sol = num(C.session_sol_kwh), res = num(C.session_res_kwh), kwh = sol + res;
    const mins = num(C.voiture_minutes_restantes), fin = new Date(Date.now() + mins * 6e4);
    const full = L.plugged && soc >= lim, t = BZ.tariffNow(), offPeak = isOn(C.voiture_heures_creuses), scheduled = isOn(C.voiture_programmee);
    let state, tone, why;
    if (L.charging) { state = "En charge"; tone = "ev"; why = null; }
    else if (full) { state = "Charge terminée"; tone = "good"; why = `limite de ${fmt.n(lim)} % atteinte`; }
    else if (L.plugged && offPeak && t.key === "hp") { state = "En attente"; tone = "hc"; why = `heures creuses à ${fmt.time(t.changeAt)}`; }
    else if (L.plugged && scheduled) { state = "En attente"; tone = "hc"; why = "charge programmée dans la voiture"; }
    else if (L.plugged) { state = "Branchée"; tone = "neutral"; why = "prête à charger"; }
    else { state = "Débranchée"; tone = "neutral"; why = null; }
    // km par % : estimation de la voiture si la batterie n'est pas presque vide, sinon capacité / consommation
    const kmPerPct = soc >= 15 && km > 0 ? clamp(km / soc, 2.5, 7) : (C.voiture_capacite_kwh / (C.voiture_conso_kwh_100km || 16.5));
    return { L, soc, lim, km, added, start, sol, res, kwh, mins, fin, full, state, tone, why, kmPerPct };
  }
  const dur = (m) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`);

  /* ─── Barre de batterie : remplissage unique + repère + drapeau de limite ── */
  function battery(S) {
    const { soc, lim, start, L } = S, low = soc <= 20;
    return h`<div class="ve-bat ${L.charging ? "is-charging" : ""} ${low ? "is-low" : ""}" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(soc)}"
        aria-label="Batterie ${fmt.n(soc)} %, ${fmt.n(S.km)} km d'autonomie, limite ${fmt.n(lim)} %${S.added ? `, ${fmt.n(S.added)} % ajoutés depuis le branchement` : ""}">
      <div class="ve-bat-t">
        <span class="ve-seg is-base" style="--a:0%;--b:${start}%"></span>
        ${S.added ? h`<span class="ve-seg is-add" style="--a:${start}%;--b:${soc}%"></span>` : ""}
        ${soc < lim ? h`<span class="ve-seg is-room" style="--a:${soc}%;--b:${lim}%"></span>` : ""}
      </div>
      <b class="ve-lim" style="--x:${lim}%"><span>${fmt.n(lim)} %</span></b>
      <span class="ve-knob" style="--x:${soc}%"><span>${fmt.n(soc)} % · ${fmt.n(S.km)} km</span></span>
    </div>`;
  }

  // Déroulé de la charge (sous la barre) ; débranchée : la dernière recharge
  function timeline(S) {
    if (!S.L.plugged) {
      const last = BZ.chargeDays(14).filter((d) => d.kwh).pop();
      if (!last) return "";
      const d = last.date.toDateString(), when = d === new Date().toDateString() ? "aujourd'hui" : d === new Date(Date.now() - 864e5).toDateString() ? "hier" : fmt.date(last.date, { weekday: "long", day: "numeric", month: "long" });
      // Texte d'un seul tenant : sinon l'écart du flex s'insère entre les morceaux (« 8,9 kWh  , 76 % »)
      return h`<p class="ve-last">${icon("clock")}<span>Dernière recharge ${when} · <b>${fmt.kwhText(last.kwh)}</b>, ${fmt.n(last.sun * 100)} % solaire</span></p>`;
    }
    const startAt = BZ.dt(C.session_debut), share = S.kwh ? S.sol / S.kwh : 0;
    const endKm = S.kmPerPct * S.lim;
    return h`<ol class="ve-steps" aria-label="Déroulé de la recharge">
      <li class="is-done"><i></i><strong>Branchée à ${fmt.time(startAt)}</strong><small>${fmt.n(S.start)} %</small></li>
      <li class="is-now"><i></i><strong>+${fmt.n(S.added)} % · ${fmt.kwhText(S.kwh)}</strong><small><span data-tone="solar">${fmt.n(share * 100)} % soleil</span><span class="ve-res"> · ${fmt.kwhText(S.res)} réseau</span></small></li>
      <li><i></i><strong>${S.L.charging ? `Fin vers ${fmt.time(S.fin)}` : S.full ? "Terminée" : "Objectif"}</strong><small>${fmt.n(S.lim)} % · ≈ ${fmt.n(endKm)} km</small></li>
    </ol>`;
  }

  /* ─── Commandes à distance : pupitre de quatre tuiles ─────────────────
     Tout passe par le cloud Kia Connect : Kia accepte la commande (5 à 30 s), puis la voiture l'applique et
     ne le confirme qu'au relevé suivant (jusqu'à 2 min). Chaque tuile dit l'état actuel de la voiture ;
     pendant une commande, un trait fait le tour de la tuile (envoi, puis application), laisse place à un
     anneau vert et une coche quand la voiture confirme, ou la tuile vire au rouge en cas d'échec (appuyer
     dessus relance la même commande). La ligne du pupitre raconte l'étape en clair avec les secondes
     écoulées : c'est elle que lisent les lecteurs d'écran. */
  const secs = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return s < 60 ? `${s} s` : `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")}`; };
  const remain = (until) => String(Math.max(0, Math.ceil((until - Date.now()) / 1000)));
  const LATE = 15000;   // au-delà, on rassure : Kia met parfois 2 minutes
  const running = (t) => !!t && (t.phase === "send" || t.phase === "wait");
  // Secondes qui défilent sans redessiner la page (même principe que l'avancement du morceau)
  setInterval(() => {
    document.querySelectorAll("[data-since]").forEach((el) => {
      const ms = Date.now() - +el.dataset.since, txt = secs(ms);
      if (el.textContent !== txt) el.textContent = txt;
      const late = el.closest("[data-late]"); if (late) late.classList.toggle("is-late", ms >= LATE);
    });
    document.querySelectorAll("[data-until]").forEach((el) => { const txt = remain(+el.dataset.until); if (el.textContent !== txt) el.textContent = txt; });
  }, 250);

  // Teinte d'une commande en cours (déverrouiller = ambre) et ce qu'elle vise, dit aux lecteurs d'écran
  const TONE = { lock: "good", clim: "battery", charge: "ev", refresh: "ev" };   // relevé : violet de la voiture (le corail ressemblerait à une erreur)
  const toneOf = (t) => (t.key === "lock" && t.to === "unlocked" ? "warn" : TONE[t.key]);
  const VERB = { lock: (to) => (to === "unlocked" ? "Déverrouillage" : "Verrouillage"), clim: (to) => (to ? "Démarrage du climat" : "Arrêt du climat"),
    charge: (to) => (to ? "Démarrage de la recharge" : "Arrêt de la recharge"), refresh: () => "Actualisation" };
  const actOf = (key) => `car-${key}`;   // action d'app.js qui (re)lance la commande
  // Texte long et texte court : une tuile ou une ligne étroite (requêtes de conteneur) garde le court
  const xs = (long, short) => h`<span class="ve-x">${long}</span><span class="ve-xs">${short}</span>`;
  const lc = (s) => s.charAt(0).toLowerCase() + s.slice(1);   // « Envoi à Kia… » → « envoi à Kia… » (Kia garde sa majuscule)
  // Relance de la même commande (cible explicite) : la tuile en échec et « Réessayer » la portent
  const target = (t) => (t.to != null ? `data-to="${t.to}"` : "");

  function controls(S) {
    const { L } = S, busy = BZ.slowBusy(), armed = BZ.ui.armed === "unlock" && !busy;
    const locked = st(C.voiture_verrou) === "locked", clim = isOn(C.voiture_clim), ago = fmt.ago(st(C.voiture_maj));
    const charge = L.charging ? "En charge" : !L.plugged ? "Débranchée" : S.full ? "Limite atteinte" : S.state === "En attente" ? S.state : "Arrêtée";
    const T = [
      { key: "lock", act: "car-lock", label: "Verrou", aria: "Verrou des portes", ic: locked ? "lock" : "unlock", tone: locked ? "good" : "warn", on: locked,
        state: locked ? "Verrouillée" : "Ouverte", hint: locked ? "Verrouillée · appuie deux fois pour déverrouiller" : "Ouverte · appuie pour verrouiller" },
      { key: "clim", act: "car-clim", label: "Climat", aria: "Climatisation", ic: "snow", tone: TONE.clim, on: clim,
        state: clim ? "En marche" : "Arrêté", hint: clim ? "Climatisation en marche · appuie pour l'arrêter" : "Appuie pour lancer la climatisation" },
      { key: "charge", act: "car-charge", label: "Recharge", aria: "Recharge", ic: L.plugged ? "bolt" : "plug", tone: TONE.charge, on: L.charging,
        off: !L.plugged || (S.full && !L.charging), said: lc(charge), state: S.full && !L.charging && L.plugged ? xs(charge, "Terminée") : charge,
        hint: !L.plugged ? "Branche la voiture pour charger" : S.full ? `Limite de ${fmt.n(S.lim)} % atteinte` : L.charging ? "En charge · appuie pour arrêter" : "Appuie pour démarrer la recharge" },
      // État : l'âge du dernier relevé (le mot « relevé » est déjà dans l'en-tête de la page)
      { key: "refresh", act: "car-refresh", label: "Actualiser", aria: "Demander un relevé à la voiture", ic: "refresh", tone: TONE.refresh,
        state: fmt.cap(ago), said: `dernier relevé ${ago}`, hint: "Réveille la voiture pour un relevé frais (lent : à garder pour quand tu en as besoin)" },
    ];
    // Dernier résultat affiché (confirmé ou échec) : le plus récent
    const done = T.map((x) => BZ.slowOf(x.key)).filter((t) => t && !running(t)).sort((a, b) => b.tEnd - a.tEnd)[0];
    const until = (BZ.ui.armedAt || Date.now()) + 4000;

    const tile = (x) => {
      const t = BZ.slowOf(x.key);
      // Étape de la tuile : à confirmer > en cours > confirmé > impossible > occupé ailleurs > échec > repos
      const ph = armed && x.key === "lock" ? "armed" : running(t) ? t.phase : t && t.phase === "ok" ? "ok" : x.off ? "off" : busy ? "held" : t ? t.phase : "idle";
      const tone = ph === "armed" ? "warn" : ph === "fail" ? "bad" : ph === "ok" ? "good" : running(t) ? toneOf(t) : x.tone;
      const ic = ph === "ok" ? icon("check", "ve-tick") : ph === "fail" ? icon("alert")
        : ph === "armed" ? h`<b class="ve-act-n" data-until="${until}">${remain(until)}</b>`
        : icon(x.key === "lock" && t ? (t.to === "unlocked" ? "unlock" : "lock") : x.ic);
      // Sous-titre : l'étape en cours, sinon l'état actuel ; la raison d'un échec et « Réessayer » sont sur la ligne du pupitre
      const sub = { send: xs("Envoi à Kia…", "Envoi…"), wait: x.key === "refresh" ? "Réveil…" : "En cours…", fail: "Échec", armed: xs("Appuie encore", "Confirme") }[ph] || x.state;
      const say = { send: "envoi à Kia…", wait: x.key === "refresh" ? "réveil de la voiture…" : "en cours d'application…", fail: "échec, appuie pour réessayer",
        armed: "appuie encore pour confirmer" }[ph] || x.said || lc(x.state);
      const title = { send: "Commande envoyée à Kia Connect : patiente, la voiture répond en 30 s à 2 min", wait: "Kia a accepté : la voiture applique la commande",
        held: "Une commande est déjà en cours avec la voiture : attends qu'elle se termine", fail: `${t && t.why}. Appuie pour réessayer`,
        armed: "Appuie encore dans les 4 secondes pour déverrouiller la voiture" }[ph] || x.hint;
      // Deux tracés sur le pourtour : la comète (envoi, application) et l'anneau (confirmé, compte à rebours)
      return h`<button type="button" class="ve-act" data-st="${ph}" data-k="${x.key}" data-tone="${tone}" data-act="${x.act}" ${ph === "fail" ? target(t) : ""}
          ${x.on != null ? `aria-pressed="${String(!!x.on)}"` : ""} ${ph === "off" ? "disabled" : ""} ${ph === "held" ? 'aria-disabled="true"' : ""} ${running(t) ? 'aria-busy="true"' : ""}
          aria-label="${esc(`${ph === "armed" ? "Confirmer le déverrouillage" : x.aria}, ${say}`)}" title="${esc(title)}">
        <svg class="ve-act-r" aria-hidden="true"><rect class="ve-orb" width="100%" height="100%" rx="13" pathLength="100"/><rect class="ve-ring" width="100%" height="100%" rx="13" pathLength="100"/></svg>
        <span class="ve-act-i">${ic}</span>
        <span class="ve-act-t"><b class="ve-act-l">${ph === "armed" ? xs("Déverrouiller ?", "Ouvrir ?") : x.label}</b><small class="ve-act-s">${sub}</small></span>
      </button>`;
    };

    // Ligne du pupitre : l'étape en clair, puis les secondes écoulées ; après un échec, la raison et « Réessayer ».
    // Les lecteurs d'écran entendent d'abord la commande concernée (« Démarrage du climat. Envoi à Kia Connect… »)
    const last = !armed && (busy || done);
    let what = last ? h`<span class="sr">${VERB[last.key](last.to)}. </span>` : "", line, tone = "neutral", aside = "", tip = "";
    if (armed) {
      // La tuile dit déjà « Déverrouiller ? · Appuie encore » : la ligne dit ce qui se passe sinon
      what = h`<span class="sr">Appuie encore sur le verrou pour déverrouiller. </span>`; line = "Sans confirmation, elle reste verrouillée"; tone = "warn";
    } else if (busy) {
      tone = toneOf(busy);
      line = h`<span class="ve-acts-now">${busy.phase === "send" ? "Envoi à Kia Connect…" : busy.key === "refresh" ? "Réveil de la voiture…" : "La voiture applique la commande…"}</span><span class="ve-acts-late">${xs("Normal : Kia met parfois 2 min", "Kia met parfois 2 min")}</span>`;
      aside = h`<span class="ve-acts-c" data-since="${busy.t0}" aria-hidden="true">${secs(Date.now() - busy.t0)}</span>`;
    } else if (done && done.phase === "ok") {
      tone = "good"; line = `${done.key === "refresh" ? "Relevé reçu" : "Confirmé par la voiture"} en ${secs(done.tEnd - done.t0)}`;
    } else if (done) {
      // La raison vient de Kia ou de Home Assistant : échappée. « Réessayer » relance la même commande (le déverrouillage
      // redemande sa double touche) puis rend le focus à sa tuile ; la tuile reste l'autre façon de réessayer
      tone = "bad"; line = esc(done.why); tip = done.why;
      if (!T.find((x) => x.key === done.key).off)
        aside = h`<button type="button" class="ve-acts-retry" data-act="${actOf(done.key)}" ${target(done)} data-refocus="${esc(`.ve-act[data-k="${done.key}"]`)}"
          title="${esc(`Relancer : ${lc(VERB[done.key](done.to))}`)}">${icon("refresh")}Réessayer</button>`;
    } else { line = xs("Commandes via Kia Connect", "Via Kia Connect"); aside = h`<span class="ve-acts-d" title="Délai habituel d'une commande à distance">30 s à 2 min</span>`; }
    const late = busy && Date.now() - busy.t0 >= LATE;
    return h`<div class="ve-acts" data-tone="${tone}">
      <p class="ve-acts-h ${busy ? "is-run" : ""} ${late ? "is-late" : ""}" ${busy ? "data-late" : ""}><i aria-hidden="true"></i><span class="ve-acts-s" role="status" aria-live="polite" ${tip ? `title="${esc(tip)}"` : ""}>${what}${line}</span>${aside}</p>
      <div class="ve-acts-g" role="group" aria-label="Commandes à distance">${T.map(tile)}</div>
    </div>`;
  }

  function hero() {
    const S = chargeState(), { L } = S, R = BZ.slowOf("refresh");
    const meta = L.charging ? h`Encore <b>${dur(S.mins)}</b> à ${fmt.powerText(L.car)}` : S.why ? fmt.cap(S.why) : h`Dernier trajet <b>${fmt.ago(BZ.dt(C.voiture_dernier_trajet))}</b>`;
    // Relevé forcé en cours : les chiffres « chatoient » ; à l'arrivée des valeurs fraîches, un bref éclat
    return h`<section class="card ve-hero ${L.charging ? "is-charging" : ""} ${running(R) ? "is-reading" : ""} ${R && R.phase === "ok" ? "is-fresh" : ""}" aria-label="État de la voiture">
      <div class="ve-hero-l">
        <div class="ve-status">${BZ.pill(S.state, S.tone, L.charging)}</div>
        <div class="ve-soc ${S.soc <= 20 ? "is-low" : ""}">${val([fmt.n(S.soc), "%"])}</div>
        <p class="ve-range"><b>${fmt.n(S.km)} km</b> d'autonomie</p>
        <p class="ve-meta">${meta}</p>
        ${controls(S)}
      </div>
      <div class="ve-hero-r">
        <div class="ve-art">${BZ.segmented({ name: "carArt", label: "Illustration de la voiture", value: BZ.ui.carArt === "eniro" ? "eniro" : "roadster", options: [["roadster", "Roadster"], ["eniro", "e-Niro"]] })}</div>
        ${car(L.charging, L.plugged)}
        ${battery(S)}
        ${timeline(S)}
        <ul class="ve-chips">
          <li><span>Batterie 12 V</span><b>${fmt.n(num(C.voiture_12v_pct))} %</b></li>
          ${L.plugged ? h`<li><span>Dernier trajet</span><b>${fmt.ago(BZ.dt(C.voiture_dernier_trajet))}</b></li>` : ""}
        </ul>
      </div>
    </section>`;
  }

  /* ─── Recharges de la période ───────────────────────────────────────── */
  const gridMix = () => (isOn(C.voiture_heures_creuses) ? { hsc: 0.72, hc: 0.28, hp: 0 } : { hsc: 0.62, hc: 0.23, hp: 0.15 });   // même règle que core.chargeMix
  const costOf = (t) => {
    // Home Assistant : kWh du réseau par tarif, lus heure par heure dans l'historique de la borne (inconnus tant qu'ils arrivent)
    if (BZ.hist) return (t.evHp ?? NaN) * BZ.TARIFS.hp.price() + (t.evHc ?? NaN) * BZ.TARIFS.hc.price() + (t.evHsc ?? NaN) * BZ.TARIFS.hsc.price();
    const g = Math.max(0, (t.ev || 0) - (t.evSun || 0)), m = gridMix(); return g * (m.hsc * num(C.tarif_hsc) + m.hc * num(C.tarif_hc) + m.hp * num(C.tarif_hp));
  };
  // Pas de recharge : 0 ; Home Assistant, historique pas encore arrivé : inconnu (« — »), pas 0
  const none = (t) => (BZ.hist && !Number.isFinite(t.ev) ? NaN : 0);
  // Home Assistant : historique de la borne absent (pas de statistiques) ou en chargement : on le dit, sans dessiner de jours vides
  const evWait = (days) => {
    const HB = BZ.hist; if (!HB) return null;
    const diag = btn({ label: "Diagnostic", ic: "alert", act: "open-sheet", args: { sheet: "diag" }, size: "sm" });
    if (HB.has("voiture") === false) return { ic: "clock", title: "Pas d'historique de recharge", text: "Les compteurs de la borne n'ont pas de statistiques dans Home Assistant.", action: diag };
    return days.some((d) => d.loading) ? { ic: "clock", title: "Chargement…", text: "L'historique des recharges arrive de Home Assistant." } : null;
  };

  function stats() {
    const kind = BZ.ui.carPeriod, P = BZ.period(kind, "voiture"), T = P.total, Q = P.prevTotal, real = P.buckets.filter((b) => !b.forecast);
    // Home Assistant : l'écart compare la même durée, arrêtée à la même heure, sur les jours connus des deux côtés (Tc)
    const Tc = P.cmpTotal || T;
    const conso = C.voiture_conso_kwh_100km || 16.5, ess = (C.essence_l_100km || 6.5) * (C.essence_prix_l || 1.85);
    const per100 = (t) => (t.ev ? (costOf(t) / t.ev) * conso : none(t)), saved = (t) => (ess - per100(t)) * ((t.ev || 0) / conso);
    const share = (t) => (t.ev ? t.evSun / t.ev : none(t));
    const m = new Date().getMonth();
    const base = { semaine: "vs 7 j avant", mois: `vs ${BZ.MONTHS[(m + 11) % 12]} à date`, annee: `vs ${new Date().getFullYear() - 1} à date` }[kind];
    const cmp = P.cmp || {}, from = cmp.from ? new Date(`${cmp.from}T12:00:00`) : null;
    const vs = BZ.hist && BZ.hist.has("voiture") === false ? "historique indisponible"
      : cmp.none ? "pas de comparaison : historique incomplet" : cmp.partial ? `${base}, dès le ${fmt.date(from, { day: "numeric", month: "short" })}` : base;
    // Cumuls (courbes lisibles : pas de dents de scie entre jours avec et sans recharge)
    let e = 0, s = 0, c = 0;
    const add = (v) => (BZ.hist ? v : v || 0);   // Home Assistant : un jour inconnu rend le cumul inconnu (pas de courbe fausse)
    const cum = real.map((b) => { e += add(b.ev); s += add(b.evSun); c += costOf(b); return { e, share: e ? s / e : null, per100: e ? (c / e) * conso : null }; });
    return { kind, P, T, Q, Tc, real, conso, ess, per100, saved, share, vs, cum };
  }

  function kpis(S) {
    const { T, Q, Tc, per100, saved, share, vs, ess, cum } = S;
    return h`<div class="kpis">
      ${kpi({ label: "Énergie rechargée", ic: "bolt", tone: "ev", value: val(fmt.kwh(T.ev)), delta: delta(Tc.ev, Q.ev), vs, spark: BZ.spark(cum.map((x) => x.e), "ev") })}
      ${kpi({ label: "Part solaire", ic: "sun", tone: "solar", value: val([fmt.n(share(T) * 100), "%"]), delta: delta(share(Tc), share(Q), { unit: "pts" }), vs, spark: BZ.spark(cum.map((x) => x.share), "solar") })}
      ${kpi({ label: "Coût aux 100 km", ic: "euro", tone: "accent", value: val([fmt.n(per100(T), 2), "€"]), delta: delta(per100(Tc), per100(Q), { invert: true }), vs, spark: BZ.spark(cum.map((x) => x.per100), "accent") })}
      ${kpi({ label: "Économisé vs essence", ic: "leaf", tone: "good", value: val([fmt.n(saved(T), 0), "€"]), delta: "", vs: `essence : ${fmt.n(ess, 2)} € / 100 km`, spark: BZ.spark(cum.map((x, i) => saved({ ev: x.e, evSun: S.real.slice(0, i + 1).reduce((a, b) => a + (b.evSun || 0), 0) })), "good") })}
    </div>`;
  }

  function mixCard(S) {
    const M = BZ.chargeMix(S.kind), offPeak = isOn(C.voiture_heures_creuses);
    const rows = [["sol", "Soleil", "solar", "panneaux"], ["hsc", "Super creuses", "hsc", BZ.rangeLabel("hsc")], ["hc", "Heures creuses", "hc", BZ.rangeLabel("hc")], ["hp", "Heures pleines", "hp", BZ.rangeLabel("hp")]];
    return card({ cls: "ve-mix", title: "Par source", ic: "leaf", tone: "accent", aside: h`<span class="ve-total">${fmt.eur(M.cost)} payés</span>`, body: h`
      ${BZ.split(rows.map(([k, l, tone]) => ({ label: l, v: M.mix[k], tone })), { label: rows.map(([k, l]) => `${l} ${fmt.kwhText(M.mix[k])}`).join(", ") })}
      <ul class="ve-src">${rows.map(([k, l, tone, when]) => h`<li data-tone="${tone}" class="${!M.mix[k] ? "is-zero" : ""}"><i></i>
        <span><strong>${l}</strong><small>${k === "sol" ? "gratuit" : `${when} · ${fmt.n(M.price[k], 4)} €`}${k === "hp" && offPeak ? " · exclues" : ""}</small></span>
        <b>${fmt.kwhText(M.mix[k])}</b><em>${k === "sol" ? "0 €" : fmt.eur(M.mix[k] * M.price[k])}</em></li>`)}</ul>` });
  }

  function calendarCard() {
    // 4 semaines complètes + la semaine en cours, du lundi au dimanche (5 rangées)
    const wd = (new Date().getDay() + 6) % 7, days = BZ.chargeDays(29 + wd), maxDay = Math.max(...days.map((d) => d.kwh), 1);
    const wait = evWait(days);
    if (wait) return card({ cls: "ve-cal", title: "Jours de recharge", ic: "calendar", tone: "accent", body: BZ.empty(wait) });
    const n = days.filter((d) => d.kwh).length, sel = BZ.ui.calSel != null && days[BZ.ui.calSel] ? BZ.ui.calSel : days.length - 1, d = days[sel];
    const lab = (x) => fmt.cap(fmt.date(x.date, { weekday: "long", day: "numeric", month: "long" }));
    return card({ cls: "ve-cal", title: "Jours de recharge", ic: "calendar", tone: "accent", aside: h`<span class="ve-total">${n} en 5 semaines</span>`, body: h`
      <div class="ve-cal-g">
        ${["L", "M", "M", "J", "V", "S", "D"].map((x) => h`<span class="ve-wd" aria-hidden="true">${x}</span>`)}
        ${days.map((x, i) => h`<button type="button" class="ve-day ${x.kwh ? "" : "is-none"} ${i === days.length - 1 ? "is-today" : ""} ${i === sel ? "is-sel" : ""}" data-act="set" data-k="calSel" data-value="${i}"
          style="--a:${(0.25 + 0.75 * (x.kwh / maxDay)).toFixed(2)};--s:${Math.round(x.sun * 100)}%" aria-pressed="${String(i === sel)}"
          aria-label="${esc(`${lab(x)} : ${x.kwh ? `${fmt.kwhText(x.kwh)}, ${fmt.n(x.sun * 100)} % solaire` : "pas de recharge"}`)}">${x.date.getDate()}</button>`)}
      </div>
      <p class="ve-cal-d" aria-live="polite"><b>${lab(d)}</b>${d.kwh ? h` · ${fmt.kwhText(d.kwh)} · <span data-tone="solar">${fmt.n(d.sun * 100)} % soleil</span>` : " · pas de recharge"}</p>` });
  }

  // Dernières recharges (motif « Recent projects ») : date, énergie, part solaire, coût
  function recentCard() {
    const wait = BZ.hist && evWait(BZ.chargeDays(30));
    if (wait) return card({ cls: "ve-recent", title: "Dernières recharges", ic: "clock", tone: "accent", body: BZ.empty(wait) });
    const S = chargeState(), list = BZ.chargeDays(21).filter((d) => d.kwh).reverse().slice(0, 4);
    const today = new Date().toDateString();
    // Séance en cours : Home Assistant donne sa recharge réseau par tarif depuis le branchement (coût réel)
    const live = () => ({ date: new Date(), kwh: S.kwh, sun: S.kwh ? S.sol / S.kwh : 0, live: S.L.charging, ...(BZ.hist ? BZ.hist.evSplitBetween(+BZ.dt(C.session_debut), Date.now()) : {}) });
    if (S.L.plugged) list[0] && list[0].date.toDateString() === today ? (list[0] = live()) : list.unshift(live());
    const rows = list.slice(0, 4);
    const when = (d) => (d.toDateString() === today ? "Aujourd'hui" : d.toDateString() === new Date(Date.now() - 864e5).toDateString() ? "Hier" : fmt.cap(fmt.date(d, { weekday: "short", day: "numeric", month: "short" })));
    return card({ cls: "ve-recent", title: "Dernières recharges", ic: "clock", tone: "accent", body: h`
      <ul class="plist">${rows.map((r) => { const cost = costOf({ ev: r.kwh, evSun: r.kwh * r.sun, evHp: r.evHp, evHc: r.evHc, evHsc: r.evHsc }); return h`<li><div class="plist-r">
        <span class="dt-ic" data-tone="${r.sun >= 0.5 ? "solar" : "grid"}">${icon(r.sun >= 0.5 ? "sun" : "grid")}</span>
        <span><strong>${when(r.date)}${r.live ? h` <span class="pill is-live" data-tone="ev">en cours</span>` : ""}</strong><small>${fmt.kwhText(r.kwh)} · ${fmt.eur(cost)}</small></span>
        <span class="plist-p"><span>${fmt.n(r.sun * 100)} % soleil</span>${meter({ value: r.sun * 100, tone: "solar", size: "xs" })}</span>
      </div></li>`; })}</ul>
      ${(() => { const all = BZ.chargeDays(30).filter((d) => d.kwh), avg = all.reduce((a, d) => a + d.kwh, 0) / (all.length || 1), sun = all.reduce((a, d) => a + d.kwh * d.sun, 0) / (all.reduce((a, d) => a + d.kwh, 0) || 1);
        return h`<p class="ve-avg">30 jours : <b>${all.length} recharges</b> · <b>${fmt.kwhText(avg)}</b> en moyenne · <b>${fmt.n(sun * 100)} %</b> soleil</p>`; })()}` });
  }

  function settingsCard() {
    const lim = num(C.voiture_limite_pct), dc = num(C.voiture_limite_dc_pct);
    const odo = num(C.voiture_odometre), last = num(C.entretien_dernier_km), next = last + C.entretien_intervalle_km, left = next - odo, armed = BZ.ui.armed === "service";
    return card({ cls: "ve-set", title: "Réglages et entretien", ic: "gauge", tone: "accent", body: h`<div class="rows">
      <div class="row ve-lims"><div><strong>Limites de charge</strong><span>AC à domicile · DC sur borne rapide</span></div>
        <div class="ve-lim2" title="Recharge à domicile (AC)"><span>AC</span>${stepper({ value: fmt.n(lim), unit: " %", act: "car-lim", label: "Limite à domicile (AC)", cur: lim, min: 50, max: 100, pending: BZ.isPending(C.voiture_limite_pct) })}</div>
        <div class="ve-lim2" title="Recharge rapide sur borne (DC)"><span>DC</span>${stepper({ value: fmt.n(dc), unit: " %", act: "car-limdc", label: "Limite charge rapide (DC)", cur: dc, min: 50, max: 100, pending: BZ.isPending(C.voiture_limite_dc_pct) })}</div></div>
      <div class="row"><div><strong>Heures creuses seulement</strong><span>creuses et super creuses</span></div>${toggle({ on: isOn(C.voiture_heures_creuses), act: "toggle", args: { entity: C.voiture_heures_creuses }, label: "Heures creuses seulement", pending: BZ.isPending(C.voiture_heures_creuses) })}</div>
      <div class="row"><div><strong>Charge programmée</strong><span>horaire réglé dans la voiture</span></div>${toggle({ on: isOn(C.voiture_programmee), act: "toggle", args: { entity: C.voiture_programmee }, label: "Charge programmée", pending: BZ.isPending(C.voiture_programmee) })}</div>
      <div class="row ve-care"><div><strong>Révision</strong><span>${left >= 0 ? `dans ${fmt.n(left)} km (à ${fmt.n(next)} km)` : `${fmt.n(-left)} km de retard`}</span>${meter({ value: ((odo - last) / C.entretien_intervalle_km) * 100, tone: left < 1000 ? "warn" : "ev", size: "xs", label: "Avancement jusqu'à la révision" })}</div>
        ${btn({ label: armed ? "Confirmer" : "Révision faite", ic: "check", act: "car-service", size: "sm", kind: armed ? "danger" : "secondary" })}</div>
    </div>` });
  }

  // « Relevé il y a 12 min » : devient « Relevé en cours… 8 s » pendant un relevé forcé, « Relevé à l'instant ✓ » en vert
  // une fois à jour, et signale l'échec (les chiffres affichés n'ont alors pas été rafraîchis). Le texte part toujours
  // de « Relevé » au même endroit : les marques (secondes, coche) viennent après, rien ne se décale
  function updated() {
    const R = BZ.slowOf("refresh");
    if (running(R)) return h`<p class="ph-hi ve-upd is-reading">Relevé en cours…<span class="ve-upd-c" data-since="${R.t0}" aria-hidden="true">${secs(Date.now() - R.t0)}</span></p>`;
    if (R && R.phase === "ok") return h`<p class="ph-hi ve-upd is-fresh">Relevé à l'instant${icon("check", "ve-tick")}</p>`;
    return h`<p class="ph-hi ve-upd ${R ? "is-fail" : ""}">Relevé ${fmt.ago(st(C.voiture_maj))}${R ? h`<span> · échec du relevé</span>` : ""}</p>`;
  }

  BZ.pages.vehicle = () => {
    const S = stats();
    return h`
      <header class="ph">
        <div>${updated()}<h1>Kia e-Niro</h1><p class="ph-sub">${fmt.n(num(C.voiture_odometre))} km au compteur · batterie de ${fmt.n(C.voiture_capacite_kwh)} kWh</p></div>
        <div class="ph-a">${pills({ name: "carPeriod", label: "Période des recharges", value: S.kind, options: [["semaine", "7 jours"], ["mois", "Mois"], ["annee", "Année"]] })}</div>
      </header>
      ${kpis(S)}
      <div class="layout ve-grid">
        <div class="col ve-l">${hero()}<div class="ve-pair">${mixCard(S)}${calendarCard()}</div></div>
        <div class="col ve-r">${recentCard()}${settingsCard()}</div>
      </div>`;
  };
})();
;
// ═══ v3/js/pages/home.js
// Maison (V3) : la page domotique validée en V1/V2 (façon Apple Maison, rangée par type d'objet,
// poêle et ballon côte à côte, lecteur sans carte avec pochette), dans la mise en page de la V3 :
// en-tête · 4 indicateurs (qui servent aussi de filtres) · grille ⅔ + ⅓.
// Toutes les tuiles ont la même hauteur et les emplacements libres reçoivent des actions groupées,
// pour que les rangées restent alignées d'une section à l'autre sans trou.
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, val, card, C, num, st, attr, isOn, esc } = BZ;

  /* ─── Tuile : l'icône agit tout de suite, le texte ouvre le détail ─── */
  const tile = (a, extra = "") => {
    const iconAct = a.toggle
      ? h`data-act="${a.quick}" ${a.quick === "toggle" ? `data-entity="${a.id}"` : BZ.dataArgs(a.args || { i: (a.sheet || "").split(":")[1] || "" })} aria-label="${esc(`${a.verb} : ${a.name}`)}" aria-pressed="${String(a.on)}"`
      : h`data-act="open-sheet" data-sheet="${a.sheet}" aria-label="${esc(`Ouvrir ${a.name}`)}"`;
    return h`<div class="ma-tile ${a.on ? "is-on" : ""} ${a.anim || ""}" data-tone="${a.tone}" data-key="${a.id}${a.name}">
      <button type="button" class="ma-tile-i ${a.armed ? "is-armed" : ""}" ${iconAct} ${BZ.isPending(a.id) ? 'aria-busy="true"' : ""}>${icon(a.ic)}</button>
      <button type="button" class="ma-tile-t" ${a.sheet ? `data-act="open-sheet" data-sheet="${a.sheet}"` : a.toggle ? h`data-act="${a.quick}" ${a.quick === "toggle" ? `data-entity="${a.id}"` : BZ.dataArgs(a.args || {})} aria-pressed="${String(a.on)}"` : `data-act="nav" data-to="${a.to}"`}><strong>${a.name}</strong><span>${a.state}</span></button>
      ${extra}
    </div>`;
  };
  // Volets : un trait fin sous le texte indique l'ouverture
  const coverTile = (a) => tile(a, h`<i class="ma-pos" style="--v:${a.pos}%" aria-hidden="true"></i>`);
  // Action groupée : remplit les emplacements libres d'une grille
  const actionTile = ({ label, sub, ic, act, args = {}, disabled, pending, tone = "accent" }) => h`
    <button type="button" class="ma-tile ma-act" data-tone="${tone}" data-act="${act}" ${BZ.dataArgs(args)} ${disabled ? "disabled" : ""} ${pending ? 'aria-busy="true"' : ""}>
      <span class="ma-tile-i" aria-hidden="true">${icon(ic)}</span><span class="ma-tile-t"><strong>${label}</strong><span>${sub}</span></span></button>`;

  /* ─── Lecteur « À l'écoute » : sans carte, avec la pochette ────────── */
  function nowPlaying() {
    const M = BZ.media();
    if (!M.active) return "";
    return h`<div class="ma-np ${M.playing ? "is-playing" : ""}">
      <button type="button" class="ma-np-art" data-act="open-sheet" data-sheet="media" aria-label="Ouvrir le lecteur">${BZ.mediaArt(M)}</button>
      <button type="button" class="ma-np-t" data-act="open-sheet" data-sheet="media">
        <span class="ma-np-src">${M.playing ? h`<span class="ma-eq" aria-hidden="true"><i></i><i></i><i></i></span>` : ""}HomePod salon${M.playing ? "" : " · en pause"}</span>
        <strong>${esc(M.title || "—")}${M.artist ? h`<span> · ${esc(M.artist)}</span>` : ""}</strong>
      </button>
      <div class="ma-np-c">
        <button type="button" data-act="media" data-cmd="previous" aria-label="Morceau précédent">${icon("prev")}</button>
        <button type="button" class="ma-np-play" data-act="media" data-cmd="play_pause" aria-label="${M.playing ? "Pause" : "Lecture"}" ${BZ.isPending(C.homepod) ? 'aria-busy="true"' : ""}>${icon(M.playing ? "pause" : "play")}</button>
        <button type="button" data-act="media" data-cmd="next" aria-label="Morceau suivant">${icon("next")}</button>
      </div>
      <div class="ma-np-p">${BZ.mediaProgress(M)}</div>
    </div>`;
  }

  /* ─── Indicateur : résumé d'une famille, et filtre de la page ───────── */
  const fkpi = ({ k, label, ic, tone, value, valueText, note, viz }) => {
    const sel = BZ.ui.homeFilter === k;
    return h`<button type="button" class="kpi ma-kpi ${sel ? "is-sel" : ""}" data-act="set" data-k="homeFilter" data-value="${sel ? "all" : k}" aria-pressed="${String(sel)}"
      aria-label="${esc(`${label} : ${valueText}. ${sel ? "Afficher toute la maison" : "Ne montrer que cette famille"}`)}">
      <span class="kpi-i" data-tone="${tone}">${icon(ic)}</span>
      <span class="kpi-l">${label}</span>
      <span class="kpi-v">${value}</span>
      <span class="kpi-d"><span class="kpi-vs">${note}</span></span>
      <span class="kpi-s ma-viz" data-tone="${tone}" aria-hidden="true">${viz}</span>
    </button>`;
  };

  BZ.pages.home = () => {
    const f = BZ.ui.homeFilter;
    const lights = C.lumieres.map((_, i) => BZ.acc("light", i)), covers = C.volets.map((_, i) => BZ.acc("cover", i));
    const heat = [BZ.acc("stove"), BZ.acc("boiler"), ...C.radiateurs.map((_, i) => BZ.acc("rad", i))];
    const devices = [BZ.acc("plug"), BZ.acc("strip"), BZ.acc("robot")];
    const lit = lights.filter((a) => a.on), openN = covers.filter((a) => a.on).length, closed = covers.length - openN;
    const temps = [attr(C.poele, "current_temperature"), ...C.radiateurs.map((id, i) => (C.radiateurs_temp[i] ? num(C.radiateurs_temp[i]) : attr(id, "current_temperature")))];
    const tMin = Math.min(...temps), tMax = Math.max(...temps), heatOn = heat.filter((a) => a.on).length;
    const activeDev = devices.filter((a) => a.on), watts = isOn(C.prise_chambre) ? num(C.prise_chambre_w) : 0;
    const locked = st(C.voiture_verrou) === "locked", armed = BZ.ui.armed === "unlock";
    // États météo de Home Assistant (tous), en clair
    const meteo = { sunny: "ensoleillé", cloudy: "nuageux", rainy: "pluie", partlycloudy: "éclaircies", clear: "dégagé", "clear-night": "nuit claire", fog: "brouillard", hail: "grêle",
      lightning: "orage", "lightning-rainy": "orage et pluie", pouring: "averses", snowy: "neige", "snowy-rainy": "pluie et neige", windy: "venteux", "windy-variant": "venteux",
      exceptional: "exceptionnel", unavailable: "météo indisponible", unknown: "météo inconnue" }[st(C.meteo)] || st(C.meteo);
    const tremieH = (num(C.tremie_kg) / num(C.conso_jour_kg)) * 24;
    const coversBusy = C.volets.some(BZ.isPending);

    const sections = {
      lights: card({ cls: "ma-sec ma-lights", title: "Lumières", ic: "bulb", tone: "light", body: h`<div class="ma-tiles">
        ${lights.map((a) => tile(a))}
        ${actionTile({ label: "Tout éteindre", sub: lit.length ? `${lit.length} allumée${lit.length > 1 ? "s" : ""}` : "déjà éteintes", ic: "power", act: "lights-off", disabled: !lit.length, pending: C.lumieres.some(BZ.isPending) })}</div>` }),
      covers: card({ cls: "ma-sec ma-covers", title: "Volets", ic: "blinds", tone: "battery", body: h`<div class="ma-tiles">
        ${covers.map((a) => coverTile(a))}
        ${actionTile({ label: "Tout ouvrir", sub: closed ? `${closed} fermé${closed > 1 ? "s" : ""}` : "déjà ouverts", ic: "up", act: "covers-all", args: { pos: 100 }, disabled: !closed, pending: coversBusy, tone: "battery" })}
        ${actionTile({ label: "Mi-hauteur", sub: "tous à 50 %", ic: "minus", act: "covers-all", args: { pos: 50 }, pending: coversBusy, tone: "battery" })}
        ${actionTile({ label: "Tout fermer", sub: openN ? `${openN} ouvert${openN > 1 ? "s" : ""}` : "déjà fermés", ic: "down", act: "covers-all", args: { pos: 0 }, disabled: !openN, pending: coversBusy, tone: "battery" })}</div>` }),
      heat: card({ cls: "ma-sec ma-heat", title: "Chauffage", ic: "thermo", tone: "heat",
        aside: BZ.pill(`Granulés ≈ ${fmt.n(tremieH)} h`, tremieH < 48 ? "warn" : "neutral"),
        body: h`<div class="ma-tiles">${heat.map((a) => tile(a))}</div>` }),
      devices: card({ cls: "ma-sec ma-dev", title: "Appareils", ic: "plug", tone: "good", body: h`<div class="ma-tiles">
        ${devices.map((a) => tile(a))}
        <div class="ma-tile ${locked ? "is-on" : ""}" data-tone="${locked ? "good" : "warn"}">
          <button type="button" class="ma-tile-i ${armed ? "is-armed" : ""}" data-act="car-lock" aria-label="${armed ? "Confirmer le déverrouillage de l'e-Niro" : locked ? "Déverrouiller l'e-Niro" : "Verrouiller l'e-Niro"}" ${BZ.isPending(C.voiture_verrou) ? 'aria-busy="true"' : ""}>${icon(locked ? "lock" : "unlock")}</button>
          <button type="button" class="ma-tile-t" data-act="nav" data-to="vehicle"><strong>e-Niro</strong><span>${armed ? "Touche encore pour ouvrir" : locked ? "Verrouillée" : "Ouverte"}</span></button>
        </div></div>` }),
    };
    const order = ["lights", "devices", "covers", "heat"];
    const famLabel = { lights: "Lumières", covers: "Volets", heat: "Chauffage", devices: "Appareils" };

    return h`
      <header class="ph ma-ph">
        <div><p class="ph-hi">${fmt.n(attr(C.meteo, "temperature"))}° dehors · ${meteo}</p><h1>Maison</h1>
          <p class="ph-sub">Humidité ${fmt.n(attr(C.meteo, "humidity"))} % · vent ${fmt.n(attr(C.meteo, "wind_speed"))} ${esc(attr(C.meteo, "wind_speed_unit") || "km/h")}</p></div>
        <div class="ph-a">${nowPlaying()}</div>
      </header>

      <div class="kpis ma-kpis">
        ${fkpi({ k: "lights", label: "Lumières allumées", ic: "bulb", tone: "light", value: val([String(lit.length), `/ ${lights.length}`]), valueText: `${lit.length} sur ${lights.length}`,
          note: lit.length ? `${lit[0].name}${lit.length > 1 ? ` +${lit.length - 1}` : ""}` : "aucune",
          viz: h`<span class="ma-dots">${lights.map((a) => h`<i class="${a.on ? "is-on" : ""}"></i>`)}</span>` })}
        ${fkpi({ k: "covers", label: "Volets ouverts", ic: "blinds", tone: "battery", value: val([String(openN), `/ ${covers.length}`]), valueText: `${openN} sur ${covers.length}`,
          note: closed ? `${closed} fermé${closed > 1 ? "s" : ""}` : "tous ouverts",
          viz: h`<span class="ma-bars">${covers.map((a) => h`<i style="--v:${Math.max(6, a.pos)}%"></i>`)}</span>` })}
        ${fkpi({ k: "heat", label: "Chauffage en marche", ic: "thermo", tone: "heat", value: val([String(heatOn), `/ ${heat.length}`]), valueText: `${heatOn} sur ${heat.length}`,
          note: `pièces de ${fmt.n(tMin, 1)} à ${fmt.n(tMax, 1)}°`,
          viz: h`<span class="ma-bars is-temp">${temps.map((t) => h`<i style="--v:${Math.round(((t - 14) / 10) * 100)}%"></i>`)}</span>` })}
        ${fkpi({ k: "devices", label: "Appareils en marche", ic: "plug", tone: "good", value: val([String(activeDev.length), `/ ${devices.length}`]), valueText: `${activeDev.length} sur ${devices.length}`,
          note: watts ? `consomment ${fmt.powerText(watts)}` : "rien ne consomme",
          viz: h`<span class="ma-dots">${devices.map((a) => h`<i class="${a.on ? "is-on" : ""}"></i>`)}</span>` })}
      </div>

      ${f !== "all" ? h`<div class="ma-filter"><span>Filtre : <b>${famLabel[f]}</b></span><button type="button" class="more" data-act="set" data-k="homeFilter" data-value="all">Tout afficher${icon("x")}</button></div>` : ""}

      <div class="layout ma-grid ${f !== "all" ? "is-filtered" : ""}">${order.map((k) => (f === "all" || f === k ? sections[k] : sections[k].replace('class="card ma-sec', 'class="card ma-sec is-dim')))}</div>`;
  };
})();
;
// ═══ v3/js/app.js
// Breezy HEMS V3 — coquille : barre latérale, barre du haut (recherche, notifications, thème, profil),
// routes, actions, panneaux, thème.
(() => {
  const BZ = window.BZ;
  const { h, fmt, icon, avatar, C, num, st, attr, isOn, call, esc } = BZ;
  const HA = BZ.ha;   // pont Home Assistant (v3/ha/panel-core.js) ; null en démo

  /* ─── État d'interface (pas d'état métier ici) ─────────────────────── */
  const saved = (() => { try { return JSON.parse(localStorage.getItem("bz3") || "{}"); } catch { return {}; } })();
  BZ.ui = { period: "semaine", carPeriod: "mois", homeFilter: "all", devFilter: "all", carArt: "roadster", dayOffset: 0, armed: null, sheet: null, pop: null, theme: saved.theme || (HA ? "auto" : "light"), ...saved.ui };
  BZ.ui.dayOffset = 0; BZ.ui.pop = null; BZ.ui.homeFilter = "all";
  const persist = () => { try { localStorage.setItem("bz3", JSON.stringify({ theme: BZ.ui.theme, ui: { period: BZ.ui.period, carPeriod: BZ.ui.carPeriod, devFilter: BZ.ui.devFilter, carArt: BZ.ui.carArt } })); } catch {} };
  // Home Assistant : le nom de la personne connectée, sauf si config.js en impose un
  const userName = () => C.utilisateur_nom || (HA && HA.userName) || "Breezy";
  BZ.user = userName();

  const ROUTES = [
    { id: "overview", label: "Aperçu", ic: "overview" },
    { id: "energy", label: "Énergie", ic: "energy" },
    { id: "insights", label: "Bilan", ic: "insights" },
    { id: "vehicle", label: "Voiture", ic: "car" },
    { id: "home", label: "Maison", ic: "home" },
  ];
  // Route courante : gardée en mémoire (l'adresse n'est qu'un reflet), pour fonctionner aussi
  // dans un cadre isolé où les liens d'ancre ne naviguent pas.
  const fromHash = () => { const r = location.hash.replace("#/", ""); return ROUTES.some((x) => x.id === r) ? r : null; };
  // Home Assistant : la page vient de l'adresse du panneau (/breezy/energy) ; un ancien lien /breezy#/energy marche aussi
  // (le cadre ne voit pas le # de la page principale : on le lit chez elle, même origine)
  const routeOf = (r) => { const id = ((r && r.path) || "").replace(/^\//, "").split("/")[0]; return ROUTES.some((x) => x.id === id) ? id : null; };
  const parentHash = () => { try { const r = parent.location.hash.replace("#/", ""); return ROUTES.some((x) => x.id === r) ? r : null; } catch { return null; } };
  // Un # valide l'emporte : un lien ouvert dans un nouvel onglet depuis le cadre garde l'adresse du panneau au moment de
  // son ouverture (/breezy/insights#/vehicle) ; on y montre la page du #, puis l'adresse est corrigée
  const haStart = HA ? routeOf(HA.route) : null, haLegacy = HA ? parentHash() : null;
  let current = (HA ? haLegacy || haStart : fromHash()) || "overview";
  const route = () => current;
  BZ.routes = ROUTES;
  function go(id, push = true) {
    if (!ROUTES.some((x) => x.id === id)) return;
    const prev = current;
    current = id; BZ.ui.sheet = null; BZ.ui.pop = null;
    // Home Assistant : l'adresse de la page principale suit (/breezy/energy), un seul « Retour » pour revenir ;
    // la page déjà affichée n'ajoute rien à l'historique du navigateur
    if (push) { if (HA) { if (id !== prev) HA.navigate(id); } else try { if (location.hash !== `#/${id}`) history.pushState(null, "", `#/${id}`); } catch {} }
    render();
  }
  BZ.go = go;

  /* ─── Barre latérale ───────────────────────────────────────────────── */
  function side() {
    const L = BZ.live(), cur = route(), t = BZ.tariffNow(), lights = C.lumieres.filter(isOn).length;
    const badge = { vehicle: L.charging ? h`<em class="is-soft">${fmt.n(num(C.voiture_soc))} %</em>` : "", home: lights ? h`<em>${lights}</em>` : "" };
    const g = L.grid, exp = g < -15, imp = g > 15;
    const favs = [
      { label: "Eau chaude", ic: "drop", tone: "battery", v: `${fmt.n(num(C.ballon_temp))}°`, sheet: "ballon" },
      { label: "Poêle", ic: "flame", tone: "heat", v: st(C.poele) !== "off" ? `${fmt.n(attr(C.poele, "current_temperature"), 1)}°` : "éteint", sheet: "poele" },
      { label: "Kia e-Niro", ic: "car", tone: "ev", v: `${fmt.n(num(C.voiture_soc))} %`, to: "vehicle" },
    ];
    return h`
      <a class="brand" href="${BZ.href("overview")}" aria-label="Breezy HEMS, aperçu"><span class="brand-m">${icon("energy")}</span><span class="brand-t">Breezy <em>HEMS</em></span></a>
      <ul class="nav-l">${ROUTES.map((r) => h`<li><a href="${BZ.href(r.id)}" class="nav-i" ${r.id === cur ? 'aria-current="page"' : ""} title="${r.label}">${icon(r.ic)}<span>${r.label}</span>${badge[r.id] || ""}</a></li>`)}</ul>
      <p class="nav-g favs-h">Favoris</p>
      <ul class="favs">${favs.map((f) => h`<li>${f.to
        ? h`<a class="fav" href="${BZ.href(f.to)}"><span class="dt-ic" data-tone="${f.tone}">${icon(f.ic)}</span><span>${f.label}</span><span class="fav-v">${f.v}</span></a>`
        : h`<button type="button" class="fav" data-act="open-sheet" data-sheet="${f.sheet}"><span class="dt-ic" data-tone="${f.tone}">${icon(f.ic)}</span><span>${f.label}</span><span class="fav-v">${f.v}</span></button>`}</li>`)}</ul>
      <div class="promo-s">
        <span class="card-i" data-tone="${exp ? "good" : imp ? "bad" : "neutral"}">${icon("grid")}</span>
        <strong>Réseau en direct</strong>
        <div class="promo-v"><b class="${exp ? "is-good" : imp ? "is-bad" : ""}">${exp ? "−" : imp ? "+" : ""}${fmt.powerText(Math.abs(g))}</b><span>${exp ? "revente" : imp ? "achat" : "équilibre"}</span></div>
        <p>Compteur L3 · ${t.label.toLowerCase()} à ${fmt.n(t.price, 4)} €/kWh jusqu'à ${fmt.time(t.changeAt)}.</p>
        ${cur === "energy" ? h`<a class="btn btn-primary btn-sm" href="${BZ.href("insights")}"><span>Voir le bilan</span>${icon("arrow")}</a>` : h`<a class="btn btn-primary btn-sm" href="${BZ.href("energy")}"><span>Voir l'énergie</span>${icon("arrow")}</a>`}
      </div>
      <button type="button" class="side-me" data-act="pop" data-pop="me-side" aria-haspopup="menu" aria-expanded="${String(BZ.ui.pop === "me-side")}">
        ${avatar(BZ.user, "lg")}<span><b>${esc(BZ.user)}</b><small>${HA ? (HA.connected ? "Home Assistant" : "Hors ligne") : "Mode démo"}</small></span>${icon("down")}
      </button>
      <div class="pop pop-up ${BZ.ui.pop === "me-side" ? "is-open" : ""}" role="menu">${profileMenu()}</div>`;
  }

  /* ─── Barre du haut : construite une fois (le champ de recherche garde son état) ─ */
  function topInit() {
    // Home Assistant sur téléphone : pas de barre HA au-dessus du panneau, ce bouton ouvre son menu (barre latérale)
    document.getElementById("top").innerHTML = h`
      ${HA ? h`<button type="button" class="icon-btn ha-menu" data-act="ha-menu" aria-label="Ouvrir le menu Home Assistant">${icon("menu")}</button>` : ""}<a class="top-brand" href="${BZ.href("overview")}" aria-label="Breezy HEMS, aperçu"><span class="brand-m">${icon("energy")}</span><span class="brand-t">Breezy <em>HEMS</em></span></a>
      <div class="search" role="search">
        <label class="search-f">${icon("search")}<span class="sr">Rechercher</span>
          <input id="q" type="search" placeholder="Rechercher un appareil, une page…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="q-pop" aria-autocomplete="list"><kbd>/</kbd></label>
        <div class="pop" id="q-pop" role="listbox" aria-label="Résultats"></div>
      </div>
      <div class="top-a" id="top-a"></div>`;
    const q = document.getElementById("q"), pop = document.getElementById("q-pop");
    let sel = 0, res = [];
    const draw = () => {
      res = BZ.search(q.value);
      const open = q.value.trim() !== "";
      pop.classList.toggle("is-open", open); q.setAttribute("aria-expanded", String(open));
      pop.innerHTML = !open ? "" : res.length ? h`<p class="pop-h">${res.length} résultat${res.length > 1 ? "s" : ""}</p>${res.map((r, i) => h`
        <button type="button" class="pop-i ${i === sel ? "is-active" : ""}" role="option" aria-selected="${String(i === sel)}" data-pick="${i}"><span class="dt-ic" data-tone="${r.tone}">${icon(r.ic)}</span><span><strong>${r.label}</strong><small>${r.sub}</small></span></button>`)}`
        : h`<p class="pop-e">Aucun résultat pour « ${esc(q.value)} »</p>`;
    };
    const pick = (r) => {
      if (!r) return;
      q.value = ""; draw(); q.blur();
      if (r.to) go(r.to); else if (r.sheet) openSheet(r.sheet); else if (r.act) A[r.act]({ ...r.args });
    };
    q.addEventListener("input", () => { sel = 0; draw(); });
    q.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); sel = BZ.clamp(sel + (e.key === "ArrowDown" ? 1 : -1), 0, Math.max(0, res.length - 1)); draw(); }
      if (e.key === "Enter") { e.preventDefault(); pick(res[sel]); }
      if (e.key === "Escape") { q.value = ""; draw(); q.blur(); }
    });
    pop.addEventListener("click", (e) => { const b = e.target.closest("[data-pick]"); if (b) pick(res[+b.dataset.pick]); });
    q.addEventListener("blur", () => setTimeout(() => { if (document.activeElement !== q) { pop.classList.remove("is-open"); q.setAttribute("aria-expanded", "false"); } }, 150));
    q.addEventListener("focus", () => q.value && draw());
  }
  function profileMenu() {
    const t = BZ.ui.theme;
    return h`<p class="pop-h">Apparence</p>
      ${[["light", "Clair", "sun"], ["dark", "Sombre", "moon"], ["auto", HA ? "Comme Home Assistant" : "Automatique", "contrast"]].map(([k, l, ic]) => h`<button type="button" class="pop-i" role="menuitemradio" aria-checked="${String(t === k)}" data-act="theme-set" data-value="${k}">${icon(ic)}<span>${l}</span></button>`)}
      <p class="pop-h">Connexion</p>
      ${HA ? haConnection() : h`<div class="pop-i">${icon("plug")}<span><strong>Données de démonstration</strong><small>Les valeurs sont des exemples tant que Home Assistant n'est pas branché.</small></span></div>`}`;
  }
  // Home Assistant : état de la connexion, version, et le diagnostic (entités introuvables…) à portée de main
  function haConnection() {
    const n = BZ.diagCount ? BZ.diagCount() : 0;
    return h`<div class="pop-i">${icon("plug")}<span><strong>${HA.connected ? "Connecté à Home Assistant" : "Connexion perdue, reconnexion…"}</strong><small>Breezy ${esc(HA.version)}</small></span></div>
      <button type="button" class="pop-i" role="menuitem" data-act="open-sheet" data-sheet="diag">${icon("alert")}<span><strong>Diagnostic${n ? ` (${n})` : ""}</strong><small>${n ? `${n} point${n > 1 ? "s" : ""} à vérifier` : "Rien à corriger"}</small></span></button>`;
  }
  function topActions() {
    const al = BZ.alerts(), dark = document.documentElement.dataset.theme === "dark";
    return h`
      <div class="rel">
        <button type="button" class="icon-btn" data-act="pop" data-pop="bell" aria-haspopup="dialog" aria-expanded="${String(BZ.ui.pop === "bell")}" aria-label="Suggestions${al.length ? ` (${al.length})` : ""}">${icon("bell")}${al.length ? h`<span class="dot"></span>` : ""}</button>
        <div class="pop pop-bell ${BZ.ui.pop === "bell" ? "is-open" : ""}" role="dialog" aria-label="Suggestions">
          <p class="pop-h">${al.length ? `${al.length} suggestion${al.length > 1 ? "s" : ""}` : "Suggestions"}</p>
          ${al.length ? al.map((a) => h`<div class="pop-i al" data-tone="${a.tone}"><span class="dt-ic">${icon(a.ic)}</span><span><strong>${a.title}</strong><small>${a.text}</small>
            ${a.act ? h`<button type="button" class="more" data-act="${a.act}" ${BZ.dataArgs(a.args || {})}>${a.cta}${icon("arrow")}</button>` : ""}</span></div>`)
            : h`<p class="pop-e">Rien à signaler : tout tourne comme prévu.</p>`}
        </div>
      </div>
      <button type="button" class="icon-btn theme-b" data-act="theme" aria-label="${dark ? "Passer en thème clair" : "Passer en thème sombre"}">${icon(dark ? "moon" : "sun")}</button>
      <div class="rel">
        <button type="button" class="me" data-act="pop" data-pop="me" aria-haspopup="menu" aria-expanded="${String(BZ.ui.pop === "me")}">${avatar(BZ.user)}<b class="me-n">${esc(BZ.user)}</b>${icon("down")}</button>
        <div class="pop ${BZ.ui.pop === "me" ? "is-open" : ""}" role="menu">${profileMenu()}</div>
      </div>`;
  }
  // Dock mobile : l'onglet actif s'élargit en pastille corail (icône + libellé), les autres restent des icônes.
  // Une pastille glisse d'un onglet à l'autre ; les états en direct (recharge, lumières) se lisent sur l'icône.
  function tabbar() {
    const cur = route(), L = BZ.live(), lights = C.lumieres.filter(isOn).length, idx = ROUTES.findIndex((r) => r.id === cur);
    const mark = { vehicle: L.charging ? h`<i class="tab-live" data-tone="ev" aria-hidden="true"></i>` : "", home: lights ? h`<em class="tab-n" aria-hidden="true">${lights}</em>` : "" };
    return h`<span class="tabs-ind" style="--i:${idx}" aria-hidden="true"></span>${ROUTES.map((r) => h`
      <a href="${BZ.href(r.id)}" ${r.id === cur ? 'aria-current="page"' : ""} aria-label="${r.label}${r.id === "home" && lights ? `, ${lights} lumière${lights > 1 ? "s" : ""} allumée${lights > 1 ? "s" : ""}` : ""}${r.id === "vehicle" && L.charging ? ", en charge" : ""}">
        <span class="tab-ic">${icon(r.ic)}${mark[r.id] || ""}</span><span class="tab-l">${r.label}</span></a>`)}`;
  }

  /* ─── Rendu ────────────────────────────────────────────────────────── */
  const view = document.getElementById("view");
  let lastRoute = null;
  function render() {
    // Panneau Home Assistant quitté : la page est détachée du document, son retour la redessine (rien à faire ici)
    if (!view.isConnected) return;
    const cur = route();
    BZ.resetCharts();
    const html = BZ.pages[cur]();
    if (cur !== lastRoute) {
      view.innerHTML = html;
      view.classList.remove("is-enter"); void view.offsetWidth; view.classList.add("is-enter");
      document.title = `${ROUTES.find((r) => r.id === cur).label} · Breezy HEMS`;
      if (lastRoute) { view.scrollTo(0, 0); window.scrollTo(0, 0); view.focus({ preventScroll: true }); }
      lastRoute = cur;
    } else {
      // Un bouton qui disparaît au rendu (« Réessayer » une fois relancé ou expiré) rend le focus à l'élément
      // qu'il désigne (data-refocus) : au clavier, on ne repart pas du début de la page
      const ae = document.activeElement, back = ae && ae.dataset && ae.dataset.refocus;
      BZ.morph(view, html);
      if (back && (!ae.isConnected || ae.dataset.refocus !== back)) view.querySelector(back)?.focus();
    }
    BZ.morph(document.getElementById("side"), side());
    BZ.morph(document.getElementById("top-a"), topActions());
    BZ.morph(document.getElementById("tabs"), tabbar());
    renderSheet();
  }
  BZ.render = render;

  /* ─── Panneau de détail (modale) ───────────────────────────────────── */
  const sheetEl = document.getElementById("sheet");
  let lastFocus = null;
  function renderSheet() {
    const s = BZ.ui.sheet;
    const bg = [document.querySelector(".frame"), document.getElementById("tabs"), document.querySelector(".skip")];
    if (!s) { if (sheetEl.classList.contains("is-open")) { sheetEl.classList.remove("is-open"); sheetEl.setAttribute("aria-hidden", "true"); bg.forEach((el) => el && (el.inert = false)); lastFocus && lastFocus.focus({ preventScroll: true }); } return; }
    bg.forEach((el) => el && (el.inert = true));   // le focus reste dans le panneau
    const [kind, i] = s.split(":"), d = BZ.sheets[kind](i != null ? +i : undefined);
    sheetEl.classList.toggle("is-full", !!d.full);
    const html = h`<div class="sheet-p ${d.full ? "is-full" : ""}" role="dialog" aria-modal="true" aria-labelledby="sheet-t" tabindex="-1">
      <header class="sheet-h"><span class="chip" data-tone="${d.tone}">${icon(d.ic)}</span><div><h2 id="sheet-t">${d.title}</h2><p>${d.sub}</p></div>
        <button type="button" class="icon-btn" data-act="close-sheet" aria-label="Fermer le panneau">${icon("x")}</button></header>
      <div class="sheet-b">${d.body}</div></div><div class="sheet-bg" data-act="close-sheet"></div>`;
    if (!sheetEl.classList.contains("is-open")) {
      sheetEl.innerHTML = html; sheetEl.classList.add("is-open"); sheetEl.removeAttribute("aria-hidden");
      lastFocus = document.activeElement;
      // Au doigt, le focus va au panneau lui-même (pas d'anneau sur le bouton Fermer) ; au clavier, sur la première commande
      requestAnimationFrame(() => (matchMedia("(pointer: coarse)").matches ? sheetEl.querySelector(".sheet-p") : sheetEl.querySelector(".vs, .sheet-b button, .icon-btn") || sheetEl).focus());
    } else BZ.morph(sheetEl, html);
  }
  const openSheet = (k) => { BZ.ui.sheet = k; BZ.ui.pop = null; render(); };
  const closeSheet = () => { BZ.ui.sheet = null; BZ.ui.armed = null; renderSheet(); };

  /* ─── Actions ──────────────────────────────────────────────────────── */
  const step = (id, d, by, lo, hi) => BZ.clamp(num(id) + by * d, lo, hi);
  let armTimer;
  const confirm2 = (key, run, msg) => {
    if (BZ.ui.armed === key) { BZ.ui.armed = null; clearTimeout(armTimer); run(); return; }
    BZ.ui.armed = key; BZ.ui.armedAt = Date.now(); if (msg) BZ.toast(msg); clearTimeout(armTimer);
    armTimer = setTimeout(() => { BZ.ui.armed = null; render(); }, 4000); render();
  };
  // Message affiché une fois la commande appliquée (msg peut être une fonction : lue après coup)
  // Home Assistant : une commande refusée renvoie false (le message d'erreur est déjà affiché)
  const done = (msg) => (ok) => { if (ok === false) return; BZ.toast(typeof msg === "function" ? msg() : msg, "good"); };
  // Commande voiture : une à la fois ; le message part quand la voiture a confirmé (ou l'échec).
  // Pupitre de la page Voiture à l'écran : sa ligne le dit déjà (et sur mobile le toast couvrirait les tuiles) ;
  // page défilée plus bas ou autre page : toast
  const carBusy = () => !!BZ.slowBusy() && (BZ.toast("Attends la fin de la commande en cours", "warn"), true);
  const seen = (el) => { const r = el && el.getBoundingClientRect(); return !!r && r.bottom > 60 && r.top < innerHeight - 90; };
  const car = (key, service, id, data, to, expect, ok) => {
    if (carBusy()) return;
    if (BZ.ui.armed === "unlock") { BZ.ui.armed = null; clearTimeout(armTimer); }   // une autre commande part : le déverrouillage n'est plus à confirmer
    return BZ.slowCall(key, service, id, data, { to, expect })
      .then((good) => (route() !== "vehicle" || !seen(document.querySelector(".ve-acts"))) && BZ.toast(good ? ok : BZ.slowOf(key)?.why || "La voiture n'a pas répondu", good ? "good" : "bad"));
  };
  // Cible explicite (d.to) : « Réessayer » relance la commande échouée telle quelle, sans basculer l'état actuel
  const aim = (d, now) => (d.to != null ? d.to === "true" : !now);
  // Volet : position en % ; Home Assistant, volet sans réglage de position (ouvert / fermé seulement) : ouvrir ou fermer
  const coverTo = (ids, pos) => {
    const all = [].concat(ids), plain = HA ? all.filter((id) => !(attr(id, "supported_features") & 4)) : [];
    if (!plain.length) return call("cover.set_cover_position", ids, { position: pos });
    const rest = all.filter((id) => !plain.includes(id));
    return Promise.all([call(`cover.${pos > 0 ? "open" : "close"}_cover`, plain), rest.length ? call("cover.set_cover_position", rest, { position: pos }) : true]).then((r) => (r.includes(false) ? false : true));
  };
  const nameOf = (id) => { const i = C.lumieres.indexOf(id); if (i >= 0) return `Lumière ${C.lumieres_noms[i]}`; const k = C.multiprise.indexOf(id); if (k >= 0) return C.multiprise_noms[k]; return id === C.prise_chambre ? "Prise chambre" : ""; };
  const A = {
    nav: (d) => go(d.to),
    set: (d) => { BZ.ui[d.k] = d.value; persist(); if (d.k === "stovePower") return call("number.set_value", C.poele_puissance, { value: d.value }).then(done(`Poêle réglé sur P${d.value}`)); render(); },
    day: (d) => { BZ.ui.dayOffset = BZ.clamp(BZ.ui.dayOffset + +d.d, -29, 0); render(); },
    pop: (d) => { BZ.ui.pop = BZ.ui.pop === d.pop ? null : d.pop; render(); },
    theme: () => { const dark = document.documentElement.dataset.theme === "dark"; BZ.ui.theme = dark ? "light" : "dark"; applyTheme(); persist(); render(); },
    "theme-set": (d) => { BZ.ui.theme = d.value; applyTheme(); persist(); render(); },
    "open-sheet": (d) => openSheet(d.i != null && d.i !== "" ? `${d.sheet}:${d.i}` : d.sheet),
    "close-sheet": closeSheet,
    // Fait défiler jusqu'à une carte de la page et la signale brièvement (maison en direct → carte détaillée)
    spot: (d) => {
      const el = document.querySelector(`.${d.spot}`); if (!el) return;
      const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
      el.scrollIntoView({ behavior: still ? "auto" : "smooth", block: "center" });
      if (!still && el.animate) el.animate([{ boxShadow: "0 0 0 0 color-mix(in srgb, var(--accent) 0%, transparent)" }, { boxShadow: "0 0 0 3px color-mix(in srgb, var(--accent) 55%, transparent)", offset: 0.25 }, { boxShadow: "0 0 0 3px color-mix(in srgb, var(--accent) 0%, transparent)" }], { duration: 1600, delay: 350, easing: "ease-out" });
      // Le titre de la carte porte tabindex="-1" dans son gabarit (card({ target: true })) : le focus survit aux rendus
      (el.querySelector("h3[tabindex]") || el).focus({ preventScroll: true });
    },
    // Service du domaine de l'entité (light.toggle, switch.toggle…) : switch.toggle n'agit pas sur une lumière
    toggle: (d) => call(`${d.entity.split(".")[0]}.toggle`, d.entity).then(done(() => `${nameOf(d.entity) || "Appareil"} ${isOn(d.entity) ? "allumé" : "éteint"}`.replace(/^(Lumière .*) (allumé|éteint)$/, "$1 $2e"))),
    // Maison
    "lights-off": () => call("light.turn_off", C.lumieres.filter(isOn)).then(done("Toutes les lumières sont éteintes")),
    "covers-all": (d) => coverTo(C.volets, +d.pos).then(done(+d.pos ? "Volets ouverts" : "Volets fermés")),
    "cover-flip": (d) => { const id = C.volets[d.i], p = BZ.coverPos(id) > 0 ? 0 : 100; return coverTo(id, p).then(done(`${C.volets_noms[d.i]} ${p ? "ouvert" : "fermé"}`)); },
    "cover-set": (d) => coverTo(C.volets[d.i], +d.pos),
    "rad-power": (d) => { const id = C.radiateurs[d.i]; return call("climate.set_hvac_mode", id, { hvac_mode: st(id) === "off" ? "heat" : "off" }).then(done(() => `Radiateur ${C.radiateurs_noms[d.i]} ${st(id) === "off" ? "éteint" : "allumé"}`)); },
    // Poêle : une seconde touche dans les 4 s confirme (évite d'allumer ou d'éteindre par erreur)
    "stove-power": () => { const on = st(C.poele) !== "off";
      return confirm2("stove", () => call("climate.set_hvac_mode", C.poele, { hvac_mode: on ? "off" : "heat" }).then(done(on ? "Poêle éteint" : "Poêle allumé")), on ? "Appuie encore pour éteindre le poêle" : "Appuie encore pour allumer le poêle"); },
    // Démo : la chauffe suit le forçage ; Home Assistant : c'est le ballon qui le dit (son état n'est jamais modifié ici)
    "boiler-boost": () => call("number.set_value", C.ballon_boost, { value: num(C.ballon_boost) === 1 ? 0 : 1 }).then((ok) => { if (ok === false) return; if (!HA) BZ.ent(C.ballon_chauffe).state = num(C.ballon_boost) === 1 ? "on" : "off"; BZ.toast(num(C.ballon_boost) === 1 ? "Chauffe du ballon forcée" : "Ballon en mode normal", "good"); }),
    "pellet-fill": () => confirm2("fill", () => call("script.turn_on", C.script_remplir).then(done("Sac versé : trémie mise à jour")), "Appuie encore pour confirmer le sac versé"),
    "pellet-buy": () => call("script.turn_on", C.script_achat).then(done("Un sac ajouté au stock")),
    robot: (d) => call(`vacuum.${d.cmd}`, C.robot).then(done({ start: `Nettoyage lancé : ${(st(C.robot_scene) || "").toLowerCase()}`, pause: "Nettoyage en pause", return_to_base: "L'aspirateur retourne à sa base", locate: "L'aspirateur émet un bip pour se signaler" }[d.cmd] || "Commande envoyée")),
    "robot-zone": (d) => call("select.select_option", C.robot_scene, { option: d.value }),
    "robot-fan": (d) => call("vacuum.set_fan_speed", C.robot, { fan_speed: d.value }).then(done(`Aspiration : ${d.value}`)),
    media: (d) => call(`media_player.media_${d.cmd}${d.cmd === "play_pause" ? "" : "_track"}`, C.homepod),
    // Énergie
    "bat-min": (d) => call("number.set_value", C.batterie_min_pct, { value: step(C.batterie_min_pct, +d.d, 5, 0, 50) }),
    "bat-max": (d) => call("number.set_value", C.batterie_max_pct, { value: step(C.batterie_max_pct, +d.d, 5, 70, 100) }),
    // Voiture
    // Voiture : commandes lentes (cloud Kia Connect), suivies jusqu'à ce que la voiture confirme
    "car-charge": (d) => { const on = aim(d, isOn(C.voiture_en_charge));
      return car("charge", `switch.turn_${on ? "on" : "off"}`, C.voiture_en_charge, {}, on, () => isOn(C.voiture_en_charge) === on, on ? "Recharge démarrée" : "Recharge arrêtée"); },
    // Déverrouiller demande une seconde touche : la tuile devient « Déverrouiller ? » avec son compte à rebours (pas de message)
    "car-lock": (d) => (carBusy() ? null : (d.to || (st(C.voiture_verrou) === "locked" ? "unlocked" : "locked")) === "unlocked"
      ? confirm2("unlock", () => car("lock", "lock.unlock", C.voiture_verrou, {}, "unlocked", () => st(C.voiture_verrou) === "unlocked", "Voiture déverrouillée"), null)
      : car("lock", "lock.lock", C.voiture_verrou, {}, "locked", () => st(C.voiture_verrou) === "locked", "Voiture verrouillée")),
    "car-clim": (d) => { const on = aim(d, isOn(C.voiture_clim));
      return car("clim", `switch.turn_${on ? "on" : "off"}`, C.voiture_clim, {}, on, () => isOn(C.voiture_clim) === on, on ? "Climatisation lancée" : "Climatisation arrêtée"); },
    "car-refresh": () => { const was = st(C.voiture_maj);
      return car("refresh", "button.press", C.voiture_rafraichir, {}, null, () => st(C.voiture_maj) !== was, "Relevé à jour"); },
    "car-lim": (d) => call("number.set_value", C.voiture_limite_pct, { value: step(C.voiture_limite_pct, +d.d, 10, 50, 100) }),
    "car-limdc": (d) => call("number.set_value", C.voiture_limite_dc_pct, { value: step(C.voiture_limite_dc_pct, +d.d, 10, 50, 100) }),
    "car-service": () => confirm2("service", () => call("input_number.set_value", C.entretien_dernier_km, { value: num(C.voiture_odometre) }).then(done("Révision enregistrée au compteur actuel")), "Appuie encore pour remettre le compteur de révision à zéro"),
    "car-service-km": () => { const v = parseInt(prompt("Kilométrage de la révision :", num(C.entretien_dernier_km)), 10); if (Number.isFinite(v)) call("input_number.set_value", C.entretien_dernier_km, { value: v }).then(done("Révision enregistrée")); },
    "ha-menu": () => HA && HA.toggleMenu(),
  };
  // Actions des fichiers propres à Home Assistant (diagnostic, historique), chargés avant celui-ci
  Object.assign(A, BZ.extraActions || {});
  BZ.actions = A;
  // Page visée par un lien interne : « #/energy » (démo) ; Home Assistant : l'adresse du panneau (/breezy/energy)
  const linkTo = (a) => {
    const href = a.getAttribute("href") || "";
    if (href.startsWith("#/")) return href.slice(2);
    if (!HA || !href.startsWith("/")) return null;
    const id = HA.idOf(href);
    return ROUTES.some((x) => x.id === id) ? id : null;
  };
  // Home Assistant écoute les clics sur les liens du cadre (sur body) et les envoie à la page principale : on garde pour
  // nous les clics simples sur nos liens dès la phase de capture (le gestionnaire ci-dessous fait la navigation). Ctrl,
  // Cmd, Maj, clic du milieu : le navigateur ouvre la vraie adresse de la page (/breezy/energy) dans un nouvel onglet
  if (HA) document.addEventListener("click", (e) => {
    const a = e.target.closest && e.target.closest("a[href]");
    if (!a || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    const href = a.getAttribute("href");
    if (href.startsWith("#") && !href.startsWith("#/")) { e.preventDefault(); const t = document.getElementById(href.slice(1)); if (t) t.focus(); return; }   // lien d'évitement « #view »
    if (linkTo(a)) e.preventDefault();
  }, true);
  document.addEventListener("click", (e) => {
    // Liens internes vers une page : navigation gérée ici
    const a = e.target.closest("a[href]"), to = a && linkTo(a);
    // data-spot : une fois sur la page, on va jusqu'à la carte visée (pastilles de la maison de l'Aperçu)
    if (to && !e.metaKey && !e.ctrlKey && !e.shiftKey) { e.preventDefault(); go(to); if (a.dataset.spot) A.spot({ spot: a.dataset.spot }); return; }
    const el = e.target.closest("[data-act]");
    // Clic hors d'un menu ouvert : on le ferme
    if (BZ.ui.pop && !e.target.closest(".pop, [data-act=pop]")) { BZ.ui.pop = null; render(); }
    if (!el || el.disabled || el.getAttribute("aria-busy") === "true" || el.tagName === "SELECT") return;
    const fn = A[el.dataset.act];
    if (fn) { e.preventDefault(); if (el.dataset.act !== "pop" && el.closest(".pop")) BZ.ui.pop = null; fn({ ...el.dataset }); }
  });
  document.addEventListener("keydown", (e) => {
    const el = e.target.closest && e.target.closest('[data-act][role="link"]');
    if (el && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); A[el.dataset.act]({ ...el.dataset }); }
    if (e.key === "Escape") { if (BZ.ui.sheet) closeSheet(); else if (BZ.ui.pop) { BZ.ui.pop = null; render(); } }
    const typing = e.target.closest("input, select, textarea, [role=slider]");
    if (!typing && e.key === "/" && !e.metaKey && !e.ctrlKey) { const q = document.getElementById("q"); if (q && q.offsetParent) { e.preventDefault(); q.focus(); } }
    if (!typing && !e.metaKey && !e.ctrlKey && !e.altKey && /^[1-5]$/.test(e.key)) go(ROUTES[+e.key - 1].id);
  });
  document.addEventListener("change", (e) => {
    if (e.target.dataset.act === "robot-scene") call("select.select_option", C.robot_scene, { option: e.target.value });
  });

  /* ─── Curseur vertical (panneaux) : pointeur et clavier ───────────── */
  const VS = {
    cover: (i, v) => coverTo(C.volets[i], v),
    rad: (i, v) => call("climate.set_temperature", C.radiateurs[i], { temperature: v }),
    stove: (i, v) => call("climate.set_temperature", C.poele, { temperature: v }),
    volume: (i, v) => call("media_player.volume_set", C.homepod, { volume_level: v / 100 }),
  };
  const vsSet = (el, v) => {
    const min = +el.dataset.min, max = +el.dataset.max, s = +el.dataset.step;
    v = BZ.clamp(Math.round(v / s) * s, min, max); v = +v.toFixed(2);
    el.style.setProperty("--v", `${((v - min) / (max - min)) * 100}%`);
    el.dataset.value = v; el.setAttribute("aria-valuenow", v);
    const k = el.dataset.vs, txt = k === "cover" || k === "volume" ? `${v} %` : `${fmt.n(v, 1)}°`;
    el.querySelector("output").textContent = txt; el.setAttribute("aria-valuetext", txt);
    return v;
  };
  let drag = null;
  document.addEventListener("pointerdown", (e) => {
    const el = e.target.closest(".vs"); if (!el) return;
    e.preventDefault(); el.setPointerCapture(e.pointerId); el.classList.add("is-drag");
    drag = { el, start: +el.dataset.value }; move(e);
  });
  const move = (e) => { if (!drag) return; const el = drag.el, r = el.getBoundingClientRect(), k = el.dataset.orient === "h" ? (e.clientX - r.left) / r.width : 1 - (e.clientY - r.top) / r.height; vsSet(el, +el.dataset.min + BZ.clamp(k, 0, 1) * (el.dataset.max - el.dataset.min)); };
  document.addEventListener("pointermove", move);
  document.addEventListener("pointerup", () => { if (!drag) return; const { el, start } = drag; drag = null; el.classList.remove("is-drag"); if (+el.dataset.value !== start) VS[el.dataset.vs](+el.dataset.i, +el.dataset.value); });
  document.addEventListener("keydown", (e) => {
    const el = e.target.closest && e.target.closest(".vs"); if (!el) return;
    const s = +el.dataset.step, map = { ArrowUp: s, ArrowRight: s, ArrowDown: -s, ArrowLeft: -s, PageUp: s * 5, PageDown: -s * 5 };
    if (!(e.key in map)) return; e.preventDefault();
    const v = vsSet(el, +el.dataset.value + map[e.key]);
    clearTimeout(el._t); el._t = setTimeout(() => VS[el.dataset.vs](+el.dataset.i, v), 450);
  });

  /* ─── Thème : clair par défaut (comme la maquette), sombre, ou automatique ─
     Home Assistant : automatique par défaut, et « automatique » suit le thème choisi dans HA (pas celui du système) */
  function applyTheme() {
    const t = BZ.ui.theme, auto = HA ? HA.darkMode : matchMedia("(prefers-color-scheme: dark)").matches;
    const dark = t === "dark" || (t === "auto" && auto);
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = dark ? "#0e0f12" : "#e9ebef";
  }
  matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => { if (BZ.ui.theme === "auto") { applyTheme(); render(); } });

  /* ─── Mode « une page » : seulement quand l'écran peut tout tenir, sinon la page défile ─ */
  const fitQ = matchMedia("(min-width: 1366px) and (min-height: 820px), (min-width: 1200px) and (min-height: 900px)");
  const applyFit = () => document.body.classList.toggle("fit", fitQ.matches);
  fitQ.addEventListener("change", applyFit);

  /* ─── Home Assistant : menu, connexion, page affichée ─────────────────── */
  // Bouton menu : mêmes règles que celui de HA (écran étroit ou barre latérale masquée, hors mode kiosque)
  const haChrome = () => {
    const root = document.documentElement;
    root.toggleAttribute("data-ha-menu", HA.showMenu);
    root.toggleAttribute("data-ha-offline", !HA.connected);
  };
  if (HA) {
    HA.on("theme", () => { if (BZ.ui.theme === "auto") { applyTheme(); render(); } });
    // « Retour » du navigateur ou lien vers /breezy/vehicle : HA nous donne la nouvelle adresse
    HA.on("route", (r) => { const id = routeOf(r) || "overview"; if (id !== current) go(id, false); });
    ["narrow", "meta", "connection"].forEach((type) => HA.on(type, () => { BZ.user = userName(); haChrome(); render(); }));
  }

  /* ─── Démarrage ────────────────────────────────────────────────────── */
  applyFit();
  applyTheme();
  topInit();
  if (HA) { haChrome(); if (haLegacy) HA.navigate(current, { replace: true }); }   // ancien lien « #/page » : l'adresse devient /breezy/page
  const sync = () => { const r = fromHash(); if (r && r !== current) go(r, false); };
  if (!HA) { window.addEventListener("hashchange", sync); window.addEventListener("popstate", sync); }
  BZ.subscribe(render);
  setTimeout(() => { document.body.classList.remove("is-loading"); render(); }, 400);
})();
